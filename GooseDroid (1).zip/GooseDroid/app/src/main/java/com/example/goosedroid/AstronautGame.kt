package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.random.Random

/**
 * Game 9: Goose Astronaut. An open 3D world: upgrade your rocket in the hangar with scrap,
 * fly through space between planets and asteroid fields, land on planets and walk around.
 * Your rocket upgrades and scrap are saved between sessions.
 */
class AstronautGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "astro", versus, onExit) {

    companion object {
        const val HANGAR = 0
        const val FLIGHT = 1
        const val SURFACE = 2
        const val SCRAP = 0
        const val FUEL = 1
        const val REPAIR = 2
        const val CRYSTAL = 3
        const val NEAR = 0.3f
        // box faces: +x -x +y -y +z -z; corner index = xb + 2*yb + 4*zb
        val FACES = arrayOf(
            intArrayOf(1, 3, 7, 5), intArrayOf(0, 2, 6, 4), intArrayOf(2, 3, 7, 6),
            intArrayOf(0, 1, 5, 4), intArrayOf(4, 5, 7, 6), intArrayOf(0, 1, 3, 2)
        )
        val ROCKET_COLORS = intArrayOf(
            Color.rgb(235, 238, 245), Color.rgb(220, 60, 60), Color.rgb(70, 72, 85), Color.rgb(255, 170, 40),
            Color.rgb(60, 120, 230), Color.WHITE, Color.rgb(255, 150, 0), Color.rgb(180, 190, 205)
        )
        // astronaut goose parts: x, y, z (centre), half sizes, colour index (0 body, 1 beak, 2 wing, 3 glass, 4 pack, 5 suit)
        val ASTRO = listOf(
            floatArrayOf(-0.14f, 0.16f, 0f, 0.06f, 0.16f, 0.07f, 1f),
            floatArrayOf(0.14f, 0.16f, 0f, 0.06f, 0.16f, 0.07f, 1f),
            floatArrayOf(0f, 0.525f, 0f, 0.30f, 0.225f, 0.42f, 5f),
            floatArrayOf(0f, 0.9f, 0.2f, 0.10f, 0.2f, 0.10f, 0f),
            floatArrayOf(0f, 1.2f, 0.30f, 0.17f, 0.15f, 0.17f, 0f),
            floatArrayOf(0f, 1.17f, 0.62f, 0.08f, 0.05f, 0.16f, 1f),
            floatArrayOf(0f, 0.62f, -0.42f, 0.2f, 0.22f, 0.12f, 4f),
            floatArrayOf(-0.34f, 0.545f, -0.02f, 0.05f, 0.125f, 0.28f, 5f),
            floatArrayOf(0.34f, 0.545f, -0.02f, 0.05f, 0.125f, 0.28f, 5f),
            floatArrayOf(0f, 1.22f, 0.30f, 0.27f, 0.27f, 0.27f, 3f)
        )
    }

    override val coinRate = 0.25f
    override val versusLimitMs = 180_000L
    override fun currentScore() = score

    private class Planet(
        val name: String, val x: Float, val y: Float, val z: Float, val r: Float,
        val color: Int, val ring: Boolean, val landable: Boolean
    ) {
        var discovered = false
        var landed = false
    }

    private class Rock(val x: Float, val y: Float, val z: Float, val size: Float, val yaw: Float, val pitch: Float, val color: Int)
    private class Pick(val kind: Int, val x: Float, val y: Float, val z: Float) { var taken = false }
    private class DI(val d2: Float, val type: Int, val ref: Any?)

    private val planets = listOf(
        Planet("Gooseland", 0f, 0f, 0f, 120f, Color.rgb(90, 170, 100), false, true),
        Planet("Honkus", 700f, 60f, 500f, 90f, Color.rgb(210, 120, 80), false, true),
        Planet("Feathera", -900f, -80f, 1200f, 140f, Color.rgb(225, 230, 245), false, true),
        Planet("Pondus", 300f, 200f, -1500f, 110f, Color.rgb(60, 120, 220), false, true),
        Planet("Nestor", -1500f, 150f, -700f, 70f, Color.rgb(160, 120, 200), false, true),
        Planet("Ringus", 1800f, -100f, 1400f, 220f, Color.rgb(230, 190, 110), true, false),
        Planet("Quackion", -300f, -300f, 2600f, 100f, Color.rgb(120, 220, 170), false, true)
    )
    private val rocks = ArrayList<Rock>()
    private val picks = ArrayList<Pick>()
    private val crystalsBy = Array(7) { ArrayList<Pick>() }
    private val decorBy = Array(7) { ArrayList<FloatArray>() }
    private val stars = Array(170) { FloatArray(4) }
    private val items = ArrayList<DI>()

    // ---------- state ----------
    private var mode = HANGAR
    private var curPlanet = 0
    private var score = 0
    private var scrapRun = 0
    private var discoveries = 0
    private var landings = 0
    private var dist = 0f
    private var t = 0f
    private var lastAt = 0L
    private var ready = false
    private var flash = ""
    private var flashUntil = 0L
    private var invuln = 0f
    private var jumpBuf = 0f

    // ship
    private var sxp = 0f
    private var syp = 0f
    private var szp = 0f
    private var yaw = 0f
    private var pitch = 0f
    private var bank = 0f
    private var fuel = 100f
    private var hull = 3
    private var boosting = false
    private var landDx = 0f
    private var landDy = 1f
    private var landDz = 0f

    // walking on a planet
    private var gx = 0f
    private var gy = 0f
    private var gz = -6f
    private var gvy = 0f
    private var gyaw = 0f
    private var gOnGround = true
    private var sYaw = 0f
    private var hYaw = 0f

    // camera
    private var camX = 0f
    private var camY = 0f
    private var camZ = 0f
    private var camYaw = 0f
    private var camPitch = 0f
    private var ccy = 1f
    private var csy = 0f
    private var ccp = 1f
    private var csp = 0f
    private var focal = 1f
    private var cx0 = 0f
    private var cy0 = 0f
    private var fogC = Color.BLACK

    // touch
    private var movePid = -1
    private var lookPid = -1
    private var boostPid = -1
    private var moveOx = 0f
    private var moveOy = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var lastLookX = 0f

    // drawing tools
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(60, 0, 0, 0); strokeWidth = 1.2f
    }
    private val skyP = Paint()
    private val uiP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val planetP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val leftP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()
    private val rect = RectF()
    private val pr = FloatArray(8)
    private val pu = FloatArray(8)
    private val pd = FloatArray(8)
    private val qr = FloatArray(16)
    private val qu = FloatArray(16)
    private val qd = FloatArray(16)
    private val wxs = FloatArray(8)
    private val wys = FloatArray(8)
    private val wzs = FloatArray(8)
    private val bas = FloatArray(9)

    // hangar panel (normal Android views on top of the 3D scene)
    private val panel = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        val p = (12 * d).toInt()
        setPadding(p, p, p, p)
        background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(Color.argb(205, 15, 18, 40)) }
        visibility = View.GONE
    }
    private val scrapText = TextView(ctx).apply { setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
    private val partBtns = Array(3) { Button(ctx) }
    private val launchBtn = Button(ctx)

    init {
        hud.setTextColor(Color.WHITE)
        hud.setShadowLayer(5f, 0f, 0f, Color.BLACK)
        val r = Random(3)
        for (s in stars) {
            var x = r.nextFloat() * 2f - 1f
            var y = r.nextFloat() * 2f - 1f
            var z = r.nextFloat() * 2f - 1f
            val l = max(0.1f, sqrt(x * x + y * y + z * z))
            x /= l; y /= l; z /= l
            s[0] = x; s[1] = y; s[2] = z; s[3] = 0.6f + r.nextFloat() * 1.6f
        }
        panel.addView(TextView(ctx).apply {
            text = tr("Collect scrap ⚙ in space to upgrade your rocket!"); setTextColor(Color.rgb(200, 210, 255)); textSize = 12f
        })
        panel.addView(scrapText)
        for (i in 0 until 3) {
            panel.addView(partBtns[i])
            partBtns[i].setOnClickListener { upgrade(i) }
        }
        launchBtn.text = tr("🚀 Launch!")
        launchBtn.setOnClickListener { launch() }
        panel.addView(launchBtn)
        addView(
            panel,
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
                val m = (10 * d).toInt()
                setMargins(m, 0, m, m)
            }
        )
    }

    // =====================================================================
    // saved progress
    // =====================================================================

    private fun prefs() = Store.prefs(context)
    private fun lv(i: Int) = prefs().getInt("astro_lv$i", 1)
    private fun scrap() = prefs().getInt("astro_scrap", 0)
    private fun fuelMax() = 60f + 40f * lv(1)
    private fun hullMax() = 2 + lv(2)

    private fun addScrap(n: Int) {
        prefs().edit().putInt("astro_scrap", scrap() + n).apply()
        scrapRun += n
    }

    private fun upgradeCost(i: Int) = (if (i == 0) 25 else 20) * lv(i)

    private fun upgrade(i: Int) {
        if (lv(i) >= 5) return
        val cost = upgradeCost(i)
        if (scrap() < cost) { flashMsg(tr("Not enough scrap!")); return }
        prefs().edit().putInt("astro_scrap", scrap() - cost).putInt("astro_lv$i", lv(i) + 1).apply()
        Sound.play(600.0, 1000.0, 120)
        refreshPanel()
    }

    private fun refreshPanel() {
        scrapText.text = trf("⚙ Scrap: %d", scrap())
        val names = arrayOf(tr("Engine"), tr("Fuel tank"), tr("Hull"))
        for (i in 0 until 3) {
            val l = lv(i)
            partBtns[i].text = names[i] + "  " + trf("Lv %d", l) + "   " + (if (l >= 5) tr("MAX") else trf("Upgrade (%d ⚙)", upgradeCost(i)))
        }
    }

    private fun setMode(m: Int) {
        mode = m
        panel.visibility = if (m == HANGAR) View.VISIBLE else View.GONE
        if (m == HANGAR) refreshPanel()
        movePid = -1; lookPid = -1; boostPid = -1
    }

    // =====================================================================
    // world
    // =====================================================================

    override fun reset() {
        for (p in planets) { p.discovered = false; p.landed = false }
        planets[0].discovered = true
        planets[0].landed = true
        score = 0; scrapRun = 0; discoveries = 0; landings = 0; dist = 0f; t = 0f
        invuln = 0f; boosting = false; curPlanet = 0
        hYaw = 0f
        fuel = fuelMax(); hull = hullMax()
        genWorld()
        setMode(HANGAR)
        val now = SystemClock.uptimeMillis()
        lastAt = now
        flash = ""; flashUntil = 0L
        focal = width * 0.9f
        cx0 = width / 2f
        cy0 = height * 0.46f
        ready = true
    }

    private fun genWorld() {
        rocks.clear(); picks.clear()
        val r = Random(42)
        val centers = arrayOf(
            floatArrayOf(350f, -50f, -400f), floatArrayOf(-500f, 120f, 500f), floatArrayOf(1200f, 100f, -300f),
            floatArrayOf(-1100f, -150f, -1500f), floatArrayOf(900f, 200f, 1100f), floatArrayOf(-1700f, 50f, 500f),
            floatArrayOf(200f, 150f, 1700f), floatArrayOf(-700f, -200f, 2000f), floatArrayOf(1500f, -100f, -1200f)
        )
        for (cn in centers) repeat(14) {
            rocks.add(
                Rock(
                    cn[0] + (r.nextFloat() - 0.5f) * 320f, cn[1] + (r.nextFloat() - 0.5f) * 160f, cn[2] + (r.nextFloat() - 0.5f) * 320f,
                    4f + r.nextFloat() * 7f, r.nextFloat() * 6.28f, r.nextFloat() * 6.28f,
                    Color.rgb(110 + r.nextInt(50), 100 + r.nextInt(40), 90 + r.nextInt(40))
                )
            )
        }
        // a trail of scrap to get you started, heading away from Gooseland
        for (k in 0 until 8) picks.add(Pick(SCRAP, 0f, 0f, -300f - k * 60f))
        picks.add(Pick(FUEL, 0f, 0f, -820f))
        var made = 0
        while (made < 18) {
            val x = (r.nextFloat() - 0.5f) * 4800f
            val y = (r.nextFloat() - 0.5f) * 700f
            val z = (r.nextFloat() - 0.5f) * 4800f
            if (planets.any { hypot(hypot(x - it.x, y - it.y), z - it.z) < it.r + 60f }) continue
            made++
            repeat(6) { picks.add(Pick(SCRAP, x + (r.nextFloat() - 0.5f) * 80f, y + (r.nextFloat() - 0.5f) * 40f, z + (r.nextFloat() - 0.5f) * 80f)) }
            repeat(3) { picks.add(Pick(FUEL, x + (r.nextFloat() - 0.5f) * 80f, y + (r.nextFloat() - 0.5f) * 40f, z + (r.nextFloat() - 0.5f) * 80f)) }
            if (r.nextInt(100) < 35) picks.add(Pick(REPAIR, x, y + 12f, z))
        }
        // planet surfaces: crystals to collect and rocks to look at
        for (i in 0 until planets.size) {
            crystalsBy[i].clear(); decorBy[i].clear()
            val pr2 = Random(100 + i)
            repeat(6) {
                val a = pr2.nextFloat() * 6.28f
                val rr = 8f + pr2.nextFloat() * 14f
                crystalsBy[i].add(Pick(CRYSTAL, sin(a) * rr, 0.8f, cos(a) * rr))
            }
            repeat(26) {
                val a = pr2.nextFloat() * 6.28f
                val rr = 20f + pr2.nextFloat() * 90f
                crystalsBy[i].add(Pick(CRYSTAL, sin(a) * rr, 0.8f, cos(a) * rr))
            }
            repeat(28) {
                val a = pr2.nextFloat() * 6.28f
                val rr = 10f + pr2.nextFloat() * 105f
                decorBy[i].add(floatArrayOf(sin(a) * rr, cos(a) * rr, 0.8f + pr2.nextFloat() * 2.4f, pr2.nextFloat() * 6.28f))
            }
        }
    }

    // =====================================================================
    // touch controls
    // =====================================================================

    private fun btnX(i: Int) = if (i == 0) width - 90 * d else width - 190 * d
    private fun btnY(i: Int) = if (i == 0) height - 130 * d else height - 80 * d
    private fun btnR(i: Int) = if (i == 0) 46 * d else 38 * d

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val id = e.getPointerId(idx)
                val x = e.getX(idx)
                val y = e.getY(idx)
                var btn = -1
                if (mode != HANGAR) for (i in 0 until 2) if (hypot(x - btnX(i), y - btnY(i)) <= btnR(i) + 10 * d) btn = i
                when {
                    btn == 0 -> { if (mode == SURFACE) jumpBuf = 0.15f else boostPid = id }
                    btn == 1 -> action()
                    mode != HANGAR && x < width / 2f && movePid == -1 -> { movePid = id; moveOx = x; moveOy = y; moveX = x; moveY = y }
                    lookPid == -1 && (mode != FLIGHT) -> { lookPid = id; lastLookX = x }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == movePid) {
                        moveX = e.getX(i); moveY = e.getY(i)
                    } else if (id == lookPid) {
                        val x = e.getX(i)
                        if (mode == SURFACE) sYaw += (x - lastLookX) * 0.006f else hYaw += (x - lastLookX) * 0.006f
                        lastLookX = x
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == movePid) movePid = -1
                if (id == lookPid) lookPid = -1
                if (id == boostPid) boostPid = -1
                if (a != MotionEvent.ACTION_POINTER_UP) { movePid = -1; lookPid = -1; boostPid = -1 }
            }
        }
        return true
    }

    private fun stick(): FloatArray {
        val out = floatArrayOf(0f, 0f)
        if (movePid != -1) {
            val r = 56f * d
            var jx = (moveX - moveOx) / r
            var jy = (moveY - moveOy) / r
            val len = hypot(jx, jy)
            if (len > 1f) { jx /= len; jy /= len }
            out[0] = jx; out[1] = jy
        }
        return out
    }

    private fun action() {
        if (mode == FLIGHT) land()
        else if (mode == SURFACE && hypot(gx, gz) < 6f) launchFromSurface()
    }

    // =====================================================================
    // game logic
    // =====================================================================

    private fun flashMsg(s: String) {
        flash = s
        flashUntil = SystemClock.uptimeMillis() + 1600L
    }

    private fun launch() {
        val home = planets[0]
        sxp = home.x
        syp = home.y
        szp = home.z - (home.r + 70f)
        yaw = 3.1416f // away from Gooseland
        pitch = 0f
        bank = 0f
        fuel = fuelMax()
        hull = hullMax()
        t = 0f
        setMode(FLIGHT)
        Sound.play(150.0, 400.0, 500)
    }

    private fun nearPlanet(): Planet? {
        var best: Planet? = null
        var bd = 1e9f
        for (p in planets) {
            val dd = hypot(hypot(sxp - p.x, syp - p.y), szp - p.z) - p.r
            if (dd < 90f && dd < bd) { bd = dd; best = p }
        }
        return best
    }

    private fun land() {
        val p = nearPlanet() ?: return
        if (!p.landable) { flashMsg(tr("Gas giants can't be landed on!")); return }
        val i = planets.indexOf(p)
        curPlanet = i
        val dx = sxp - p.x
        val dy = syp - p.y
        val dz = szp - p.z
        val l = max(0.1f, sqrt(dx * dx + dy * dy + dz * dz))
        landDx = dx / l; landDy = dy / l; landDz = dz / l
        if (!p.landed) {
            p.landed = true
            landings++
            addScrap(20)
            flashMsg(trf("Landed on %s! +100", p.name))
        }
        if (i == 0) {
            fuel = fuelMax(); hull = hullMax()
            hYaw = 0f
            setMode(HANGAR)
        } else {
            gx = 0f; gz = -7f; gy = 0f; gvy = 0f; gOnGround = true; sYaw = 0f; gyaw = 0f
            setMode(SURFACE)
        }
        Sound.play(400.0, 150.0, 400)
    }

    private fun launchFromSurface() {
        val p = planets[curPlanet]
        sxp = p.x + landDx * (p.r + 45f)
        syp = p.y + landDy * (p.r + 45f)
        szp = p.z + landDz * (p.r + 45f)
        yaw = atan2(landDx, landDz)
        pitch = -asin(landDy.coerceIn(-1f, 1f))
        fuel = min(fuelMax(), fuel + 0.4f * fuelMax())
        invuln = 2f
        setMode(FLIGHT)
        flashMsg(tr("⛽ Refuelled a bit!"))
        Sound.play(150.0, 400.0, 500)
    }

    override fun tick() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastAt) / 1000f).coerceIn(0.001f, 0.05f)
        lastAt = now
        t += dt
        invuln = max(0f, invuln - dt)
        jumpBuf = max(0f, jumpBuf - dt)
        when (mode) {
            HANGAR -> if (lookPid == -1) hYaw += 0.15f * dt
            FLIGHT -> updateFlight(dt)
            else -> updateSurface(dt)
        }
        if (!isRunning()) return
        updateCamera()
        score = scrapRun * 2 + discoveries * 50 + landings * 100 + (dist / 50f).toInt()
        hud.text = trf("Score: %d   ⚙ %d", score, scrap())
        invalidate()
    }

    private fun updateFlight(dt: Float) {
        val s = stick()
        yaw += s[0] * 1.3f * dt
        pitch = (pitch + s[1] * 1.2f * dt).coerceIn(-1.2f, 1.2f)
        bank += (-s[0] * 0.55f - bank) * min(1f, 4f * dt)
        boosting = boostPid != -1 && fuel > 0f
        val base = 60f + 18f * lv(0)
        var speed = base * (if (boosting) 2.2f else 1f)
        if (fuel <= 0f) speed = base * 0.35f
        fuel = max(0f, fuel - (if (boosting) 3f else 0.6f) * dt)
        val fx = sin(yaw) * cos(pitch)
        val fy = -sin(pitch)
        val fz = cos(yaw) * cos(pitch)
        sxp += fx * speed * dt
        syp += fy * speed * dt
        szp += fz * speed * dt
        dist += speed * dt

        for (p in planets) { // planets are solid
            val dx = sxp - p.x
            val dy = syp - p.y
            val dz = szp - p.z
            val dd = sqrt(dx * dx + dy * dy + dz * dz)
            val lim = p.r + 6f
            if (dd < lim && dd > 0.01f) { sxp = p.x + dx / dd * lim; syp = p.y + dy / dd * lim; szp = p.z + dz / dd * lim }
            if (!p.discovered && dd < p.r * 2.2f + 150f) {
                p.discovered = true
                discoveries++
                addScrap(10)
                flashMsg(trf("Discovered %s! +50", p.name))
                Sound.play(500.0, 1100.0, 250)
            }
        }
        if (invuln <= 0f) {
            for (rk in rocks) {
                val dx = sxp - rk.x
                val dy = syp - rk.y
                val dz = szp - rk.z
                val lim = rk.size * 0.85f + 3f
                if (dx * dx + dy * dy + dz * dz < lim * lim) {
                    hull--
                    invuln = 1.5f
                    flashMsg(tr("Asteroid hit!"))
                    Sound.play(200.0, 70.0, 250)
                    val dd = max(0.1f, sqrt(dx * dx + dy * dy + dz * dz))
                    sxp += dx / dd * 10f; syp += dy / dd * 10f; szp += dz / dd * 10f
                    break
                }
            }
        }
        if (hull <= 0) {
            gameOver(trf("You explored %d planets and collected %d scrap!", discoveries, scrapRun), score)
            return
        }
        for (p in picks) {
            if (p.taken) continue
            val dx = sxp - p.x
            val dy = syp - p.y
            val dz = szp - p.z
            if (dx * dx + dy * dy + dz * dz < 64f) {
                p.taken = true
                when (p.kind) {
                    SCRAP -> { addScrap(5); Sound.play(900.0, 1300.0, 45) }
                    FUEL -> { fuel = min(fuelMax(), fuel + 30f); Sound.play(500.0, 800.0, 70) }
                    else -> { hull = min(hullMax(), hull + 1); flashMsg("+1 ♥"); Sound.play(600.0, 900.0, 90) }
                }
            }
        }
        val fromOrigin = sqrt(sxp * sxp + syp * syp + szp * szp)
        if (fromOrigin > 3600f) {
            val k = 3600f / fromOrigin
            sxp *= k; syp *= k; szp *= k
            flashMsg(tr("Deep space! Turn back."))
        }
    }

    private fun updateSurface(dt: Float) {
        val s = stick()
        val fwd = -s[1]
        val str = s[0]
        val sn = sin(sYaw)
        val cs = cos(sYaw)
        val wx = sn * fwd + cs * str
        val wz = cs * fwd - sn * str
        gx += wx * 7f * dt
        gz += wz * 7f * dt
        val rr = hypot(gx, gz)
        if (rr > 110f) { gx *= 110f / rr; gz *= 110f / rr }
        val rd = hypot(gx, gz)
        if (rd < 2.6f && rd > 0.01f) { gx *= 2.6f / rd; gz *= 2.6f / rd }
        if (hypot(wx, wz) > 0.1f) gyaw = atan2(wx, wz)
        if (jumpBuf > 0f && gOnGround) { gvy = 7f; gOnGround = false; jumpBuf = 0f; Sound.play(400.0, 800.0, 90) }
        gvy -= 9f * dt // low gravity
        gy += gvy * dt
        if (gy <= 0f) { gy = 0f; gvy = 0f; gOnGround = true }
        for (p in crystalsBy[curPlanet]) {
            if (!p.taken && hypot(p.x - gx, p.z - gz) < 1.6f && gy < 2.2f) {
                p.taken = true
                addScrap(3)
                Sound.play(1000.0, 1500.0, 60)
            }
        }
    }

    private fun setBasis(yw: Float, pt: Float, rl: Float) {
        val sy = sin(yw)
        val cy = cos(yw)
        val sp = sin(pt)
        val cp = cos(pt)
        val fx = sy * cp
        val fy = -sp
        val fz = cy * cp
        val ux = sy * sp
        val uy = cp
        val uz = cy * sp
        val rx = cy
        val rz = -sy
        val sr = sin(rl)
        val cr = cos(rl)
        bas[0] = rx * cr + ux * sr; bas[1] = uy * sr; bas[2] = rz * cr + uz * sr
        bas[3] = ux * cr - rx * sr; bas[4] = uy * cr; bas[5] = uz * cr - rz * sr
        bas[6] = fx; bas[7] = fy; bas[8] = fz
    }

    private fun updateCamera() {
        when (mode) {
            FLIGHT -> {
                camYaw = yaw
                camPitch = pitch
                setBasis(yaw, pitch, 0f)
                camX = sxp - bas[6] * 15f + bas[3] * 4f
                camY = syp - bas[7] * 15f + bas[4] * 4f
                camZ = szp - bas[8] * 15f + bas[5] * 4f
            }
            SURFACE -> {
                camYaw = sYaw
                camPitch = 0.30f
                camX = gx - sin(sYaw) * 7f
                camY = gy + 3.4f
                camZ = gz - cos(sYaw) * 7f
            }
            else -> {
                camYaw = hYaw
                camPitch = 0.20f
                camX = -sin(hYaw) * 17f
                camY = 6f
                camZ = -cos(hYaw) * 17f
            }
        }
        ccy = cos(camYaw); csy = sin(camYaw); ccp = cos(camPitch); csp = sin(camPitch)
    }

    // =====================================================================
    // 3D drawing
    // =====================================================================

    private fun mixC(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
    )

    private fun tone(color: Int, k: Float, fog: Float): Int {
        val lit = Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt())
        return (mixC(lit, fogC, fog) and 0x00FFFFFF) or (Color.alpha(color) shl 24)
    }

    private fun put(i: Int, x: Float, y: Float, z: Float) {
        val rx = x - camX
        val ry = y - camY
        val rz = z - camZ
        val ax = rx * ccy - rz * csy
        val az = rx * csy + rz * ccy
        pr[i] = ax
        pu[i] = ry * ccp + az * csp
        pd[i] = -ry * csp + az * ccp
    }

    private fun poly(c: Canvas, color: Int, n: Int) {
        var m = 0
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            val di = pd[i] - NEAR
            val dj = pd[j] - NEAR
            if (di >= 0f) { qr[m] = pr[i]; qu[m] = pu[i]; qd[m] = pd[i]; m++ }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                qr[m] = pr[i] + (pr[j] - pr[i]) * f
                qu[m] = pu[i] + (pu[j] - pu[i]) * f
                qd[m] = NEAR
                m++
            }
        }
        if (m < 3) return
        path.reset()
        for (k in 0 until m) {
            val sx = cx0 + focal * qr[k] / qd[k]
            val sy = cy0 - focal * qu[k] / qd[k]
            if (k == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        path.close()
        fillP.color = color
        c.drawPath(path, fillP)
        c.drawPath(path, lineP)
    }

    private fun quadTop(c: Canvas, x0: Float, x1: Float, z0: Float, z1: Float, y: Float, color: Int) {
        put(0, x0, y, z0); put(1, x1, y, z0); put(2, x1, y, z1); put(3, x0, y, z1)
        poly(c, color, 4)
    }

    /** A box turned wys the current basis in bas[] (right, up, forward). Only faces looking at the camera are drawn. */
    private fun obox(c: Canvas, cx: Float, cy: Float, cz: Float, hx: Float, hy: Float, hz: Float, color: Int, fog: Float) {
        for (i in 0 until 8) {
            val sx = if ((i and 1) == 0) -hx else hx
            val sy = if (((i shr 1) and 1) == 0) -hy else hy
            val sz = if (((i shr 2) and 1) == 0) -hz else hz
            wxs[i] = cx + sx * bas[0] + sy * bas[3] + sz * bas[6]
            wys[i] = cy + sx * bas[1] + sy * bas[4] + sz * bas[7]
            wzs[i] = cz + sx * bas[2] + sy * bas[5] + sz * bas[8]
        }
        for (f in 0 until 6) {
            val axis = (f shr 1) * 3
            val sign = if ((f and 1) == 0) 1f else -1f
            val nx = bas[axis] * sign
            val ny = bas[axis + 1] * sign
            val nz = bas[axis + 2] * sign
            val fc = FACES[f]
            val fcx = (wxs[fc[0]] + wxs[fc[1]] + wxs[fc[2]] + wxs[fc[3]]) / 4f
            val fcy = (wys[fc[0]] + wys[fc[1]] + wys[fc[2]] + wys[fc[3]]) / 4f
            val fcz = (wzs[fc[0]] + wzs[fc[1]] + wzs[fc[2]] + wzs[fc[3]]) / 4f
            if ((camX - fcx) * nx + (camY - fcy) * ny + (camZ - fcz) * nz <= 0f) continue
            val shade = min(1f, 0.5f + 0.5f * max(0f, nx * 0.35f + ny * 0.8f - nz * 0.45f))
            for (k in 0 until 4) put(k, wxs[fc[k]], wys[fc[k]], wzs[fc[k]])
            poly(c, tone(color, shade, fog), 4)
        }
    }

    /** Draws a model made of boxes (parts relative to the object, turned wys bas[]), far parts first. */
    private fun drawParts(c: Canvas, parts: List<FloatArray>, colors: IntArray, ox: Float, oy: Float, oz: Float, scale: Float, fog: Float) {
        val n = parts.size
        val cxs = FloatArray(n)
        val cys = FloatArray(n)
        val czs = FloatArray(n)
        val ds = FloatArray(n)
        for (i in 0 until n) {
            val p = parts[i]
            cxs[i] = ox + (bas[0] * p[0] + bas[3] * p[1] + bas[6] * p[2]) * scale
            cys[i] = oy + (bas[1] * p[0] + bas[4] * p[1] + bas[7] * p[2]) * scale
            czs[i] = oz + (bas[2] * p[0] + bas[5] * p[1] + bas[8] * p[2]) * scale
            val dx = cxs[i] - camX
            val dy = cys[i] - camY
            val dz = czs[i] - camZ
            ds[i] = dx * dx + dy * dy + dz * dz
        }
        for (i in (0 until n).sortedByDescending { ds[it] }) {
            val p = parts[i]
            obox(c, cxs[i], cys[i], czs[i], p[3] * scale, p[4] * scale, p[5] * scale, colors[p[6].toInt()], fog)
        }
    }

    /** The rocket you built: more tanks, a bigger engine and more fins as you upgrade it. Points along +z. */
    private fun rocketParts(flame: Float): List<FloatArray> {
        val e = lv(0)
        val f = lv(1)
        val h = lv(2)
        val out = ArrayList<FloatArray>()
        out.add(floatArrayOf(0f, 0f, -1.3f, 0.42f + 0.1f * e, 0.42f + 0.1f * e, 0.6f, 2f))
        if (flame > 0f) out.add(floatArrayOf(0f, 0f, -1.9f - flame * 0.9f, 0.3f + 0.06f * e, 0.3f + 0.06f * e, 0.6f + flame, 3f))
        for (k in 0 until f) out.add(floatArrayOf(0f, 0f, 0.1f + k * 1.45f, 0.85f, 0.85f, 0.72f, if (k % 2 == 0) 0f else 7f))
        val zc = 0.1f + f * 1.45f
        out.add(floatArrayOf(0f, 0f, zc + 0.25f, 0.7f, 0.7f, 0.9f, 1f))
        out.add(floatArrayOf(0f, 0.72f, zc - 0.1f, 0.28f, 0.28f, 0.28f, 5f))
        out.add(floatArrayOf(0f, 0.72f, zc + 0.3f, 0.1f, 0.07f, 0.22f, 6f))
        val fl = 0.5f + 0.18f * h
        out.add(floatArrayOf(-0.85f - fl, 0f, -0.6f, fl, 0.06f, 0.7f, 4f))
        out.add(floatArrayOf(0.85f + fl, 0f, -0.6f, fl, 0.06f, 0.7f, 4f))
        if (h >= 3) out.add(floatArrayOf(0f, 0.85f + fl * 0.6f, -0.6f, 0.06f, fl * 0.6f, 0.7f, 4f))
        if (h >= 4) {
            out.add(floatArrayOf(-0.95f, 0f, 0.1f, 0.12f, 0.5f, f * 0.7f + 0.4f, 2f))
            out.add(floatArrayOf(0.95f, 0f, 0.1f, 0.12f, 0.5f, f * 0.7f + 0.4f, 2f))
        }
        return out
    }

    private fun disc(c: Canvas, x: Float, y: Float, z: Float, r: Float, color: Int, squash: Float) {
        put(0, x, y, z)
        if (pd[0] < NEAR) return
        val sx = cx0 + focal * pr[0] / pd[0]
        val sy = cy0 - focal * pu[0] / pd[0]
        val rad = max(2f, focal * r / pd[0])
        rect.set(sx - rad * squash, sy - rad, sx + rad * squash, sy + rad)
        fillP.color = color
        c.drawOval(rect, fillP)
    }

    private fun drawStars(c: Canvas, alpha: Int) {
        uiP.style = Paint.Style.FILL
        for (s in stars) {
            put(0, camX + s[0] * 1000f, camY + s[1] * 1000f, camZ + s[2] * 1000f)
            if (pd[0] < NEAR) continue
            val tw = 0.7f + 0.3f * sin(t * 2f + s[0] * 10f)
            uiP.color = Color.argb((alpha * tw).toInt(), 255, 255, 255)
            c.drawCircle(cx0 + focal * pr[0] / pd[0], cy0 - focal * pu[0] / pd[0], s[3] * d, uiP)
        }
    }

    private fun drawPlanet(c: Canvas, p: Planet) {
        put(0, p.x, p.y, p.z)
        val dep = pd[0]
        if (dep < 1f) return
        val sx = cx0 + focal * pr[0] / dep
        val sy = cy0 - focal * pu[0] / dep
        val rad = min(5000f, focal * p.r / dep)
        if (sx + rad < 0f || sx - rad > width || sy + rad < 0f || sy - rad > height) return
        planetP.shader = null
        planetP.color = Color.argb(60, Color.red(p.color), Color.green(p.color), Color.blue(p.color))
        c.drawCircle(sx, sy, rad * 1.07f, planetP)
        planetP.shader = RadialGradient(
            sx - rad * 0.35f, sy - rad * 0.35f, rad * 1.5f,
            mixC(p.color, Color.WHITE, 0.4f), mixC(p.color, Color.BLACK, 0.7f), Shader.TileMode.CLAMP
        )
        c.drawCircle(sx, sy, rad, planetP)
        planetP.shader = null
        if (p.ring) {
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = rad * 0.18f
            uiP.color = Color.argb(150, 235, 215, 170)
            rect.set(sx - rad * 1.9f, sy - rad * 0.4f, sx + rad * 1.9f, sy + rad * 0.4f)
            c.drawOval(rect, uiP)
        }
    }

    private fun drawSun(c: Canvas) {
        put(0, camX + 4000f, camY + 1200f, camZ + 3000f)
        if (pd[0] < 1f) return
        val sx = cx0 + focal * pr[0] / pd[0]
        val sy = cy0 - focal * pu[0] / pd[0]
        val rad = focal * 0.05f
        planetP.shader = RadialGradient(
            sx, sy, rad * 4f, intArrayOf(Color.argb(255, 255, 250, 200), Color.argb(120, 255, 200, 80), Color.argb(0, 255, 160, 40)),
            floatArrayOf(0.2f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(sx, sy, rad * 4f, planetP)
        planetP.shader = null
    }

    override fun onDraw(c: Canvas) {
        if (!ready) return
        val w = width.toFloat()
        val h = height.toFloat()
        if (mode == FLIGHT) drawSpace(c, w, h) else drawGround(c, w, h)
        drawHud(c, w, h)
    }

    private fun drawSpace(c: Canvas, w: Float, h: Float) {
        fogC = Color.BLACK
        skyP.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(3, 5, 18), Color.rgb(16, 10, 40), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, skyP)
        drawStars(c, 220)
        drawSun(c)

        items.clear()
        for (p in planets) {
            val dd = hypot(hypot(p.x - camX, p.y - camY), p.z - camZ) - p.r
            items.add(DI(dd * dd, 0, p))
        }
        for (rk in rocks) {
            val dx = rk.x - camX
            val dy = rk.y - camY
            val dz = rk.z - camZ
            val dd = dx * dx + dy * dy + dz * dz
            if (dd < 2000f * 2000f) items.add(DI(dd, 1, rk))
        }
        for (p in picks) {
            if (p.taken) continue
            val dx = p.x - camX
            val dy = p.y - camY
            val dz = p.z - camZ
            val dd = dx * dx + dy * dy + dz * dz
            if (dd < 1400f * 1400f) items.add(DI(dd, 2, p))
        }
        items.add(DI(15f * 15f, 3, null))
        items.sortByDescending { it.d2 }
        for (di in items) {
            when (di.type) {
                0 -> drawPlanet(c, di.ref as Planet)
                1 -> {
                    val rk = di.ref as Rock
                    setBasis(rk.yaw, rk.pitch, 0f)
                    obox(c, rk.x, rk.y, rk.z, rk.size, rk.size * 0.7f, rk.size * 0.85f, rk.color, 0f)
                }
                2 -> {
                    val p = di.ref as Pick
                    val sq = max(0.3f, abs(cos(t * 3f + p.x)))
                    when (p.kind) {
                        SCRAP -> disc(c, p.x, p.y, p.z, 3.2f, Color.rgb(222, 190, 70), sq)
                        FUEL -> disc(c, p.x, p.y, p.z, 3.6f, Color.rgb(80, 200, 255), sq)
                        else -> disc(c, p.x, p.y, p.z, 4f, Color.rgb(90, 235, 130), sq)
                    }
                }
                else -> {
                    if (!(invuln > 0f && (t * 12f).toInt() % 2 == 0)) {
                        setBasis(yaw, pitch, bank)
                        val flame = if (boosting) 1.2f else if (fuel > 0f) 0.5f + 0.2f * sin(t * 30f) else 0f
                        drawParts(c, rocketParts(flame), ROCKET_COLORS, sxp, syp, szp, 1.2f, 0f)
                    }
                }
            }
        }
    }

    private fun drawGround(c: Canvas, w: Float, h: Float) {
        val pl = planets[curPlanet]
        val horizonY = cy0 - focal * tan(camPitch)
        val skyTop = mixC(pl.color, Color.BLACK, 0.65f)
        val skyHor = mixC(pl.color, Color.WHITE, 0.55f)
        fogC = skyHor
        skyP.shader = LinearGradient(0f, 0f, 0f, horizonY, skyTop, skyHor, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, horizonY, skyP)
        skyP.shader = LinearGradient(0f, horizonY, 0f, h, skyHor, mixC(pl.color, Color.BLACK, 0.25f), Shader.TileMode.CLAMP)
        c.drawRect(0f, horizonY, w, h, skyP)
        drawStars(c, 110)

        val ts = 24f
        val tx = floor(camX / ts).toInt()
        val tz = floor(camZ / ts).toInt()
        val colA = mixC(pl.color, Color.WHITE, 0.15f)
        val colB = mixC(pl.color, Color.BLACK, 0.2f)
        for (iz in -6..6) for (ix in -6..6) {
            val gxi = tx + ix
            val gzi = tz + iz
            val x0 = gxi * ts
            val z0 = gzi * ts
            val dd = hypot(x0 + ts / 2f - camX, z0 + ts / 2f - camZ)
            quadTop(c, x0, x0 + ts, z0, z0 + ts, 0f, tone(if (((gxi + gzi) and 1) == 0) colA else colB, 1f, (dd / 170f).coerceIn(0f, 0.95f)))
        }

        items.clear()
        for (dc in decorBy[curPlanet]) {
            val dd = hypot(dc[0] - camX, dc[1] - camZ)
            if (dd < 150f) items.add(DI(dd * dd, 0, dc))
        }
        if (mode == SURFACE) {
            for (p in crystalsBy[curPlanet]) {
                if (p.taken) continue
                val dd = hypot(p.x - camX, p.z - camZ)
                if (dd < 150f) items.add(DI(dd * dd, 1, p))
            }
            items.add(DI((gx - camX) * (gx - camX) + (gz - camZ) * (gz - camZ), 3, null))
        }
        items.add(DI(camX * camX + camZ * camZ, 2, null))
        items.sortByDescending { it.d2 }
        val rockCol = mixC(pl.color, Color.rgb(90, 90, 100), 0.55f)
        for (di in items) {
            when (di.type) {
                0 -> {
                    val dc = di.ref as FloatArray
                    setBasis(dc[3], 0f, 0f)
                    val fog = (hypot(dc[0] - camX, dc[1] - camZ) / 170f).coerceIn(0f, 0.9f)
                    obox(c, dc[0], dc[2] * 0.6f, dc[1], dc[2], dc[2] * 0.6f, dc[2] * 0.8f, rockCol, fog)
                }
                1 -> {
                    val p = di.ref as Pick
                    setBasis(t * 1.5f + p.x, 0f, 0f)
                    val fog = (hypot(p.x - camX, p.z - camZ) / 170f).coerceIn(0f, 0.9f)
                    obox(c, p.x, 0.9f + 0.25f * sin(t * 2f + p.z), p.z, 0.35f, 0.7f, 0.35f, Color.rgb(120, 230, 255), fog)
                }
                2 -> { // the rocket stands upright
                    setBasis(0f, -1.5708f, 0f)
                    val flame = 0f
                    drawParts(c, rocketParts(flame), ROCKET_COLORS, 0f, 2.0f, 0f, 1.2f, 0f)
                }
                else -> {
                    setBasis(gyaw, 0f, 0f)
                    val cols = intArrayOf(
                        Cosmetics.body, Cosmetics.beak, mixC(Cosmetics.body, Color.GRAY, 0.2f),
                        Color.argb(110, 180, 230, 255), Color.rgb(120, 125, 140), Color.rgb(240, 240, 250)
                    )
                    drawParts(c, ASTRO, cols, gx, gy, gz, 1f, 0f)
                }
            }
        }
        if (mode == SURFACE) { // the flag you planted
            setBasis(0f, 0f, 0f)
            obox(c, 5f, 1.6f, 5f, 0.08f, 1.6f, 0.08f, Color.rgb(230, 230, 235), 0f)
            obox(c, 5.7f, 2.9f, 5f, 0.7f, 0.45f, 0.05f, Color.rgb(229, 57, 53), 0f)
        }
    }

    // =====================================================================
    // HUD
    // =====================================================================

    private fun drawRadar(c: Canvas, w: Float) {
        val r = 50 * d
        val cx = w - r - 10 * d
        val cy = r + 64 * d
        uiP.style = Paint.Style.FILL
        uiP.color = Color.argb(120, 0, 0, 0)
        c.drawCircle(cx, cy, r, uiP)
        uiP.style = Paint.Style.STROKE
        uiP.strokeWidth = 2 * d
        uiP.color = Color.argb(140, 120, 255, 170)
        c.drawCircle(cx, cy, r, uiP)
        uiP.style = Paint.Style.FILL
        for (p in planets) {
            val dx = p.x - sxp
            val dz = p.z - szp
            val rx = dx * ccy - dz * csy
            val rz = dx * csy + dz * ccy
            val dd = max(1f, hypot(rx, rz))
            val k = r * 0.9f / max(dd, 2800f)
            uiP.color = p.color
            c.drawCircle(cx + rx * k, cy - rz * k, (if (p.discovered) 5 else 3) * d, uiP)
        }
        uiP.color = Color.WHITE
        c.drawCircle(cx, cy, 3 * d, uiP)
    }

    private fun drawButton(c: Canvas, i: Int, label: String, on: Boolean) {
        uiP.style = Paint.Style.FILL
        uiP.color = Color.argb(if (on) 110 else 45, 255, 255, 255)
        c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
        uiP.style = Paint.Style.STROKE
        uiP.strokeWidth = 3 * d
        uiP.color = Color.argb(160, 255, 255, 255)
        c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
        textP.textSize = btnR(i) * 0.9f
        c.drawText(label, btnX(i), btnY(i) + btnR(i) * 0.3f, textP)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        val top = (if (versus != null) 104 else 80) * d
        if (mode == FLIGHT) {
            // fuel bar and hull hearts
            val bw = 120 * d
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(140, 0, 0, 0)
            c.drawRect(16 * d, top - 14 * d, 16 * d + bw, top, uiP)
            uiP.color = if (fuel > 0f) Color.rgb(80, 200, 255) else Color.rgb(229, 57, 53)
            c.drawRect(16 * d, top - 14 * d, 16 * d + bw * (fuel / fuelMax()).coerceIn(0f, 1f), top, uiP)
            leftP.textSize = 14 * d
            c.drawText("⛽", 16 * d + bw + 6 * d, top, leftP)
            leftP.textSize = 20 * d
            for (i in 0 until hullMax()) {
                leftP.color = if (i < hull) Color.rgb(255, 82, 82) else Color.argb(120, 255, 255, 255)
                c.drawText("♥", 16 * d + i * 22 * d, top + 26 * d, leftP)
            }
            leftP.color = Color.WHITE
            val np = nearPlanet()
            if (np != null) {
                leftP.textSize = 14 * d
                val dd = hypot(hypot(sxp - np.x, syp - np.y), szp - np.z) - np.r
                c.drawText(if (np.landable) trf("🪂 Land on %s", np.name) else np.name + "  ${dd.toInt()} m", 16 * d, top + 48 * d, leftP)
            }
            if (fuel <= 0f) {
                textP.textSize = 14 * d
                c.drawText(tr("⛽ Out of fuel! Find blue fuel cells."), w / 2f, h * 0.2f, textP)
            }
            drawRadar(c, w)
            if (t < 7f) {
                textP.textSize = 13 * d
                c.drawText(tr("Left thumb: steer   🔥 boost   🪂 land on planets"), w / 2f, h * 0.3f, textP)
            }
        } else if (mode == SURFACE) {
            leftP.textSize = 14 * d
            c.drawText("💎 ${crystalsBy[curPlanet].count { it.taken }} / ${crystalsBy[curPlanet].size}   ${planets[curPlanet].name}", 16 * d, top, leftP)
            if (hypot(gx, gz) < 6f) {
                textP.textSize = 16 * d
                c.drawText(tr("🚀 Tap to launch"), w / 2f, h * 0.25f, textP)
            }
        }
        if (now < flashUntil) {
            textP.textSize = 22 * d
            c.drawText(flash, w / 2f, h * 0.2f + 30 * d, textP)
        }
        if (mode == FLIGHT) {
            drawButton(c, 0, "🔥", fuel > 0f)
            drawButton(c, 1, "🪂", nearPlanet() != null)
        } else if (mode == SURFACE) {
            drawButton(c, 0, "⬆", true)
            drawButton(c, 1, "🚀", hypot(gx, gz) < 6f)
        }
        if (movePid != -1) {
            val r = 56f * d
            var jx = moveX - moveOx
            var jy = moveY - moveOy
            val len = hypot(jx, jy)
            if (len > r) { jx = jx / len * r; jy = jy / len * r }
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 3 * d
            uiP.color = Color.argb(130, 255, 255, 255)
            c.drawCircle(moveOx, moveOy, r, uiP)
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(170, 255, 255, 255)
            c.drawCircle(moveOx + jx, moveOy + jy, 20f * d, uiP)
        }
    }
}
