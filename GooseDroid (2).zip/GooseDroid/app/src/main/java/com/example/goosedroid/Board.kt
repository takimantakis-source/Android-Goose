package com.example.goosedroid

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Shared outfits and votes, kept on the public ntfy.sh relay (messages stay for about 12 hours). */
object Board {
    private const val TOPIC = "gdroid-v1-looks"
    val SLOTS = listOf("skin", "hat", "face", "neck", "back", "feet")

    class Look(val id: String, val name: String, val ids: List<String>, val time: Long) { var votes = 0 }

    fun voterId(ctx: Context): String {
        val p = Store.prefs(ctx)
        val existing = p.getString("voter_id", null)
        if (existing != null) return existing
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val n = (1..8).map { chars.random() }.joinToString("")
        p.edit().putString("voter_id", n).apply()
        return n
    }

    fun lastShared(ctx: Context): String = Store.prefs(ctx).getString("last_look", "") ?: ""

    /** Publishes the outfit your goose is wearing right now. */
    fun share(ctx: Context) {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val id = (1..6).map { chars.random() }.joinToString("")
        val ids = SLOTS.map { Store.equipped(ctx, it) }
        Ntfy.publish(TOPIC, "LOOK|$id|${Profile.displayName(ctx)}|${ids.joinToString("|")}")
        Store.prefs(ctx).edit().putString("last_look", id).apply()
    }

    fun hasVoted(ctx: Context, id: String) = Store.prefs(ctx).getBoolean("voted_$id", false)

    fun vote(ctx: Context, id: String) {
        Ntfy.publish(TOPIC, "VOTE|$id|${voterId(ctx)}")
        Store.prefs(ctx).edit().putBoolean("voted_$id", true).apply()
    }

    /** Loads the recent looks, most votes first. onDone gets null if the network failed. */
    fun fetch(onDone: (List<Look>?) -> Unit) {
        thread {
            var out: List<Look>? = null
            try {
                val c = URL("https://ntfy.sh/$TOPIC/json?poll=1&since=all").openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 15000
                if (c.responseCode == 200) {
                    val looks = LinkedHashMap<String, Look>()
                    val votes = ArrayList<List<String>>()
                    c.inputStream.bufferedReader().useLines { lines ->
                        for (line in lines) {
                            val j = try { JSONObject(line) } catch (_: Exception) { continue }
                            if (j.optString("event") != "message") continue
                            val p = j.optString("message").split("|")
                            if (p[0] == "LOOK" && p.size >= 9) looks[p[1]] = Look(p[1], p[2].take(20), p.subList(3, 9), j.optLong("time"))
                            else if (p[0] == "VOTE" && p.size >= 3) votes.add(p)
                        }
                    }
                    val seen = HashSet<String>()
                    for (v in votes) {
                        val l = looks[v[1]] ?: continue
                        if (seen.add(v[1] + "|" + v[2])) l.votes++
                    }
                    out = looks.values.sortedWith(compareByDescending<Look> { it.votes }.thenByDescending { it.time })
                }
                c.disconnect()
            } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post { onDone(out) }
        }
    }
}
