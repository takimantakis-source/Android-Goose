package com.example.goosedroid

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Drag items from the tray onto your goose (or tap them), then share the look on the leaderboard. */
class DesignerActivity : Activity() {
    private lateinit var preview: GooseView
    private lateinit var tray: LinearLayout
    private val slotEmoji = mapOf("skin" to "🎨", "hat" to "🎩", "face" to "😎", "neck" to "🎀", "back" to "🎒", "feet" to "👟")

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
        }
        root.addView(TextView(this).apply { text = tr("👗 Outfit Designer"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply {
            text = tr("Drag items onto your goose (or just tap them). Drop on 🗑 to take them off.")
            textSize = 13f
        })

        preview = GooseView(this, 1.6f)
        val drop = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(40, 128, 128, 128))
            addView(preview, FrameLayout.LayoutParams(preview.sizeW, preview.sizeH, Gravity.CENTER))
            setOnDragListener(dropListener(false))
        }
        root.addView(drop, LinearLayout.LayoutParams(-1, dp(260f)).apply { topMargin = dp(8f) })

        val trash = TextView(this).apply {
            text = "🗑"
            textSize = 32f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(45, 229, 57, 53))
            setOnDragListener(dropListener(true))
        }
        root.addView(trash, LinearLayout.LayoutParams(-1, dp(60f)).apply { topMargin = dp(8f) })

        tray = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        root.addView(HorizontalScrollView(this).apply { addView(tray) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8f) })

        val row = LinearLayout(this)
        row.addView(Button(this).apply {
            text = tr("📤 Share my look")
            isAllCaps = false
            setOnClickListener {
                Board.share(this@DesignerActivity)
                Toast.makeText(this@DesignerActivity, tr("Shared! Find it on the leaderboard."), Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = tr("🏆 Leaderboard")
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@DesignerActivity, LeaderboardActivity::class.java)) }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        setContentView(ScrollView(this).apply { addView(root) })
        buildTray()
    }

    private fun dropListener(toTrash: Boolean) = View.OnDragListener { _, ev ->
        if (ev.action == DragEvent.ACTION_DROP) {
            val id = ev.clipData?.getItemAt(0)?.text?.toString()
            val item = if (id != null) Store.byId(id) else null
            if (item != null) {
                if (toTrash) { if (item.slot != "skin") Store.equip(this, item.slot, "") }
                else Store.equip(this, item.slot, item.id)
                refresh()
            }
        }
        true
    }

    private fun refresh() {
        Cosmetics.refresh(this)
        preview.invalidate()
        buildTray()
    }

    private fun buildTray() {
        tray.removeAllViews()
        val dark = ThemeMode.dark(this)
        for (item in Store.items) {
            if (!Store.owned(this, item.id)) continue
            val worn = Store.equipped(this, item.slot) == item.id
            val chip = TextView(this).apply {
                text = (slotEmoji[item.slot] ?: "") + " " + tr(item.name) + if (worn) " ✓" else ""
                textSize = 14f
                setTextColor(if (worn || !dark) Color.BLACK else Color.WHITE)
                setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
                background = GradientDrawable().apply {
                    cornerRadius = dp(18f).toFloat()
                    setColor(if (worn) Color.rgb(255, 213, 79) else if (dark) Color.rgb(70, 74, 84) else Color.rgb(228, 228, 232))
                }
                setOnClickListener {
                    if (worn) { if (item.slot != "skin") Store.equip(this@DesignerActivity, item.slot, "") }
                    else Store.equip(this@DesignerActivity, item.slot, item.id)
                    refresh()
                }
                setOnLongClickListener { v ->
                    v.startDragAndDrop(ClipData.newPlainText("item", item.id), View.DragShadowBuilder(v), null, 0)
                    true
                }
            }
            tray.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8f) })
        }
    }
}
