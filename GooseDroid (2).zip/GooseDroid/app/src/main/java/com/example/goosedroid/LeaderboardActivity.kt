package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LeaderboardActivity : Activity() {
    private lateinit var box: LinearLayout
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        }
        root.addView(TextView(this).apply { text = tr("🏆 Outfit Leaderboard"); textSize = 26f })
        root.addView(TextView(this).apply {
            text = tr("Outfits shared by players in the last hours. Vote for your favorites!")
            textSize = 13f
            setPadding(0, dp(4f), 0, dp(8f))
        })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(box)
        setContentView(ScrollView(this).apply { addView(root) })
        load()
    }

    private fun msg(s: String) {
        box.removeAllViews()
        box.addView(TextView(this).apply { text = s; textSize = 15f; setPadding(0, dp(12f), 0, 0) })
    }

    private fun load() {
        msg(tr("Loading..."))
        Board.fetch { list ->
            if (isFinishing) return@fetch
            when {
                list == null -> msg(tr("Couldn't load the leaderboard. Check your internet."))
                list.isEmpty() -> msg(tr("No outfits shared yet. Be the first!"))
                else -> show(list)
            }
        }
    }

    private fun show(list: List<Board.Look>) {
        box.removeAllViews()
        val mine = Board.lastShared(this)
        for ((rank, look) in list.take(40).withIndex()) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val g = GooseView(this, 0.5f).apply {
                fixedLook = true
                lookSkin = look.ids[0].ifEmpty { "skin_classic" }
                lookHat = look.ids[1]; lookFace = look.ids[2]; lookNeck = look.ids[3]
                lookBack = look.ids[4]; lookFeet = look.ids[5]
            }
            row.addView(g, LinearLayout.LayoutParams(g.sizeW, g.sizeH))
            row.addView(TextView(this).apply {
                text = "#${rank + 1}  ${look.name}"
                textSize = 16f
                setPadding(dp(8f), 0, dp(8f), 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            val btn = Button(this)
            btn.text = "👍 ${look.votes}"
            btn.isEnabled = !Board.hasVoted(this, look.id) && look.id != mine
            btn.setOnClickListener {
                Board.vote(this, look.id)
                look.votes++
                btn.text = "👍 ${look.votes}"
                btn.isEnabled = false
            }
            row.addView(btn)
            box.addView(row)
        }
    }
}
