package com.example.goosedroid

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast

/** Live Mode: a room code on the public ntfy.sh relay. The streamer's score goes out live, viewers send honks back. */
object Live {
    var code: String? = null
        private set
    val cheers = ArrayList<String>()
    var listener: (() -> Unit)? = null

    private var sub: Ntfy.Sub? = null
    private var last = 0L
    private val main = Handler(Looper.getMainLooper())

    fun topic(c: String) = "gdroid-v1-live-$c"

    fun start(): String {
        stop()
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val c = (1..5).map { chars.random() }.joinToString("")
        code = c
        cheers.clear()
        sub = Ntfy.subscribe(topic(c), "5s") { m -> onMsg(m) }
        return c
    }

    fun stop() {
        sub?.close()
        sub = null
        code = null
    }

    /** Called by the games all the time; sends the score at most every 5 seconds while broadcasting. */
    fun pulse(game: String, score: Int) {
        val c = code ?: return
        val a = Store.app ?: return
        val now = SystemClock.uptimeMillis()
        if (now - last < 5000L) return
        last = now
        Ntfy.publish(topic(c), "ST|${Profile.displayName(a)}|$game|$score")
    }

    private fun onMsg(m: String) {
        val p = m.split("|")
        if (p[0] == "HONK" && p.size >= 2) {
            main.post {
                val a = Store.app ?: return@post
                cheers.add(0, p[1])
                if (cheers.size > 30) cheers.removeAt(cheers.size - 1)
                Sound.honk()
                Toast.makeText(a, "📢 ${p[1]}", Toast.LENGTH_SHORT).show()
                listener?.invoke()
            }
        }
    }

    fun gameTitle(key: String): String = when (key) {
        "catch" -> tr("🪿 Catch the Goose")
        "bread" -> tr("🍞 Bread Catch")
        "simon" -> tr("🎵 Honk Memory")
        "flappy" -> tr("🌾 Flappy Goose")
        "whack" -> tr("🦊 Whack-a-Goose")
        "hunt" -> tr("🔎 Goose Hunt")
        "obby" -> tr("🏃 Goose Obby")
        "shove" -> tr("🏢 Goose Shove")
        "astro" -> tr("🚀 Goose Astronaut")
        else -> key
    }
}
