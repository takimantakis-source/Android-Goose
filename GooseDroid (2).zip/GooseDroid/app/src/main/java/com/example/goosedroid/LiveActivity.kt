package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LiveActivity : Activity() {
    private lateinit var root: LinearLayout
    private var watchSub: Ntfy.Sub? = null
    private var watchCode = ""
    private var status = ""
    private var lastHonk = 0L

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(14f), dp(18f), dp(14f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    override fun onResume() {
        super.onResume()
        Live.listener = { runOnUiThread { if (watchCode.isEmpty()) render() } }
    }

    override fun onPause() {
        Live.listener = null
        super.onPause()
    }

    override fun onDestroy() {
        watchSub?.close()
        super.onDestroy()
    }

    private fun tv(t: String, size: Float) = TextView(this).apply {
        text = t; textSize = size
        setPadding(0, dp(6f), 0, dp(6f))
    }

    private fun render() {
        root.removeAllViews()
        root.addView(tv(tr("📡 Live Mode"), 26f))
        root.addView(tv(tr("Broadcast your game: friends watch your score live and cheer with honks. (Live scores and honks, not video.)"), 13f))
        val code = Live.code
        if (watchCode.isNotEmpty()) {
            watchView()
        } else if (code != null) {
            root.addView(tv(tr("Your room code:"), 15f))
            root.addView(tv(code.uppercase(), 40f).apply { gravity = Gravity.CENTER })
            root.addView(tv(tr("Play any minigame now. Your friends see your score!"), 14f))
            root.addView(tv(tr("Cheers"), 18f))
            if (Live.cheers.isEmpty()) root.addView(tv("…", 14f))
            for (c in Live.cheers.take(12)) root.addView(tv("📢 $c", 15f))
            root.addView(Button(this).apply { text = tr("Stop broadcasting"); setOnClickListener { Live.stop(); render() } })
        } else {
            root.addView(Button(this).apply { text = tr("📡 Start broadcasting"); setOnClickListener { Live.start(); render() } })
            root.addView(tv(tr("Watch a friend"), 18f))
            val et = EditText(this).apply { hint = tr("Room code"); inputType = InputType.TYPE_CLASS_TEXT; isSingleLine = true }
            root.addView(et)
            root.addView(Button(this).apply {
                text = tr("👀 Watch a friend")
                setOnClickListener {
                    val c = et.text.toString().trim().lowercase()
                    if (c.length >= 4) startWatching(c)
                }
            })
        }
    }

    private fun startWatching(c: String) {
        watchCode = c
        status = tr("Waiting for the streamer...")
        watchSub = Ntfy.subscribe(Live.topic(c), "30s") { m ->
            val p = m.split("|")
            if (p[0] == "ST" && p.size >= 4) {
                runOnUiThread {
                    status = trf("%s is playing %s: %d points", p[1], Live.gameTitle(p[2]), p[3].toIntOrNull() ?: 0)
                    if (watchCode.isNotEmpty()) render()
                }
            }
        }
        render()
    }

    private fun watchView() {
        root.addView(tv(status, 18f))
        root.addView(Button(this).apply {
            text = tr("📢 Honk!")
            textSize = 22f
            setOnClickListener {
                val now = SystemClock.uptimeMillis()
                if (now - lastHonk > 1500L) {
                    lastHonk = now
                    Ntfy.publish(Live.topic(watchCode), "HONK|${Profile.displayName(this@LiveActivity)}")
                    Sound.honk()
                }
            }
        }, LinearLayout.LayoutParams(-1, dp(90f)))
        root.addView(Button(this).apply {
            text = tr("Leave")
            setOnClickListener { watchSub?.close(); watchSub = null; watchCode = ""; render() }
        })
    }
}
