package com.example.goosedroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.security.MessageDigest

/** A profile that lives on this phone: email, username, password (stored only as a hash) and a profile picture. */
object Profile {
    private fun p(ctx: Context) = Store.prefs(ctx)

    fun email(ctx: Context): String = p(ctx).getString("acc_email", "") ?: ""
    fun username(ctx: Context): String = p(ctx).getString("acc_name", "") ?: ""
    fun hasAccount(ctx: Context) = email(ctx).isNotBlank()
    fun signedIn(ctx: Context) = hasAccount(ctx) && p(ctx).getBoolean("acc_in", false)

    /** The name other players see: your username, or the random goose nickname. */
    fun displayName(ctx: Context): String = username(ctx).ifBlank { Store.nick(ctx) }

    private fun hash(pw: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray()).joinToString("") { "%02x".format(it) }

    private fun nameError(n: String): String? =
        if (!Regex("^[A-Za-z0-9_]{3,16}$").matches(n)) tr("Username: 3-16 letters, numbers or _.") else null

    /** Returns null on success, otherwise a (translated) message. */
    fun signUp(ctx: Context, email: String, name: String, pw: String): String? {
        val e = email.trim().lowercase()
        val n = name.trim()
        if (!Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$").matches(e)) return tr("Please enter a valid email address.")
        nameError(n)?.let { return it }
        if (pw.length < 6) return tr("Password: at least 6 characters.")
        val salt = (1..8).map { "abcdef0123456789".random() }.joinToString("")
        p(ctx).edit()
            .putString("acc_email", e).putString("acc_name", n)
            .putString("acc_salt", salt).putString("acc_hash", hash(pw, salt))
            .putBoolean("acc_in", true).apply()
        return null
    }

    fun signIn(ctx: Context, email: String, pw: String): Boolean {
        val sp = p(ctx)
        val ok = email.trim().lowercase() == email(ctx) &&
            hash(pw, sp.getString("acc_salt", "") ?: "") == sp.getString("acc_hash", "")
        if (ok) sp.edit().putBoolean("acc_in", true).apply()
        return ok
    }

    fun signOut(ctx: Context) { p(ctx).edit().putBoolean("acc_in", false).apply() }

    fun delete(ctx: Context) {
        p(ctx).edit().remove("acc_email").remove("acc_name").remove("acc_salt").remove("acc_hash").putBoolean("acc_in", false).apply()
        avatarFile(ctx).delete()
    }

    fun rename(ctx: Context, name: String): String? {
        val n = name.trim()
        nameError(n)?.let { return it }
        p(ctx).edit().putString("acc_name", n).apply()
        return null
    }

    private fun avatarFile(ctx: Context) = File(ctx.filesDir, "avatar.png")

    fun avatar(ctx: Context): Bitmap? = try { BitmapFactory.decodeFile(avatarFile(ctx).path) } catch (_: Exception) { null }

    fun saveAvatar(ctx: Context, src: Bitmap) {
        val s = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        avatarFile(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
