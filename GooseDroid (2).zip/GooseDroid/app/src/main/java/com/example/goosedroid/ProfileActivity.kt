package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Create an account on this phone, then pick a username and a profile picture. */
class ProfileActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private val placeholder: Bitmap by lazy {
        val b = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(200, 220, 240))
        c.drawText("🪿", 128f, 170f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 140f; textAlign = Paint.Align.CENTER })
        b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(16f), dp(20f), dp(16f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(8f), 0, dp(4f))
    }

    private fun field(hint: String, type: Int) = EditText(this).apply {
        this.hint = hint
        inputType = type
        isSingleLine = true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun render() {
        root.removeAllViews()
        root.addView(tv(tr("👤 Profile"), 26f, true))

        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            clipToOutline = true
            setImageBitmap(Profile.avatar(this@ProfileActivity) ?: placeholder)
        }
        root.addView(img, LinearLayout.LayoutParams(dp(120f), dp(120f)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8f) })

        if (Profile.signedIn(this)) {
            root.addView(tv(Profile.username(this), 22f, true).apply { gravity = Gravity.CENTER })
            root.addView(tv(Profile.email(this), 14f).apply { gravity = Gravity.CENTER })
            root.addView(Button(this).apply {
                text = tr("Change profile picture")
                setOnClickListener {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 31
                    )
                }
            })
            root.addView(Button(this).apply { text = tr("Change username"); setOnClickListener { renameDialog() } })
            root.addView(Button(this).apply { text = tr("Sign out"); setOnClickListener { Profile.signOut(this@ProfileActivity); render() } })
            root.addView(Button(this).apply { text = tr("Delete account"); setOnClickListener { confirmDelete() } })
        } else if (Profile.hasAccount(this)) {
            val e = field(tr("Email"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
            val pw = field(tr("Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            root.addView(e); root.addView(pw)
            root.addView(Button(this).apply {
                text = tr("Sign in")
                setOnClickListener {
                    if (Profile.signIn(this@ProfileActivity, e.text.toString(), pw.text.toString())) render()
                    else toast(tr("Wrong email or password."))
                }
            })
            root.addView(Button(this).apply { text = tr("Delete account"); setOnClickListener { confirmDelete() } })
        } else {
            val e = field(tr("Email"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
            val n = field(tr("Username"), InputType.TYPE_CLASS_TEXT)
            val pw = field(tr("Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
            root.addView(e); root.addView(n); root.addView(pw)
            root.addView(Button(this).apply {
                text = tr("Create account")
                setOnClickListener {
                    val err = Profile.signUp(this@ProfileActivity, e.text.toString(), n.text.toString(), pw.text.toString())
                    if (err != null) toast(err) else render()
                }
            })
        }
        root.addView(tv(tr("Your account is stored on this phone only. Other players see your username, not your email."), 12f))
    }

    private fun renameDialog() {
        val et = EditText(this)
        et.setText(Profile.username(this))
        AlertDialog.Builder(this)
            .setTitle(tr("Change username"))
            .setView(et)
            .setPositiveButton(tr("Save")) { _, _ ->
                val err = Profile.rename(this, et.text.toString())
                if (err != null) toast(err)
                render()
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(tr("Delete account"))
            .setPositiveButton(tr("Delete")) { _, _ -> Profile.delete(this); render() }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 31 && res == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                val o2 = BitmapFactory.Options().apply { inSampleSize = maxOf(1, minOf(o.outWidth, o.outHeight) / 512) }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                if (bmp != null) Profile.saveAvatar(this, bmp)
            } catch (_: Exception) {}
            render()
        }
    }
}
