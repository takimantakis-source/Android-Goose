package com.example.goosedroid

import android.content.Context
import android.os.Handler
import android.os.Looper

/** Goofy synthesized sound effects, and the in-app actions that can trigger them. */
object Soundboard {
    private class Seq(val f0: Double, val f1: Double, val ms: Int, val wave: Int, val vib: Double, val at: Long)

    val IDS = listOf("honk", "squeak", "boing", "laser", "sad", "tada", "coin", "quack", "whistle", "fall", "wah")

    fun nameOf(id: String): String = when (id) {
        "honk" -> tr("Honk")
        "squeak" -> tr("Squeak")
        "boing" -> tr("Boing")
        "laser" -> tr("Laser")
        "sad" -> tr("Sad trombone")
        "tada" -> tr("Ta-da!")
        "coin" -> tr("Coin")
        "quack" -> tr("Quack")
        "whistle" -> tr("Slide whistle")
        "fall" -> tr("Cartoon fall")
        else -> tr("Wah-wah")
    }

    private val defs: Map<String, List<Seq>> = mapOf(
        "squeak" to listOf(Seq(900.0, 1500.0, 140, 1, 0.0, 0)),
        "boing" to listOf(Seq(180.0, 500.0, 200, 2, 0.0, 0), Seq(500.0, 150.0, 260, 2, 0.0, 200)),
        "laser" to listOf(Seq(1800.0, 200.0, 250, 0, 0.0, 0)),
        "sad" to listOf(
            Seq(233.0, 220.0, 300, 1, 0.0, 0), Seq(220.0, 208.0, 300, 1, 0.0, 320),
            Seq(208.0, 196.0, 300, 1, 0.0, 640), Seq(196.0, 110.0, 700, 0, 25.0, 960)
        ),
        "tada" to listOf(Seq(523.0, 523.0, 120, 1, 0.0, 0), Seq(659.0, 659.0, 120, 1, 0.0, 130), Seq(784.0, 784.0, 420, 1, 0.0, 260)),
        "coin" to listOf(Seq(988.0, 988.0, 70, 1, 0.0, 0), Seq(1319.0, 1319.0, 300, 1, 0.0, 80)),
        "quack" to listOf(Seq(420.0, 300.0, 120, 0, 40.0, 0), Seq(420.0, 300.0, 120, 0, 40.0, 160)),
        "whistle" to listOf(Seq(300.0, 1500.0, 500, 2, 0.0, 0)),
        "fall" to listOf(Seq(1200.0, 100.0, 700, 2, 80.0, 0)),
        "wah" to listOf(Seq(350.0, 300.0, 300, 1, 30.0, 0), Seq(300.0, 250.0, 400, 1, 30.0, 330))
    )

    private val handler = Handler(Looper.getMainLooper())

    fun play(id: String) {
        if (id == "honk") { Sound.honk(); return }
        val d = defs[id] ?: return
        for (s in d) {
            if (s.at == 0L) Sound.play(s.f0, s.f1, s.ms, s.wave, s.vib)
            else handler.postDelayed({ Sound.play(s.f0, s.f1, s.ms, s.wave, s.vib) }, s.at)
        }
    }

    // ----- in-app actions that can play a sound -----
    val EVENTS = listOf("game_win", "game_over", "buy", "daily", "start")

    fun eventName(e: String): String = when (e) {
        "game_win" -> tr("When I win a game")
        "game_over" -> tr("When a game ends badly")
        "buy" -> tr("When I buy something")
        "daily" -> tr("When I claim the daily reward")
        else -> tr("When the app opens")
    }

    private fun defaultFor(e: String) = when (e) {
        "game_win" -> "tada"
        "game_over" -> "sad"
        "buy" -> "coin"
        "daily" -> "tada"
        else -> ""
    }

    fun assigned(ctx: Context, e: String): String = Store.prefs(ctx).getString("sb_$e", defaultFor(e)) ?: ""
    fun assign(ctx: Context, e: String, id: String) { Store.prefs(ctx).edit().putString("sb_$e", id).apply() }

    private var started = false

    fun trigger(event: String) {
        val a = Store.app ?: return
        if (event == "start") { if (started) return; started = true }
        val id = assigned(a, event)
        if (id.isNotEmpty()) play(id)
    }
}
