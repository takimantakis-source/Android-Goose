package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SoundboardActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply { text = tr("🔊 Goose Soundboard"); textSize = 26f })
        root.addView(TextView(this).apply { text = tr("Tap a button to play it."); textSize = 13f; setPadding(0, dp(4f), 0, dp(8f)) })
        for (chunk in Soundboard.IDS.chunked(3)) {
            val row = LinearLayout(this)
            for (id in chunk) {
                row.addView(Button(this).apply {
                    text = Soundboard.nameOf(id)
                    isAllCaps = false
                    setOnClickListener { Soundboard.play(id) }
                }, LinearLayout.LayoutParams(0, dp(64f), 1f))
            }
            root.addView(row)
        }

        root.addView(TextView(this).apply { text = tr("Special actions"); textSize = 20f; setPadding(0, dp(18f), 0, dp(4f)) })
        root.addView(TextView(this).apply { text = tr("Pick a sound that plays when this happens in the app."); textSize = 13f })
        for (e in Soundboard.EVENTS) {
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = Soundboard.eventName(e); textSize = 15f }, LinearLayout.LayoutParams(0, -2, 1f))
            val cur = Soundboard.assigned(this, e)
            row.addView(Button(this).apply {
                text = if (cur.isEmpty()) tr("None") else Soundboard.nameOf(cur)
                isAllCaps = false
                setOnClickListener { choose(e) }
            })
            root.addView(row)
        }
    }

    private fun choose(e: String) {
        val ids = listOf("") + Soundboard.IDS
        val names = ids.map { if (it.isEmpty()) tr("None") else Soundboard.nameOf(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(Soundboard.eventName(e)).setItems(names) { _, i ->
            Soundboard.assign(this, e, ids[i])
            if (ids[i].isNotEmpty()) Soundboard.play(ids[i])
            render()
        }.show()
    }
}
