package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.random.Random

/** A tiny daily adventure: 9 places, 3 digs, and clues that change every day. */
class TreasureActivity : Activity() {
    private val places = arrayOf("🌲", "🏠", "🌊", "⛰️", "🌾", "🪨", "🌳", "🛖", "⛲")
    private val today = java.time.LocalDate.now().toEpochDay()
    private val target = Random(today * 31 + 7).nextInt(9)
    private lateinit var root: LinearLayout
    private var digs = 0
    private var dug = ArrayList<Int>()
    private var found = false
    private var message = ""

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun rowName(i: Int) = when (i) { 0 -> tr("top"); 1 -> tr("middle"); else -> tr("bottom") }
    private fun colName(i: Int) = when (i) { 0 -> tr("left"); 1 -> tr("middle"); else -> tr("right") }

    private fun placeHint(i: Int) = when (i) {
        0 -> tr("Hidden under pine needles.")
        1 -> tr("Buried by the old barn.")
        2 -> tr("Wet feathers! It's by the water.")
        3 -> tr("High up on the hill.")
        4 -> tr("Somewhere in the golden field.")
        5 -> tr("Between the big rocks.")
        6 -> tr("Under the old oak.")
        7 -> tr("Near a little hut.")
        else -> tr("Close to the fountain.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val p = Store.prefs(this)
        if (p.getLong("tr_day", -1L) != today) {
            p.edit().putLong("tr_day", today).putInt("tr_digs", 0).putString("tr_dug", "").putBoolean("tr_found", false).apply()
        }
        digs = p.getInt("tr_digs", 0)
        dug = ArrayList((p.getString("tr_dug", "") ?: "").split(",").filter { it.isNotEmpty() }.map { it.toInt() })
        found = p.getBoolean("tr_found", false)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(16f), dp(20f), dp(16f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun finished() = found || digs >= 3

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply { text = tr("🗺 Goose Treasure Hunt"); textSize = 26f })
        root.addView(TextView(this).apply {
            text = tr("Dig for the treasure! New clues every day. You have 3 digs.")
            textSize = 14f
            setPadding(0, dp(6f), 0, dp(10f))
        })

        val shown = if (finished()) 3 else minOf(3, digs + 1)
        val clues = listOf(
            trf("The treasure is in the %s row.", rowName(target / 3)),
            trf("The treasure is in the %s column.", colName(target % 3)),
            placeHint(target)
        )
        for (i in 0 until shown) {
            root.addView(TextView(this).apply { text = "🔎 " + clues[i]; textSize = 16f; setPadding(0, dp(4f), 0, dp(4f)) })
        }
        root.addView(TextView(this).apply {
            text = trf("Digs left: %d", if (found) 0 else 3 - digs)
            textSize = 15f
            setPadding(0, dp(10f), 0, dp(6f))
        })

        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for (c in 0 until 3) {
                val i = r * 3 + c
                row.addView(Button(this).apply {
                    text = if (dug.contains(i)) (if (i == target) "💰" else "🕳") else places[i]
                    textSize = 30f
                    isEnabled = !finished() && !dug.contains(i)
                    setOnClickListener { dig(i) }
                }, LinearLayout.LayoutParams(0, dp(90f), 1f))
            }
            root.addView(row)
        }
        if (message.isNotEmpty()) {
            root.addView(TextView(this).apply { text = message; textSize = 18f; setPadding(0, dp(12f), 0, 0) })
        }
        if (finished()) {
            if (!found) root.addView(TextView(this).apply { text = trf("The treasure was here: %s", places[target]); textSize = 16f })
            root.addView(TextView(this).apply { text = tr("Come back tomorrow for new clues!"); textSize = 14f; setPadding(0, dp(8f), 0, 0) })
        }
    }

    private fun dig(i: Int) {
        digs++
        dug.add(i)
        if (i == target) {
            found = true
            val coins = when (digs) { 1 -> 150; 2 -> 100; else -> 50 }
            Store.addCoins(this, coins)
            message = trf("You found the treasure! +%d coins 🪙", coins)
            Soundboard.play("tada")
        } else {
            Store.addCoins(this, 5)
            message = trf("Nothing here... +%d coins", 5)
            Sound.play(200.0, 120.0, 150)
        }
        Store.prefs(this).edit().putInt("tr_digs", digs).putString("tr_dug", dug.joinToString(",")).putBoolean("tr_found", found).apply()
        render()
    }
}
