package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class GameActivity : Activity() {
    private var game: BaseGame? = null
    private var versus: Versus? = null
    private val handle = Matchmaker.Handle()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this, true)
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val key = intent.getStringExtra("game") ?: "catch"

        if (!intent.getBooleanExtra("online", false)) { launch(key, null); return }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(TextView(this@GameActivity).apply {
                text = tr("🌐 Searching for players...\n\nIf nobody is online you'll face a bot.")
                textSize = 20f
                gravity = Gravity.CENTER
            })
            addView(Button(this@GameActivity).apply {
                text = tr("Cancel")
                setOnClickListener { handle.cancelled = true; finish() }
            })
        }
        setContentView(box)

        val best = Store.prefs(this).getInt(key, 0)
        Matchmaker.find(key, Store.nick(this), best, handle) { v ->
            runOnUiThread {
                if (isFinishing || isDestroyed) v.close() else { versus = v; launch(key, v) }
            }
        }
    }

    private fun launch(key: String, v: Versus?) {
        val exit: () -> Unit = { finish() }
        val g = when (key) {
            "catch" -> CatchGame(this, v, exit)
            "bread" -> BreadGame(this, v, exit)
            "flappy" -> FlappyGame(this, v, exit)
            "whack" -> WhackGame(this, v, exit)
            "hunt" -> HuntGame(this, v, exit, intent.getIntExtra("map", 0), intent.getIntExtra("minutes", 10))
            "obby" -> ObbyGame(this, v, exit)
            else -> SimonGame(this, v, exit)
        }
        game = g
        setContentView(g)
    }

    override fun onBackPressed() {
        val g = game
        if (g != null && g.isRunning()) g.finishNow() else super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        game?.abandon()
        finish() // leaving the app ends the round
    }

    override fun onDestroy() {
        handle.cancelled = true
        game?.end()
        versus?.close()
        super.onDestroy()
    }
}
