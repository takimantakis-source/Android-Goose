package com.example.goosedroid

import android.annotation.SuppressLint
import android.content.Context
import android.os.SystemClock
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/** Game 1: tap the goose as many times as you can in 30 seconds. It gets faster every catch. */
class CatchGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "catch", versus, onExit) {
    override fun currentScore() = score
    private val goose = GooseView(ctx)
    private var gx = 0f
    private var gy = 0f
    private var tx = 0f
    private var ty = 0f
    private var score = 0
    private var endAt = 0L

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouch() {
        goose.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) hit()
            true
        }
    }

    init {
        addView(goose, FrameLayout.LayoutParams(goose.sizeW, goose.sizeH))
        setupTouch()
    }

    override fun reset() {
        score = 0
        gx = (width - goose.sizeW) / 2f
        gy = (height - goose.sizeH) / 2f
        pick()
        endAt = SystemClock.uptimeMillis() + 30_000
        place()
    }

    private fun pick() {
        tx = Random.nextFloat() * (width - goose.sizeW)
        ty = Random.nextFloat() * (height - goose.sizeH)
    }

    private fun hit() {
        score++
        Sound.honk()
        goose.bubble = "HONK!"
        handler.postDelayed({ goose.bubble = null; goose.invalidate() }, 400)
        pick()
    }

    override fun tick() {
        val left = endAt - SystemClock.uptimeMillis()
        if (left <= 0) { gameOver("You caught the goose $score times!", score); return }
        hud.text = "Score: $score     Time: ${left / 1000 + 1}"

        val dx = tx - gx
        val dy = ty - gy
        val dist = hypot(dx, dy)
        if (dist < 10 * d) {
            pick()
        } else {
            val sp = (3.5f + score * 0.35f).coerceAtMost(14f) * d
            gx += dx / dist * sp
            gy += dy / dist * sp
        }
        if (abs(dx) > 2) goose.facingLeft = dx < 0
        goose.walking = true
        goose.phase += 0.45f
        place()
    }

    private fun place() {
        goose.x = gx
        goose.y = gy
        goose.invalidate()
    }
}
