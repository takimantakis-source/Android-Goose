package com.example.goosedroid

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Draws the goose with plain Canvas shapes, wearing whatever skin/accessories are equipped. */
class GooseView(context: Context) : View(context) {
    var facingLeft = false
    var walking = false
    var phase = 0f
    var bubble: String? = null

    private val d = resources.displayMetrics.density
    val sizeW = (110 * d).toInt()
    val sizeH = (130 * d).toInt() // extra 20dp on top for the speech bubble / tall hats

    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun stroke(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val white = fill(Color.WHITE)
    private val orange = fill(Color.rgb(255, 140, 0))
    private val black = fill(Color.BLACK)
    private val outline = stroke(Color.rgb(80, 80, 80), 1.3f)
    private val neckOutline = stroke(Color.rgb(80, 80, 80), 11f)
    private val neckWhite = stroke(Color.WHITE, 8.6f)
    private val legs = stroke(Color.rgb(255, 140, 0), 2.6f)
    private val acc = fill(Color.BLACK)
    private val accLine = stroke(Color.BLACK, 1.5f)
    private val bubbleFill = fill(Color.WHITE)
    private val bubbleLine = stroke(Color.DKGRAY, 2f * d)
    private val bubbleText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; textSize = 13 * d; typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private val red = Color.rgb(229, 57, 53)
    private val gold = Color.rgb(255, 193, 7)

    init { Cosmetics.refresh(context) }

    private fun poly(c: Canvas, color: Int, vararg pts: Float) {
        val p = Path()
        p.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) { p.lineTo(pts[i], pts[i + 1]); i += 2 }
        p.close()
        acc.color = color
        c.drawPath(p, acc); c.drawPath(p, outline)
    }

    private fun oval(c: Canvas, color: Int, l: Float, t: Float, r: Float, b: Float) {
        acc.color = color
        val rc = RectF(l, t, r, b)
        c.drawOval(rc, acc); c.drawOval(rc, outline)
    }

    private fun box(c: Canvas, color: Int, l: Float, t: Float, r: Float, b: Float) {
        acc.color = color
        val rc = RectF(l, t, r, b)
        c.drawRect(rc, acc); c.drawRect(rc, outline)
    }

    private fun line(c: Canvas, color: Int, w: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
        accLine.color = color; accLine.strokeWidth = w
        c.drawLine(x1, y1, x2, y2, accLine)
    }

    override fun onDraw(c: Canvas) {
        white.color = Cosmetics.body
        neckWhite.color = Cosmetics.body
        orange.color = Cosmetics.beak
        legs.color = Cosmetics.beak

        bubble?.let {
            val r = RectF(width * 0.12f, 1 * d, width * 0.88f, 20 * d)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleFill)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleLine)
            c.drawText(it, r.centerX(), r.centerY() + 5 * d, bubbleText)
        }

        c.save()
        c.translate(0f, (height - width).toFloat())
        val s = width / 100f
        c.scale(s, s)
        if (facingLeft) c.scale(-1f, 1f, 50f, 50f)
        if (walking) c.translate(0f, -abs(sin(phase)) * 2f)

        // legs + feet
        val step = if (walking) sin(phase) * 5f else 0f
        for (fx in floatArrayOf(42f + step, 54f - step)) {
            c.drawLine(fx, 80f, fx, 91f, legs)
            c.drawOval(RectF(fx - 6f, 89f, fx + 6f, 95f), orange)
        }
        // tail
        val tail = Path().apply { moveTo(24f, 66f); lineTo(6f, 56f); lineTo(26f, 78f); close() }
        c.drawPath(tail, white); c.drawPath(tail, outline)
        // body + wing
        val body = RectF(20f, 56f, 72f, 88f)
        c.drawOval(body, white); c.drawOval(body, outline)
        c.drawArc(RectF(30f, 62f, 62f, 82f), 10f, 150f, false, outline)
        // neck
        c.drawLine(62f, 64f, 72f, 36f, neckOutline)
        c.drawLine(62f, 64f, 72f, 36f, neckWhite)

        // neck accessory
        when (Cosmetics.neck) {
            "neck_bowtie" -> {
                poly(c, red, 67f, 50f, 58f, 45f, 58f, 55f)
                poly(c, red, 67f, 50f, 76f, 45f, 76f, 55f)
                oval(c, Color.rgb(150, 20, 20), 65f, 48f, 69f, 52f)
            }
            "neck_scarf" -> {
                line(c, red, 5f, 60f, 55f, 71f, 52f)
                line(c, red, 4f, 62f, 56f, 60f, 68f)
            }
            "neck_medal" -> {
                line(c, Color.rgb(30, 100, 200), 1.6f, 65f, 48f, 65f, 54f)
                oval(c, gold, 61.5f, 53f, 68.5f, 60f)
            }
        }

        // head, beak, eye
        c.drawCircle(74f, 30f, 9f, white); c.drawCircle(74f, 30f, 9f, outline)
        val beak = Path().apply { moveTo(81f, 27f); lineTo(96f, 32f); lineTo(81f, 37f); close() }
        c.drawPath(beak, orange); c.drawPath(beak, outline)
        c.drawCircle(77f, 27f, 2f, black)

        // face accessory
        when (Cosmetics.face) {
            "face_shades" -> {
                box(c, Color.BLACK, 72f, 24f, 84f, 30.5f)
                line(c, Color.BLACK, 1.6f, 72f, 26f, 65f, 27f)
            }
            "face_monocle" -> {
                accLine.color = gold; accLine.strokeWidth = 1.3f
                c.drawCircle(77.5f, 27f, 4.6f, accLine)
                line(c, gold, 0.8f, 77.5f, 31.6f, 75f, 44f)
            }
            "face_stache" -> line(c, Color.rgb(93, 64, 55), 3.2f, 80f, 38.5f, 91f, 35.5f)
        }

        // hat
        when (Cosmetics.hat) {
            "hat_halo" -> {
                accLine.color = gold; accLine.strokeWidth = 2.2f
                c.drawOval(RectF(65f, 9f, 83f, 15f), accLine)
            }
            "hat_party" -> {
                poly(c, Color.rgb(233, 30, 99), 67f, 22f, 81f, 22f, 74f, 1f)
                oval(c, Color.rgb(255, 235, 59), 71.5f, -1.5f, 76.5f, 3.5f)
            }
            "hat_cowboy" -> {
                val brown = Color.rgb(141, 110, 99)
                oval(c, brown, 58f, 17f, 90f, 25f)
                poly(c, brown, 67f, 19f, 69f, 8f, 79f, 8f, 81f, 19f)
            }
            "hat_top" -> {
                box(c, Color.rgb(33, 33, 33), 66f, 3f, 82f, 21f)
                box(c, Color.rgb(33, 33, 33), 61f, 19f, 87f, 24f)
                box(c, red, 66f, 15f, 82f, 18f)
            }
            "hat_crown" -> poly(c, gold, 66f, 22f, 66f, 9f, 70f, 15f, 74f, 6f, 78f, 15f, 82f, 9f, 82f, 22f)
        }
        c.restore()
    }
}
