package com.example.goosedroid

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class MusicActivity : Activity() {
    private var list: List<Player.Track> = emptyList()
    private lateinit var listView: ListView
    private lateinit var info: TextView
    private lateinit var nowText: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var shuffleBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false

    private val ticker = object : Runnable {
        override fun run() { progress(); handler.postDelayed(this, 500) }
    }

    private val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "🎵 Music"; textSize = 26f })
        info = TextView(this).apply { text = "Loading your music..."; textSize = 14f }
        root.addView(info)
        listView = ListView(this)
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))

        nowText = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(0, pad, 0, 0) }
        root.addView(nowText)
        seek = SeekBar(this)
        root.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                Player.seekTo(seek.progress * 1000)
            }
        })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        row.addView(btn("⏮") { Player.prev() })
        playBtn = btn("▶") {
            if (Player.index < 0 && list.isNotEmpty()) { Player.tracks = list; Player.play(this, 0) }
            else Player.toggle()
        }
        row.addView(playBtn)
        row.addView(btn("⏭") { Player.next() })
        shuffleBtn = btn("🔀 Off") { Player.shuffle = !Player.shuffle; refresh() }
        row.addView(shuffleBtn)
        root.addView(row)
        setContentView(root)

        listView.setOnItemClickListener { _, _, pos, _ ->
            Player.tracks = list
            Player.play(this, pos)
        }

        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(permission), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) load()
        else info.text = "GooseDroid needs permission to read your music files."
    }

    private fun load() {
        thread {
            val out = ArrayList<Player.Track>()
            val media = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
            )
            try {
                contentResolver.query(
                    media, proj,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000",
                    null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        out.add(
                            Player.Track(
                                ContentUris.withAppendedId(media, c.getLong(0)),
                                c.getString(1) ?: "Unknown", c.getString(2) ?: "", c.getLong(3)
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread { show(out) }
        }
    }

    private fun show(tracks: List<Player.Track>) {
        list = tracks
        if (Player.tracks.isEmpty() || Player.index < 0) Player.tracks = tracks
        info.text = if (tracks.isEmpty()) "No music files found on this device." else "${tracks.size} songs - tap one to play"
        val names = tracks.map { if (it.artist.isBlank() || it.artist == "<unknown>") it.title else "${it.title} - ${it.artist}" }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
    }

    private fun refresh() {
        val t = Player.current
        nowText.text = if (t == null) "Nothing playing" else t.title
        playBtn.text = if (Player.isPlaying) "⏸" else "▶"
        shuffleBtn.text = if (Player.shuffle) "🔀 On" else "🔀 Off"
        seek.max = ((t?.durationMs ?: 0L) / 1000).toInt()
    }

    private fun progress() {
        if (!dragging) seek.progress = Player.position / 1000
    }

    override fun onResume() {
        super.onResume()
        Player.listener = { runOnUiThread { refresh() } }
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        Player.listener = null
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
