package com.example.goosedroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.IBinder

/** Keeps music playing in the background and shows a notification with Pause / Next / Stop. */
class MusicService : Service() {
    companion object { @Volatile var running = false }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Player.serviceListener = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "toggle" -> Player.toggle()
            "next" -> Player.next()
            "stop" -> { Player.stop(); stopSelf(); return START_NOT_STICKY }
        }
        startForeground(2, build())
        return START_NOT_STICKY
    }

    private fun refresh() {
        getSystemService(NotificationManager::class.java).notify(2, build())
    }

    private fun action(code: Int, name: String, icon: Int, label: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, MusicService::class.java).setAction(name),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun build(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("music", "Music", NotificationManager.IMPORTANCE_LOW))
        val t = Player.current
        val playIcon = if (Player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        return Notification.Builder(this, "music")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: "GooseDroid music")
            .setContentText(t?.artist ?: "")
            .addAction(action(1, "toggle", playIcon, if (Player.isPlaying) "Pause" else "Play"))
            .addAction(action(2, "next", android.R.drawable.ic_media_next, "Next"))
            .addAction(action(3, "stop", android.R.drawable.ic_menu_close_clear_cancel, "Stop"))
            .build()
    }

    override fun onDestroy() {
        running = false
        Player.serviceListener = null
        super.onDestroy()
    }
}
