package com.example.goosedroid

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView

/** Shared plumbing: background, score text, loop, coins, game-over dialog, versus (player or bot). */
abstract class BaseGame(
    ctx: Context,
    private val key: String,
    protected val versus: Versus?,
    private val onExit: () -> Unit
) : FrameLayout(ctx) {

    companion object { const val VERSUS_LIMIT_MS = 40_000L }

    protected val d = resources.displayMetrics.density
    protected val uiHandler = Handler(Looper.getMainLooper())
    protected val hud = TextView(ctx).apply {
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ThemeMode.text(ctx))
        val p = (16 * d).toInt()
        setPadding(p, p, p, p)
    }
    private val oppHud = TextView(ctx).apply {
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ThemeMode.oppText(ctx))
        val p = (16 * d).toInt()
        setPadding(p, 0, p, 0)
    }

    /** Coins earned per score point. */
    protected open val coinRate: Float = 1f
    protected open fun currentScore(): Int = 0

    private var started = false
    private var running = false
    private var t0 = 0L
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            tick()
            val v = versus
            if (running && v != null) {
                v.report(currentScore())
                oppHud.text = "${v.name}: ${v.oppScore}"
                if (SystemClock.uptimeMillis() - t0 >= VERSUS_LIMIT_MS) gameOver("Time's up!", currentScore())
            }
            if (running) uiHandler.postDelayed(this, 16)
        }
    }

    init {
        setWillNotDraw(false)
        setBackgroundColor(ThemeMode.bg(ctx))
        addView(hud)
        if (versus != null) {
            addView(
                oppHud,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                ).apply { topMargin = (50 * d).toInt() }
            )
        }
    }

    /** Called at the start of every round, once the view has a size. */
    abstract fun reset()
    open fun tick() {}

    fun begin() {
        uiHandler.removeCallbacksAndMessages(null)
        running = true
        t0 = SystemClock.uptimeMillis()
        reset()
        uiHandler.post(loop)
    }

    fun end() {
        running = false
        uiHandler.removeCallbacksAndMessages(null)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!started && w > 0 && h > 0) { started = true; begin() }
    }

    protected fun gameOver(text: String, score: Int) {
        end()
        val v = versus
        if (v == null) { showResult(text, score); return }
        v.finish(score)
        hud.text = "Waiting for ${v.name} to finish..."
        val waitStart = SystemClock.uptimeMillis()
        uiHandler.post(object : Runnable {
            override fun run() {
                if (v.oppDone || SystemClock.uptimeMillis() - waitStart > 30_000) showResult(text, score)
                else uiHandler.postDelayed(this, 300)
            }
        })
    }

    private fun showResult(text: String, score: Int) {
        val v = versus
        val prefs = Store.prefs(context)
        val best = maxOf(prefs.getInt(key, 0), score)
        prefs.edit().putInt(key, best).apply()

        var coins = (score * coinRate).toInt()
        if (score > 0 && coins < 1) coins = 1
        var verdict = ""
        if (v != null) {
            val opp = v.oppScore
            val left = if (!v.oppDone) " (they left early)" else ""
            verdict = when {
                score > opp -> { coins += 15; "You: $score  ${v.name}: $opp$left\n🏆 You win! (+15 bonus)\n" }
                score == opp -> { coins += 5; "You: $score  ${v.name}: $opp$left\n🤝 Tie! (+5 bonus)\n" }
                else -> "You: $score  ${v.name}: $opp$left\n${v.name} wins this one.\n"
            }
        }
        Store.addCoins(context, coins)

        val b = AlertDialog.Builder(context)
            .setTitle(if (v == null) "Game over" else "Match over")
            .setMessage("$text\n$verdict+$coins coins 🪙\nBest: $best")
            .setCancelable(false)
            .setNegativeButton("Menu") { _, _ -> onExit() }
        if (v == null) b.setPositiveButton("Play again") { _, _ -> begin() }
        try { b.show() } catch (_: Exception) {}
    }
}
