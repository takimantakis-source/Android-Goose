package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.random.Random

/** Game 2: drag the goose left and right to catch bread. Dodge the rocks. Three lives. */
class BreadGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "bread", versus, onExit) {
    override fun currentScore() = score
    private class Item(var x: Float, var y: Float, val rock: Boolean, val vy: Float)

    private val goose = GooseView(ctx)
    private val items = ArrayList<Item>()
    private var score = 0
    private var lives = 3
    private var cooldown = 0

    private val breadFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(222, 184, 135) }
    private val breadLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(150, 100, 50); strokeWidth = 2 * d
    }
    private val rockFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY }
    private val rockLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.DKGRAY; strokeWidth = 2 * d
    }

    init {
        addView(goose, FrameLayout.LayoutParams(goose.sizeW, goose.sizeH))
    }

    override fun reset() {
        score = 0
        lives = 3
        cooldown = 30
        items.clear()
        goose.x = (width - goose.sizeW) / 2f
        goose.y = height - goose.sizeH - 8 * d
        goose.walking = false
        goose.invalidate()
        updateHud()
    }

    private fun updateHud() {
        val hearts = "♥".repeat(lives.coerceAtLeast(0))
        hud.text = "Bread: $score     Lives: $hearts"
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val nx = (e.x - goose.sizeW / 2f).coerceIn(0f, (width - goose.sizeW).toFloat())
            val dx = nx - goose.x
            goose.walking = abs(dx) > 1
            if (abs(dx) > 1) goose.facingLeft = dx < 0
            goose.phase += 0.5f
            goose.x = nx
        } else {
            goose.walking = false
        }
        goose.invalidate()
        return true
    }

    private fun spawn() {
        val vy = (3f + score * 0.12f).coerceAtMost(11f) * d * (0.8f + Random.nextFloat() * 0.4f)
        items.add(
            Item(
                Random.nextFloat() * (width - 40 * d) + 20 * d,
                -20 * d,
                Random.nextInt(5) == 0,
                vy
            )
        )
    }

    override fun tick() {
        cooldown--
        if (cooldown <= 0) { spawn(); cooldown = (55 - score).coerceAtLeast(18) }

        val left = goose.x + goose.sizeW * 0.1f
        val right = goose.x + goose.sizeW * 0.9f
        val top = goose.y + goose.sizeH * 0.35f
        val bottom = goose.y + goose.sizeH

        val iter = items.iterator()
        while (iter.hasNext()) {
            val item = iter.next()
            item.y += item.vy
            if (item.y > top && item.y < bottom && item.x in left..right) {
                iter.remove()
                if (item.rock) { lives--; Sound.play(150.0, 80.0, 200) }
                else { score++; Sound.play(600.0, 900.0, 90) }
                updateHud()
            } else if (item.y > height) {
                iter.remove()
                if (!item.rock) { lives--; updateHud() }
            }
            if (lives <= 0) { gameOver("You caught $score bread!", score); return }
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        for (i in items) {
            if (i.rock) {
                c.drawCircle(i.x, i.y, 12 * d, rockFill)
                c.drawCircle(i.x, i.y, 12 * d, rockLine)
            } else {
                val r = RectF(i.x - 14 * d, i.y - 10 * d, i.x + 14 * d, i.y + 10 * d)
                c.drawOval(r, breadFill)
                c.drawOval(r, breadLine)
            }
        }
    }
}
