package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.random.Random

/** Game 4: tap to flap and fly through the gaps between the reeds. */
class FlappyGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "flappy", versus, onExit) {
    private class Pipe(var x: Float, val gapTop: Float, var passed: Boolean = false)

    override val coinRate = 2f
    override fun currentScore() = score

    private val goose = GooseView(ctx)
    private val pipes = ArrayList<Pipe>()
    private var gy = 0f
    private var vy = 0f
    private var score = 0
    private var flying = false
    private var hover = 0f

    private val pipeW: Float get() = 56 * d
    private val gap: Float get() = 170 * d
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(76, 175, 80) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(27, 94, 32); strokeWidth = 3 * d
    }

    init {
        addView(goose, FrameLayout.LayoutParams(goose.sizeW, goose.sizeH))
    }

    override fun reset() {
        score = 0
        pipes.clear()
        flying = false
        vy = 0f
        gy = height / 2f - goose.sizeH / 2f
        goose.x = width * 0.2f
        goose.facingLeft = false
        goose.walking = true
        goose.rotation = 0f
        place()
        hud.text = "Tap to flap!"
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            flying = true
            vy = -8f * d
            Sound.play(500.0, 650.0, 60)
        }
        return true
    }

    override fun tick() {
        goose.phase += 0.3f
        if (!flying) { // hover until the first tap
            hover += 0.1f
            gy += kotlin.math.sin(hover) * 0.5f * d
            place()
            return
        }
        vy = (vy + 0.35f * d).coerceAtMost(12f * d)
        gy += vy
        val speed = (3.2f + score * 0.08f).coerceAtMost(5.5f) * d
        for (p in pipes) p.x -= speed
        pipes.removeAll { it.x < -pipeW }
        if (pipes.isEmpty() || pipes.last().x < width - 230 * d) {
            pipes.add(Pipe(width + 20 * d, Random.nextFloat() * (height - gap - 200 * d) + 100 * d))
        }

        val cx = goose.x + 55 * d
        val cy = gy + 85 * d
        val hw = 26 * d
        val hh = 22 * d
        var dead = cy - hh < 0 || cy + hh > height
        for (p in pipes) {
            if (cx + hw > p.x && cx - hw < p.x + pipeW && (cy - hh < p.gapTop || cy + hh > p.gapTop + gap)) dead = true
            if (!p.passed && p.x + pipeW < cx - hw) {
                p.passed = true
                score++
                Sound.play(700.0, 900.0, 70)
            }
        }
        hud.text = "Reeds: $score"
        goose.rotation = (vy / (12f * d)) * 30f
        place()
        invalidate()
        if (dead) gameOver("You passed $score reeds!", score)
    }

    private fun place() {
        goose.y = gy
        goose.invalidate()
    }

    override fun onDraw(c: Canvas) {
        for (p in pipes) {
            c.drawRect(p.x, -10f, p.x + pipeW, p.gapTop, fill)
            c.drawRect(p.x, -10f, p.x + pipeW, p.gapTop, line)
            c.drawRect(p.x, p.gapTop + gap, p.x + pipeW, height + 10f, fill)
            c.drawRect(p.x, p.gapTop + gap, p.x + pipeW, height + 10f, line)
        }
    }
}
