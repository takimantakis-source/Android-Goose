package com.example.goosedroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val games = listOf(
        Triple("catch", "🪿 Catch the Goose", "Tap the goose. It gets faster!"),
        Triple("bread", "🍞 Bread Catch", "Drag the goose to catch bread. Dodge rocks."),
        Triple("simon", "🎵 Honk Memory", "Repeat the goose's honk pattern."),
        Triple("flappy", "🌾 Flappy Goose", "Tap to flap through the reeds."),
        Triple("whack", "🦊 Whack-a-Goose", "Tap geese as they pop up. Not foxes!")
    )
    private val gameButtons = ArrayList<Button>()
    private lateinit var shopButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad / 2)
        }
        fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("🎵") { startActivity(Intent(this, MusicActivity::class.java)) }.apply { textSize = 22f })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(button(if (ThemeMode.dark(this)) "☀️" else "🌙") {
            ThemeMode.toggle(this)
            recreate()
        }.apply { textSize = 22f })
        root.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        root.addView(label("🪿 GooseDroid", 30f))
        root.addView(label("Lets a goose waddle over your screen.\nTap it to honk. Drag it to pick it up.", 14f))
        root.addView(button("Release the goose") { start() })
        root.addView(button("Shoo goose away") { stopService(Intent(this, GooseService::class.java)) })

        shopButton = button("") { startActivity(Intent(this, ShopActivity::class.java)) }
        root.addView(shopButton)

        root.addView(label("Minigames", 22f))
        for ((key, title, _) in games) {
            val b = button("") {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setItems(arrayOf("Play solo", "Play online (player or bot)")) { _, which ->
                        startActivity(
                            Intent(this, GameActivity::class.java)
                                .putExtra("game", key).putExtra("online", which == 1)
                        )
                    }.show()
            }
            gameButtons.add(b)
            root.addView(b)
        }
        root.addView(label(
            "Online matches use the public ntfy.sh relay. Your goose nickname and scores are visible to the other player. " +
                "If nobody is found within ~9 seconds you play a bot (marked 🤖).", 12f
        ))

        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        Cosmetics.refresh(this)
        val prefs = Store.prefs(this)
        shopButton.text = "🛍 Shop   (🪙 ${Store.coins(this)})"
        games.forEachIndexed { i, (key, title, hint) ->
            gameButtons[i].text = "$title\n$hint\nBest: ${prefs.getInt(key, 0)}"
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\", then come back", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, GooseService::class.java))
    }
}
