package com.example.goosedroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MusicActivity : Activity() {
    private var all: List<Player.Track> = emptyList()
    private var list: List<Player.Track> = emptyList() // what the list currently shows
    private var viewName: String? = null               // null = all songs, otherwise a playlist name

    private lateinit var listView: ListView
    private lateinit var info: TextView
    private lateinit var modeBtn: Button
    private lateinit var delBtn: Button
    private lateinit var nowText: TextView
    private lateinit var artView: ImageView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private lateinit var shuffleBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false

    private val placeholder: Bitmap by lazy {
        val b = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(224, 224, 224))
        c.drawText("🎵", 128f, 170f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 130f; textAlign = Paint.Align.CENTER
        })
        b
    }

    private val ticker = object : Runnable {
        override fun run() { progress(); handler.postDelayed(this, 500) }
    }

    private val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (12 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "🎵 Music"; textSize = 26f })
        info = TextView(this).apply { text = "Loading your music..."; textSize = 14f }
        root.addView(info)

        val modeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        modeBtn = Button(this).apply { text = "📂 All songs ▾"; setOnClickListener { pickView() } }
        delBtn = Button(this).apply {
            text = "🗑"; visibility = View.GONE
            setOnClickListener { confirmDelete() }
        }
        modeRow.addView(modeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        modeRow.addView(delBtn)
        root.addView(modeRow)

        listView = ListView(this)
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))

        val nowRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad, 0, 0)
        }
        artView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        nowRow.addView(artView, LinearLayout.LayoutParams((100 * d).toInt(), (100 * d).toInt()))
        nowText = TextView(this).apply { textSize = 16f; setPadding(pad, 0, 0, 0) }
        nowRow.addView(nowText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(nowRow)

        seek = SeekBar(this)
        root.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                Player.seekTo(seek.progress * 1000)
            }
        })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        row.addView(btn("⏮") { Player.prev() })
        playBtn = btn("▶") {
            if (Player.index < 0 && list.isNotEmpty()) { Player.tracks = list; Player.play(this, 0) }
            else Player.toggle()
        }
        row.addView(playBtn)
        row.addView(btn("⏭") { Player.next() })
        shuffleBtn = btn("🔀 Off") { Player.shuffle = !Player.shuffle; refresh() }
        row.addView(shuffleBtn)
        root.addView(row)
        setContentView(root)

        listView.setOnItemClickListener { _, _, pos, _ ->
            Player.tracks = list
            Player.play(this, pos)
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < list.size) songMenu(list[pos])
            true
        }

        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(permission), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) load()
        else info.text = "GooseDroid needs permission to read your music files."
    }

    private fun load() {
        thread {
            val out = ArrayList<Player.Track>()
            val media = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
            )
            try {
                contentResolver.query(
                    media, proj,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000",
                    null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        out.add(
                            Player.Track(
                                ContentUris.withAppendedId(media, c.getLong(0)),
                                c.getString(1) ?: "Unknown", c.getString(2) ?: "", c.getLong(3)
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread { show(out) }
        }
    }

    private fun show(tracks: List<Player.Track>) {
        all = tracks
        if (Player.tracks.isEmpty() || Player.index < 0) Player.tracks = tracks
        applyView()
    }

    /** Fills the list with either all songs or the chosen playlist. */
    private fun applyView() {
        val lists = Playlists.get(this)
        if (viewName != null && !lists.containsKey(viewName!!)) viewName = null
        val current = viewName
        list = if (current == null) all else {
            val byId = all.associateBy { ContentUris.parseId(it.uri) }
            (lists[current] ?: emptyList<Long>()).mapNotNull { byId[it] }
        }
        modeBtn.text = "📂 ${current ?: "All songs"} ▾"
        delBtn.visibility = if (current == null) View.GONE else View.VISIBLE
        info.text = when {
            all.isEmpty() -> "No music files found on this device."
            current != null && list.isEmpty() -> "This playlist is empty. Hold a song in All songs to add it."
            else -> "${list.size} songs - tap to play, hold for options"
        }
        val names = list.map {
            if (it.artist.isBlank() || it.artist == "<unknown>") it.title else "${it.title} - ${it.artist}"
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun askName(done: (String) -> Unit) {
        val et = EditText(this)
        et.hint = "Playlist name"
        AlertDialog.Builder(this)
            .setTitle("New playlist")
            .setView(et)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) done(n)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickView() {
        val names = Playlists.get(this).keys.toList()
        val items = (listOf("All songs") + names + "➕ New playlist...").toTypedArray()
        AlertDialog.Builder(this).setTitle("Playlists").setItems(items) { _, i ->
            when {
                i == 0 -> { viewName = null; applyView() }
                i <= names.size -> { viewName = names[i - 1]; applyView() }
                else -> askName { n -> Playlists.create(this, n); viewName = n; applyView() }
            }
        }.show()
    }

    private fun confirmDelete() {
        val n = viewName ?: return
        AlertDialog.Builder(this)
            .setTitle("Delete \"$n\"?")
            .setMessage("The songs stay on your phone.")
            .setPositiveButton("Delete") { _, _ -> Playlists.delete(this, n); viewName = null; applyView() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun songMenu(t: Player.Track) {
        val id = ContentUris.parseId(t.uri)
        val opts = ArrayList<String>()
        opts.add("Add to playlist...")
        val cur = viewName
        if (cur != null) opts.add("Remove from \"$cur\"")
        AlertDialog.Builder(this).setTitle(t.title).setItems(opts.toTypedArray()) { _, i ->
            if (i == 0) addTo(id)
            else if (cur != null) { Playlists.remove(this, cur, id); applyView() }
        }.show()
    }

    private fun addTo(id: Long) {
        val names = Playlists.get(this).keys.toList()
        val items = (names + "➕ New playlist...").toTypedArray()
        AlertDialog.Builder(this).setTitle("Add to playlist").setItems(items) { _, i ->
            if (i < names.size) { Playlists.add(this, names[i], id); toast("Added to ${names[i]}") }
            else askName { n -> Playlists.create(this, n); Playlists.add(this, n, id); toast("Added to $n") }
        }.show()
    }

    private fun refresh() {
        val t = Player.current
        nowText.text = when {
            t == null -> "Nothing playing"
            t.artist.isBlank() || t.artist == "<unknown>" -> t.title
            else -> "${t.title}\n${t.artist}"
        }
        artView.setImageBitmap(Player.art ?: placeholder)
        playBtn.text = if (Player.isPlaying) "⏸" else "▶"
        shuffleBtn.text = if (Player.shuffle) "🔀 On" else "🔀 Off"
        seek.max = ((t?.durationMs ?: 0L) / 1000).toInt()
    }

    private fun progress() {
        if (!dragging) seek.progress = Player.position / 1000
    }

    override fun onResume() {
        super.onResume()
        Player.listener = { runOnUiThread { refresh() } }
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        Player.listener = null
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
