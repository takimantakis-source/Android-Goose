package com.example.goosedroid

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.util.Size
import kotlin.concurrent.thread
import kotlin.random.Random

/** One MediaPlayer shared by the music screen and the notification service. */
object Player {
    class Track(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

    var tracks: List<Track> = emptyList()
    var index = -1
    var shuffle = false
    var listener: (() -> Unit)? = null
    var serviceListener: (() -> Unit)? = null
    var art: Bitmap? = null

    private var mp: MediaPlayer? = null
    private var ctx: Context? = null

    val current: Track? get() = tracks.getOrNull(index)
    val isPlaying: Boolean get() = try { mp?.isPlaying == true } catch (e: IllegalStateException) { false }
    val position: Int get() = try { mp?.currentPosition ?: 0 } catch (e: IllegalStateException) { 0 }

    private fun changed() { listener?.invoke(); serviceListener?.invoke() }

    fun play(context: Context, i: Int) {
        if (tracks.isEmpty()) return
        val app = context.applicationContext
        ctx = app
        index = ((i % tracks.size) + tracks.size) % tracks.size
        mp?.release()
        loadArt(app, tracks[index])
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(app, tracks[index].uri)
            p.setOnPreparedListener { it.start(); changed() }
            p.setOnCompletionListener { next() }
            p.setOnErrorListener { _, _, _ -> changed(); true }
            p.prepareAsync()
            if (!MusicService.running) app.startForegroundService(Intent(app, MusicService::class.java))
        } catch (e: Exception) { }
        changed()
    }

    /** Album cover: system thumbnail first (Android 10+), then the picture embedded in the file. */
    private fun loadArt(app: Context, t: Track) {
        art = null
        thread {
            var bmp: Bitmap? = null
            if (Build.VERSION.SDK_INT >= 29) {
                try { bmp = app.contentResolver.loadThumbnail(t.uri, Size(512, 512), null) } catch (_: Exception) {}
            }
            if (bmp == null) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(app, t.uri)
                    val b = r.embeddedPicture
                    if (b != null) {
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(b, 0, b.size, o)
                        val o2 = BitmapFactory.Options().apply {
                            inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 600)
                        }
                        bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2)
                    }
                } catch (_: Exception) {
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
            }
            if (current?.uri == t.uri) { art = bmp; changed() }
        }
    }

    fun next() {
        val c = ctx ?: return
        if (tracks.isEmpty()) return
        play(c, if (shuffle) Random.nextInt(tracks.size) else index + 1)
    }

    fun prev() {
        val c = ctx ?: return
        if (tracks.isEmpty()) return
        play(c, index - 1)
    }

    fun toggle() {
        val p = mp ?: return
        try { if (p.isPlaying) p.pause() else p.start() } catch (e: IllegalStateException) { }
        changed()
    }

    fun seekTo(ms: Int) { try { mp?.seekTo(ms) } catch (e: IllegalStateException) { } }

    fun stop() {
        mp?.release()
        mp = null
        index = -1
        art = null
        changed()
    }
}
