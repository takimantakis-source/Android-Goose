package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ShopActivity : Activity() {
    private lateinit var root: LinearLayout
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun tv(t: String, size: Float) = TextView(this).apply {
        text = t; textSize = size
        setPadding(0, pad / 2, 0, pad / 2)
    }

    private fun render() {
        root.removeAllViews()
        root.addView(tv("🛍 Goose Shop", 26f))
        root.addView(tv("🪙 ${Store.coins(this)} coins  -  earn more in the minigames!", 16f))
        val g = GooseView(this)
        root.addView(g, LinearLayout.LayoutParams(g.sizeW, g.sizeH).apply { gravity = Gravity.CENTER_HORIZONTAL })

        for ((slot, title) in Store.slots) {
            root.addView(tv(title, 20f))
            for (item in Store.items.filter { it.slot == slot }) root.addView(row(item))
        }
    }

    private fun row(item: Store.Item): LinearLayout {
        val owned = Store.owned(this, item.id)
        val eq = Store.equipped(this, item.slot) == item.id
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val pv = GooseView(this, 0.6f).apply { previewItem = item }
        r.addView(pv, LinearLayout.LayoutParams(pv.sizeW, pv.sizeH))
        r.addView(TextView(this).apply {
            text = item.name + if (!owned) "\n🪙${item.price}" else "\n✓ Owned"
            textSize = 16f
            setPadding(pad / 2, 0, pad / 2, 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Button(this).apply {
            text = when {
                !owned -> "Buy"
                eq && item.slot == "skin" -> "Equipped"
                eq -> "Unequip"
                else -> "Equip"
            }
            isEnabled = !(eq && item.slot == "skin")
            setOnClickListener {
                when {
                    !owned -> {
                        if (Store.buy(this@ShopActivity, item)) Store.equip(this@ShopActivity, item.slot, item.id)
                        else Toast.makeText(this@ShopActivity, "Not enough coins", Toast.LENGTH_SHORT).show()
                    }
                    eq -> Store.equip(this@ShopActivity, item.slot, "")
                    else -> Store.equip(this@ShopActivity, item.slot, item.id)
                }
                render()
            }
        })
        return r
    }
}
