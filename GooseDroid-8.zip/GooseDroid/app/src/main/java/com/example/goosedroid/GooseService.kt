package com.example.goosedroid

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.*
import android.os.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.random.Random

class GooseService : Service() {

    companion object { const val ACTION_STOP = "stop_goose" }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var goose: GooseView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var x = 0f
    private var y = 0f
    private var tx = 0f
    private var ty = 0f
    private var idleUntil = 0L
    private var held = false
    private var dash = false

    private val density get() = resources.displayMetrics.density
    private val sw get() = resources.displayMetrics.widthPixels
    private val sh get() = resources.displayMetrics.heightPixels

    private val ticker = object : Runnable {
        override fun run() { step(); handler.postDelayed(this, 33) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (goose == null) startGoose()
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun startGoose() {
        startForeground(1, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val g = GooseView(this)
        goose = g
        lp = WindowManager.LayoutParams(
            g.sizeW, g.sizeH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        x = -g.sizeW.toFloat() // waddles in from the left edge
        y = sh * 0.6f
        pickTarget()
        apply()
        wm.addView(g, lp)

        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f; var moved = false
        g.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = x; startY = y
                    moved = false; held = true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (hypot(dx, dy) > 20 * density) moved = true
                    if (moved) { x = startX + dx; y = startY + dy; g.walking = false; apply() }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    held = false
                    if (!moved) honk()
                    idleUntil = SystemClock.uptimeMillis() + 1500
                    pickTarget()
                }
            }
            true
        }
        handler.post(ticker)
    }

    private fun pickTarget() {
        val g = goose ?: return
        tx = Random.nextInt(0, (sw - g.sizeW).coerceAtLeast(1)).toFloat()
        ty = Random.nextInt(0, (sh - g.sizeH).coerceAtLeast(1)).toFloat()
        dash = Random.nextInt(5) == 0 // occasionally the goose sprints
    }

    private fun step() {
        val g = goose ?: return
        if (held) return
        val now = SystemClock.uptimeMillis()
        if (now < idleUntil) { g.walking = false; g.invalidate(); return }

        val dx = tx - x; val dy = ty - y
        val dist = hypot(dx, dy)
        if (dist < 8 * density) {
            idleUntil = now + Random.nextLong(1000, 4000)
            if (Random.nextInt(3) == 0) honk()
            pickTarget()
            g.walking = false
        } else {
            val speed = (if (dash) 6f else 2.6f) * density
            x += dx / dist * speed
            y += dy / dist * speed
            if (kotlin.math.abs(dx) > 2) g.facingLeft = dx < 0
            g.walking = true
            g.phase += if (dash) 0.6f else 0.35f
        }
        apply()
        g.invalidate()
    }

    private fun apply() {
        val g = goose ?: return
        lp.x = x.toInt().coerceIn(-g.sizeW, sw)
        lp.y = y.toInt().coerceIn(-g.sizeH, sh)
        if (g.isAttachedToWindow) wm.updateViewLayout(g, lp)
    }

    private fun honk() {
        val g = goose ?: return
        g.bubble = listOf("HONK!", "HONK HONK!", "HOOONK!").random()
        g.invalidate()
        handler.postDelayed({ g.bubble = null; g.invalidate() }, 900)
        playHonkSound()
    }

    /** Synthesizes a goose-ish honk: falling-pitch sawtooth with a quick envelope. */
    private fun playHonkSound() {
        val sr = 22050
        val n = sr * 3 / 10
        val buf = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i / n.toDouble()
            ph += (330 - 120 * t) / sr
            val saw = 2 * (ph % 1.0) - 1
            val env = if (t < 0.05) t / 0.05 else 1 - (t - 0.05) / 0.95
            buf[i] = (saw * env * 0.5 * Short.MAX_VALUE).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(n * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(buf, 0, n)
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack) { t.release() }
            override fun onPeriodicNotification(t: AudioTrack) {}
        })
        track.notificationMarkerPosition = n
        track.play()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("goose", "Goose", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, GooseService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "goose")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(tr("The goose is loose"))
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(
                        this, android.R.drawable.ic_menu_close_clear_cancel
                    ), tr("Shoo"), stop
                ).build()
            )
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        goose?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        goose = null
        super.onDestroy()
    }
}
