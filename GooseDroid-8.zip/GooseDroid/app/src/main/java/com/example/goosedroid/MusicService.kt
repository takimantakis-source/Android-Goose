package com.example.goosedroid

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.os.IBinder

/** Keeps music playing in the background and shows a notification with Pause / Next / Stop. */
class MusicService : Service() {
    companion object { @Volatile var running = false }

    private var noteView: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        Player.serviceListener = { refresh() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "toggle" -> Player.toggle()
            "next" -> Player.next()
            "stop" -> { Player.stop(); stopSelf(); return START_NOT_STICKY }
        }
        startForeground(2, build())
        showNote()
        return START_NOT_STICKY
    }

    private fun refresh() {
        getSystemService(NotificationManager::class.java).notify(2, build())
    }

    private fun action(code: Int, name: String, icon: Int, label: String): Notification.Action {
        val pi = PendingIntent.getService(
            this, code, Intent(this, MusicService::class.java).setAction(name),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun build(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("music", "Music", NotificationManager.IMPORTANCE_LOW))
        val t = Player.current
        val playIcon = if (Player.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        return Notification.Builder(this, "music")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(t?.title ?: tr("GooseDroid music"))
            .setContentText(t?.artist ?: "")
            .setLargeIcon(Player.art)
            .addAction(action(1, "toggle", playIcon, if (Player.isPlaying) tr("Pause") else tr("Play")))
            .addAction(action(2, "next", android.R.drawable.ic_media_next, tr("Next")))
            .addAction(action(3, "stop", android.R.drawable.ic_menu_close_clear_cancel, tr("Stop")))
            .build()
    }

    /** A little 🎵 button in the upper-left corner of the screen that opens the music player. */
    private fun showNote() {
        if (noteView != null || !Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        val v = TextView(this).apply {
            text = "🎵"
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(230, 255, 255, 255))
                setStroke((2 * d).toInt(), Color.GRAY)
            }
            setOnClickListener {
                startActivity(
                    Intent(this@MusicService, MusicActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        val lp = WindowManager.LayoutParams(
            (52 * d).toInt(), (52 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (28 * d).toInt()
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            noteView = v
        } catch (_: Exception) {}
    }

    private fun hideNote() {
        noteView?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        noteView = null
    }

    override fun onDestroy() {
        hideNote()
        running = false
        Player.serviceListener = null
        super.onDestroy()
    }
}
