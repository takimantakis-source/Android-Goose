package com.example.goosedroid

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.concurrent.thread

/** Design settings of the music player: color, liquid glass, background. */
class MusicSettingsActivity : Activity() {
    private lateinit var root: LinearLayout

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(10f), 0, dp(6f))
    }

    private fun render() {
        root.removeAllViews()
        val prefs = Store.prefs(this)
        root.addView(tv(tr("⚙ Music settings"), 24f, true))
        root.addView(preview(), LinearLayout.LayoutParams(-1, dp(170f)))

        // accent color
        root.addView(tv(tr("Design"), 18f, true))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val cur = MusicDesign.accentKey(this)
        for ((k, name, color) in MusicDesign.ACCENTS) {
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                    if (k == cur) setStroke(dp(4f), if (ThemeMode.dark(this@MusicSettingsActivity)) Color.WHITE else Color.BLACK)
                }
            }
            cell.addView(dot, LinearLayout.LayoutParams(dp(46f), dp(46f)))
            cell.addView(TextView(this).apply {
                text = (if (k == cur) "✓ " else "") + tr(name)
                textSize = 12f
                gravity = Gravity.CENTER
            })
            cell.setOnClickListener { prefs.edit().putString("m_accent", k).apply(); render() }
            row.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)

        // liquid glass
        root.addView(Switch(this).apply {
            text = tr("Liquid glass")
            textSize = 16f
            isChecked = MusicDesign.glass(this@MusicSettingsActivity)
            setPadding(0, dp(14f), 0, dp(4f))
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("m_glass", on).apply(); render() }
        })
        root.addView(TextView(this).apply {
            text = tr("Frosted, see-through panels with a soft blurred background.")
            textSize = 13f
        })

        // background
        root.addView(tv(tr("Background"), 18f, true))
        val bgCur = MusicDesign.bgKey(this)
        for ((k, name) in MusicDesign.BACKGROUNDS) {
            root.addView(Button(this).apply {
                text = (if (k == bgCur) "✓ " else "") + tr(name)
                isAllCaps = false
                setOnClickListener {
                    if (k == "custom") {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        }
                        startActivityForResult(i, 21)
                    } else {
                        prefs.edit().putString("m_bg", k).apply()
                        render()
                    }
                }
            })
        }
    }

    /** Live preview of the current design. */
    private fun preview(): View {
        val frame = FrameLayout(this)
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(bg, FrameLayout.LayoutParams(-1, -1))
        val scr = View(this).apply { setBackgroundColor(MusicDesign.scrim(this@MusicSettingsActivity)) }
        frame.addView(scr, FrameLayout.LayoutParams(-1, -1))
        val card = TextView(this).apply {
            text = "🎵  " + tr("Song title") + "\n" + tr("Artist")
            textSize = 16f
            setTextColor(MusicDesign.textColor(this@MusicSettingsActivity))
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            background = MusicDesign.panel(this@MusicSettingsActivity, 20f)
        }
        frame.addView(card, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(20f), 0, dp(20f), 0) })
        thread {
            val b = MusicDesign.background(this, 600, 360)
            runOnUiThread { bg.setImageBitmap(b) }
        }
        return frame
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 21 && res == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            Store.prefs(this).edit().putString("m_bg_uri", uri.toString()).putString("m_bg", "custom").apply()
            render()
        }
    }
}
