package com.example.goosedroid

import android.os.SystemClock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread
import kotlin.random.Random

/** Minimal client for the public ntfy.sh pub/sub relay (no account, no server of our own). */
object Ntfy {
    private const val BASE = "https://ntfy.sh/"

    class Sub {
        @Volatile var stopped = false
        @Volatile var conn: HttpURLConnection? = null
        fun close() {
            stopped = true
            Thread { try { conn?.disconnect() } catch (_: Exception) {} }.start()
        }
    }

    fun publish(topic: String, msg: String) {
        thread {
            try {
                val c = URL(BASE + topic).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.outputStream.use { it.write(msg.toByteArray()) }
                c.responseCode
                c.disconnect()
            } catch (_: Exception) {}
        }
    }

    fun subscribe(topic: String, since: String, onMsg: (String) -> Unit): Sub {
        val sub = Sub()
        thread {
            try {
                val c = URL("$BASE$topic/json?since=$since").openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 90_000
                sub.conn = c
                if (c.responseCode == 200) {
                    c.inputStream.bufferedReader().use { r ->
                        while (!sub.stopped) {
                            val line = r.readLine() ?: break
                            val j = JSONObject(line)
                            if (j.optString("event") == "message") onMsg(j.optString("message"))
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return sub
    }
}

/** The other side of a score race: either a real player or a bot. */
abstract class Versus(val name: String, val isBot: Boolean) {
    @Volatile var oppScore = 0
    @Volatile var oppDone = false
    abstract fun report(score: Int)
    abstract fun finish(score: Int)
    open fun close() {}
}

class BotVersus(gameKey: String, best: Int) : Versus("🤖 " + NAMES.random(), true) {
    companion object {
        val NAMES = listOf("Honkzilla", "Sir Waddles", "Gandergoose", "Quackers Jr", "Feathers", "Bread Bandit", "Pond Baron")
        val FLOOR = mapOf("catch" to 12, "bread" to 10, "simon" to 5, "flappy" to 5, "whack" to 12)
    }

    private val start = SystemClock.uptimeMillis()
    private val target: Int

    init {
        val ref = maxOf(FLOOR[gameKey] ?: 8, best)
        target = (ref * (0.7f + Random.nextFloat() * 0.45f)).toInt().coerceAtLeast(1)
    }

    override fun report(score: Int) {
        val t = ((SystemClock.uptimeMillis() - start) / 30_000f).coerceAtMost(1f)
        oppScore = (target * t).toInt()
    }

    override fun finish(score: Int) {
        oppScore = target
        oppDone = true
    }
}

class OnlineVersus(
    private val me: String, private val oppId: String, name: String, private val topic: String
) : Versus(name, false) {
    private var lastSent = 0L
    private var lastScore = -1

    private val sub = Ntfy.subscribe(topic, "30s") { m ->
        val p = m.split("|")
        if (p.size >= 3 && p[1] == oppId) {
            val s = p[2].toIntOrNull()
            if (s != null) {
                if (p[0] == "S") oppScore = maxOf(oppScore, s)
                if (p[0] == "D") { oppScore = s; oppDone = true }
            }
        }
    }

    override fun report(score: Int) {
        val now = SystemClock.uptimeMillis()
        if (score != lastScore && now - lastSent > 2000) {
            lastScore = score
            lastSent = now
            Ntfy.publish(topic, "S|$me|$score")
        }
    }

    override fun finish(score: Int) {
        Ntfy.publish(topic, "D|$me|$score")
    }

    override fun close() { sub.close() }
}

object Matchmaker {
    class Handle { @Volatile var cancelled = false }

    /**
     * Looks for another player in the lobby for ~9 seconds. Found someone -> OnlineVersus,
     * otherwise (or on any network trouble) -> BotVersus. Never fails.
     */
    fun find(gameKey: String, nick: String, best: Int, h: Handle, onResult: (Versus) -> Unit) {
        thread {
            val chars = "abcdefghjkmnpqrstuvwxyz23456789"
            val me = (1..6).map { chars[Random.nextInt(chars.length)] }.joinToString("")
            val lobby = "gdroid-v1-lobby-$gameKey"
            val deadline = SystemClock.uptimeMillis() + 9000

            val result = AtomicReference<Versus?>(null)
            val cand = AtomicReference<Pair<String, String>?>(null)
            val accepted = AtomicBoolean(false)

            val lobbySub = Ntfy.subscribe(lobby, "6s") { m ->
                val p = m.split("|")
                if (p[0] == "HI" && p.size >= 3 && p[1] != me) {
                    if (cand.get() == null) cand.set(p[1] to p[2])
                } else if (p[0] == "INV" && p.size >= 4 && p[2] == me && result.get() == null) {
                    val topic = "gdroid-v1-m-${p[1]}-$me"
                    Ntfy.publish(topic, "ACC|$me|0")
                    result.set(OnlineVersus(me, p[1], p[3], topic))
                }
            }

            var lastHi = 0L
            var invitedAt = 0L
            var inviteTopic: String? = null
            var accSub: Ntfy.Sub? = null

            while (!h.cancelled && SystemClock.uptimeMillis() < deadline && result.get() == null) {
                val now = SystemClock.uptimeMillis()
                if (now - lastHi > 3000) { Ntfy.publish(lobby, "HI|$me|$nick"); lastHi = now }

                val c = cand.get()
                if (c != null && me < c.first) { // lower id hosts the match
                    val t = inviteTopic
                    if (t == null) {
                        val nt = "gdroid-v1-m-$me-${c.first}"
                        inviteTopic = nt
                        accepted.set(false)
                        accSub = Ntfy.subscribe(nt, "15s") { m -> if (m.startsWith("ACC|")) accepted.set(true) }
                        Ntfy.publish(lobby, "INV|$me|${c.first}|$nick")
                        invitedAt = now
                    } else if (accepted.get()) {
                        result.set(OnlineVersus(me, c.first, c.second, t))
                    } else if (now - invitedAt > 3500) { // nobody home, forget this candidate
                        accSub?.close()
                        accSub = null
                        inviteTopic = null
                        cand.set(null)
                    }
                }
                try { Thread.sleep(250) } catch (_: InterruptedException) {}
            }

            lobbySub.close()
            accSub?.close()
            val r = result.get()
            if (h.cancelled) r?.close()
            else onResult(r ?: BotVersus(gameKey, best))
        }
    }
}
