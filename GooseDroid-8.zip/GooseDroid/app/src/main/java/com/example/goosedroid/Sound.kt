package com.example.goosedroid

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** Tiny synth: a sawtooth sweeping from startHz to endHz. Used for honks, blips and pad tones. */
object Sound {
    fun play(startHz: Double, endHz: Double, ms: Int) {
        val sr = 22050
        val n = sr * ms / 1000
        val buf = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i / n.toDouble()
            ph += (startHz + (endHz - startHz) * t) / sr
            val saw = 2 * (ph % 1.0) - 1
            val env = if (t < 0.05) t / 0.05 else 1 - (t - 0.05) / 0.95
            buf[i] = (saw * env * 0.5 * Short.MAX_VALUE).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(n * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(buf, 0, n)
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack) { t.release() }
            override fun onPeriodicNotification(t: AudioTrack) {}
        })
        track.notificationMarkerPosition = n
        track.play()
    }

    fun honk() = play(330.0, 210.0, 300)
}
