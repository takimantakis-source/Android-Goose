package com.example.goosedroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Game 6: Goose Hunt. A first-person 3D tag game (ray-casting, like the first 3D shooters).
 * Left thumb moves, right thumb looks around. Whoever is "it" chases the others;
 * touch a goose and it becomes "it" instead of you.
 */
class HuntGame(ctx: Context, versus: Versus?, onExit: () -> Unit, mapIndex: Int) :
    BaseGame(ctx, "hunt", versus, onExit) {

    companion object {
        const val ROUND_MS = 600_000L // one round = 10 minutes
        const val HIT = 0.7f   // how close counts as "touching" (map cells)
        const val FOV = 0.66f
        val DX = intArrayOf(1, -1, 0, 0)
        val DY = intArrayOf(0, 0, 1, -1)
        // skin, hat, face, neck, back, feet
        val LOOKS = arrayOf(
            arrayOf("skin_pink", "hat_party", "", "", "", ""),
            arrayOf("skin_mint", "", "face_shades", "", "", ""),
            arrayOf("skin_gold", "hat_crown", "", "", "", ""),
            arrayOf("skin_gray", "hat_top", "face_monocle", "neck_bowtie", "", ""),
            arrayOf("skin_dark", "", "", "neck_scarf", "back_cape", "")
        )
    }

    override val coinRate = 0.3f
    override val versusLimitMs = 11 * 60_000L
    override fun currentScore() = score

    private class Bot(var x: Float, var y: Float, val look: Int) {
        var ang = 0f
        var wx = x
        var wy = y
        var stunUntil = 0L
        var phase = 0f
        var moving = false
    }

    private val map = HuntMaps.ALL[mapIndex.coerceIn(0, HuntMaps.ALL.size - 1)]
    private val n = map.rows.size
    private val grid = Array(n) { y -> CharArray(n) { x -> map.rows[y][x] } }
    private val bots = ArrayList<Bot>()
    private var sprites: Array<Array<Bitmap>> = emptyArray()
    private var mini: Bitmap? = null

    private var px = 1.5f
    private var py = 1.5f
    private var ang = 0f
    private var pitch = 0f
    private var itId = -1 // -1 = you are "it", otherwise the index of the bot who is
    private var score = 0
    private var tags = 0
    private var startAt = 0L
    private var lastAt = 0L
    private var safeMs = 0f
    private var thinkAt = 0L
    private var tagReadyAt = 0L
    private var flash = ""
    private var flashUntil = 0L
    private var lastStatus = ""

    private val dIt = IntArray(n * n)
    private val dTarget = IntArray(n * n)
    private var zbuf = FloatArray(0)

    // touch controls
    private var movePid = -1
    private var lookPid = -1
    private var moveOx = 0f
    private var moveOy = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var lastLookX = 0f
    private var lastLookY = 0f

    private val colW: Int get() = maxOf(2, (2 * d).toInt())

    private val skyP = Paint()
    private val floorP = Paint()
    private val wallP = Paint()
    private val spriteP = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val markP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(229, 57, 53) }
    private val markLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE }
    private val uiP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val status = TextView(ctx).apply {
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
        val p = (16 * d).toInt()
        setPadding(p, 0, p, 0)
    }

    init {
        hud.setTextColor(Color.WHITE)
        hud.setShadowLayer(5f, 0f, 0f, Color.BLACK)
        val top = ((if (versus != null) 74 else 50) * d).toInt()
        addView(
            status,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { topMargin = top }
        )
    }

    // ---------- setup ----------

    private fun solid(x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= n || y >= n) return true
        val c = grid[y][x]
        return c != '.' && c != 'P'
    }

    private fun free(x: Float, y: Float): Boolean {
        val r = 0.22f
        return !solid(floor(x - r).toInt(), floor(y - r).toInt()) &&
            !solid(floor(x + r).toInt(), floor(y - r).toInt()) &&
            !solid(floor(x - r).toInt(), floor(y + r).toInt()) &&
            !solid(floor(x + r).toInt(), floor(y + r).toInt())
    }

    override fun reset() {
        val now = SystemClock.uptimeMillis()
        for (y in 0 until n) for (x in 0 until n) if (grid[y][x] == 'P') { px = x + 0.5f; py = y + 0.5f }
        ang = atan2(n / 2f - py, n / 2f - px)
        pitch = 0f

        bots.clear()
        val cells = ArrayList<Pair<Int, Int>>()
        for (y in 0 until n) for (x in 0 until n) if (!solid(x, y)) cells.add(x to y)
        cells.shuffle()
        var minDist = 6f
        var tries = 0
        while (bots.size < LOOKS.size && tries < 40) {
            tries++
            val cand = cells.firstOrNull { (x, y) ->
                val fx = x + 0.5f
                val fy = y + 0.5f
                hypot(fx - px, fy - py) >= minDist && bots.none { hypot(it.x - fx, it.y - fy) < 3f }
            }
            if (cand != null) {
                bots.add(Bot(cand.first + 0.5f, cand.second + 0.5f, bots.size))
                cells.shuffle()
            } else {
                minDist = max(0f, minDist - 1f)
            }
        }
        while (bots.size < LOOKS.size) {
            val c = cells.random()
            bots.add(Bot(c.first + 0.5f, c.second + 0.5f, bots.size))
        }

        itId = -1
        score = 0
        tags = 0
        safeMs = 0f
        startAt = now
        lastAt = now
        thinkAt = 0L
        tagReadyAt = now + 2000L // the geese get a head start
        flash = ""
        flashUntil = 0L
        lastStatus = ""
        movePid = -1
        lookPid = -1

        zbuf = FloatArray(max(2, (width + colW - 1) / colW))
        val h = height.toFloat()
        skyP.shader = LinearGradient(0f, 0f, 0f, h / 2f, map.sky1, map.sky2, Shader.TileMode.CLAMP)
        floorP.shader = LinearGradient(0f, h / 2f, 0f, h, map.floor1, map.floor2, Shader.TileMode.CLAMP)
        if (sprites.isEmpty()) sprites = buildSprites()
        buildMini()
        think()
    }

    /** Each goose is drawn once into a picture (2 walking frames) and then scaled in 3D. */
    private fun buildSprites(): Array<Array<Bitmap>> = Array(LOOKS.size) { li ->
        val lk = LOOKS[li]
        Array(2) { f ->
            val v = GooseView(context, 0.8f)
            v.fixedLook = true
            v.lookSkin = lk[0]; v.lookHat = lk[1]; v.lookFace = lk[2]
            v.lookNeck = lk[3]; v.lookBack = lk[4]; v.lookFeet = lk[5]
            v.walking = true
            v.phase = if (f == 0) 0.7f else 2.3f
            v.measure(
                View.MeasureSpec.makeMeasureSpec(v.sizeW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(v.sizeH, View.MeasureSpec.EXACTLY)
            )
            v.layout(0, 0, v.sizeW, v.sizeH)
            val bmp = Bitmap.createBitmap(v.sizeW, v.sizeH, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(bmp))
            bmp
        }
    }

    private fun buildMini() {
        val size = (92 * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint()
        p.color = Color.argb(150, 0, 0, 0)
        cv.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        val cs = size.toFloat() / n
        for (y in 0 until n) for (x in 0 until n) {
            if (solid(x, y)) {
                p.color = map.walls[grid[y][x]] ?: Color.GRAY
                cv.drawRect(x * cs, y * cs, (x + 1) * cs, (y + 1) * cs, p)
            }
        }
        mini = bmp
    }

    // ---------- touch: left thumb moves, right thumb looks ----------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val id = e.getPointerId(idx)
                val x = e.getX(idx)
                val y = e.getY(idx)
                if (x < width / 2f && movePid == -1) {
                    movePid = id; moveOx = x; moveOy = y; moveX = x; moveY = y
                } else if (x >= width / 2f && lookPid == -1) {
                    lookPid = id; lastLookX = x; lastLookY = y
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == movePid) {
                        moveX = e.getX(i); moveY = e.getY(i)
                    } else if (id == lookPid) {
                        val x = e.getX(i)
                        val y = e.getY(i)
                        ang += (x - lastLookX) * 0.006f
                        pitch = (pitch - (y - lastLookY) * 0.5f).coerceIn(-0.22f * height, 0.22f * height)
                        lastLookX = x; lastLookY = y
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == movePid) movePid = -1
                if (id == lookPid) lookPid = -1
                if (a != MotionEvent.ACTION_POINTER_UP) { movePid = -1; lookPid = -1 }
            }
        }
        return true
    }

    // ---------- game logic ----------

    override fun tick() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastAt) / 1000f).coerceIn(0.001f, 0.05f)
        lastAt = now
        val elapsed = now - startAt
        if (elapsed >= ROUND_MS) { gameOver(trf("You tagged %d geese!", tags), score); return }

        updatePlayer(dt)
        if (now >= thinkAt) { thinkAt = now + 350; think() }
        for (i in bots.indices) moveBot(i, bots[i], dt, now)
        checkTags(now)

        if (itId >= 0) { // points for every second you are not "it"
            safeMs += dt * 1000f
            while (safeMs >= 1000f) { score++; safeMs -= 1000f }
        }
        val secs = ((ROUND_MS - elapsed) / 1000).toInt().coerceIn(0, 600) + 1
        hud.text = trf("Score: %d     Time: %s", score, String.format("%d:%02d", secs / 60, secs % 60))
        val st = if (itId < 0) tr("🔴 You are IT! Touch a goose!") else tr("🟢 Run! A goose is hunting!")
        if (st != lastStatus) { lastStatus = st; status.text = st }
        invalidate()
    }

    private fun updatePlayer(dt: Float) {
        val dx = cos(ang)
        val dy = sin(ang)
        var fwd = 0f
        var str = 0f
        if (movePid != -1) {
            val r = 56f * d
            var jx = (moveX - moveOx) / r
            var jy = (moveY - moveOy) / r
            val len = hypot(jx, jy)
            if (len > 1f) { jx /= len; jy /= len }
            fwd = -jy
            str = jx
        }
        val sp = 3.0f * dt
        val vx = (dx * fwd - dy * str) * sp
        val vy = (dy * fwd + dx * str) * sp
        if (free(px + vx, py)) px += vx
        if (free(px, py + vy)) py += vy
    }

    private fun bfs(sx: Int, sy: Int, out: IntArray) {
        out.fill(Int.MAX_VALUE)
        val q = IntArray(n * n)
        var head = 0
        var tail = 0
        val start = sy.coerceIn(0, n - 1) * n + sx.coerceIn(0, n - 1)
        out[start] = 0
        q[tail++] = start
        while (head < tail) {
            val cur = q[head++]
            val cx = cur % n
            val cy = cur / n
            val dd = out[cur] + 1
            for (k in 0 until 4) {
                val nx = cx + DX[k]
                val ny = cy + DY[k]
                if (solid(nx, ny)) continue
                val ni = ny * n + nx
                if (out[ni] == Int.MAX_VALUE) { out[ni] = dd; q[tail++] = ni }
            }
        }
    }

    /** Works out distance maps: how far everything is from whoever is "it", and from the chaser's victim. */
    private fun think() {
        val ix = if (itId < 0) px else bots[itId].x
        val iy = if (itId < 0) py else bots[itId].y
        bfs(ix.toInt(), iy.toInt(), dIt)
        if (itId >= 0) {
            val chaser = bots[itId]
            var best = hypot(px - chaser.x, py - chaser.y)
            var tx = px
            var ty = py
            for (j in bots.indices) {
                if (j == itId) continue
                val dd = hypot(bots[j].x - chaser.x, bots[j].y - chaser.y)
                if (dd < best) { best = dd; tx = bots[j].x; ty = bots[j].y }
            }
            bfs(tx.toInt(), ty.toInt(), dTarget)
        }
        for (i in bots.indices) chooseCell(i, bots[i])
    }

    private fun chooseCell(i: Int, b: Bot) {
        val cx = b.x.toInt()
        val cy = b.y.toInt()
        var bx = cx
        var by = cy
        if (i == itId) { // hunter: step towards the victim
            var best = dTarget[cy * n + cx]
            for (k in 0 until 4) {
                val nx = cx + DX[k]
                val ny = cy + DY[k]
                if (solid(nx, ny)) continue
                val dd = dTarget[ny * n + nx]
                if (dd < best) { best = dd; bx = nx; by = ny }
            }
        } else { // everyone else: run away from whoever is "it"
            val here = dIt[cy * n + cx]
            if (here > 10 && Random.nextInt(3) > 0) {
                val k = Random.nextInt(4)
                if (!solid(cx + DX[k], cy + DY[k])) { bx = cx + DX[k]; by = cy + DY[k] }
            } else {
                var best = -1
                for (k in (0 until 4).shuffled()) {
                    val nx = cx + DX[k]
                    val ny = cy + DY[k]
                    if (solid(nx, ny)) continue
                    val dd = dIt[ny * n + nx]
                    if (dd > best) { best = dd; bx = nx; by = ny }
                }
                if (best < here) { bx = cx; by = cy } // never run towards the hunter
            }
        }
        b.wx = bx + 0.5f
        b.wy = by + 0.5f
    }

    private fun moveBot(i: Int, b: Bot, dt: Float, now: Long) {
        if (now < b.stunUntil) { b.moving = false; return }
        val dx = b.wx - b.x
        val dy = b.wy - b.y
        val dist = hypot(dx, dy)
        if (dist < 0.08f) { chooseCell(i, b); b.moving = false; return }
        val speed = if (i == itId) 2.7f else 2.4f
        val step = min(dist, speed * dt)
        b.x += dx / dist * step
        b.y += dy / dist * step
        b.ang = atan2(dy, dx)
        b.moving = true
        b.phase += dt * 10f
    }

    private fun checkTags(now: Long) {
        if (now < tagReadyAt) return
        if (itId < 0) { // you are "it": touch a goose
            for (i in bots.indices) {
                if (hypot(bots[i].x - px, bots[i].y - py) < HIT) { transfer(i, now); return }
            }
        } else {
            val h = bots[itId]
            if (now < h.stunUntil) return
            if (hypot(px - h.x, py - h.y) < HIT) { transfer(-1, now); return }
            for (j in bots.indices) {
                if (j != itId && hypot(bots[j].x - h.x, bots[j].y - h.y) < HIT) { transfer(j, now); return }
            }
        }
    }

    private fun transfer(newId: Int, now: Long) {
        val playerWasIt = itId < 0
        itId = newId
        tagReadyAt = now + 1500L
        if (newId >= 0) bots[newId].stunUntil = now + 1500L
        if (playerWasIt && newId >= 0) {
            tags++
            score += 5
            flashMsg(tr("Tagged! +5"))
            Sound.play(500.0, 800.0, 90)
        } else if (newId < 0) {
            flashMsg(tr("You got caught!"))
            Sound.play(300.0, 150.0, 220)
        }
        think()
    }

    private fun flashMsg(s: String) {
        flash = s
        flashUntil = SystemClock.uptimeMillis() + 1400L
    }

    // ---------- drawing ----------

    override fun onDraw(c: Canvas) {
        if (zbuf.isEmpty() || sprites.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        val horizon = h / 2f + pitch
        c.drawRect(0f, 0f, w, horizon, skyP)
        c.drawRect(0f, horizon, w, h, floorP)
        castColumns(c, horizon)
        drawSprites(c, horizon)
        drawOverlay(c, w, h)
    }

    /** The 3D part: one ray per screen column finds the wall, and its distance sets how tall it is drawn. */
    private fun castColumns(c: Canvas, horizon: Float) {
        val h = height.toFloat()
        val cols = zbuf.size
        val dirX = cos(ang)
        val dirY = sin(ang)
        val plX = -dirY * FOV
        val plY = dirX * FOV
        for (i in 0 until cols) {
            val camX = 2f * i / (cols - 1) - 1f
            val rdx = dirX + plX * camX
            val rdy = dirY + plY * camX
            var mx = floor(px).toInt()
            var my = floor(py).toInt()
            val ddx = if (rdx == 0f) 1e9f else abs(1f / rdx)
            val ddy = if (rdy == 0f) 1e9f else abs(1f / rdy)
            val stepX: Int
            var sdx: Float
            if (rdx < 0f) { stepX = -1; sdx = (px - mx) * ddx } else { stepX = 1; sdx = (mx + 1f - px) * ddx }
            val stepY: Int
            var sdy: Float
            if (rdy < 0f) { stepY = -1; sdy = (py - my) * ddy } else { stepY = 1; sdy = (my + 1f - py) * ddy }
            var side = 0
            var ch = '#'
            var guard = 0
            while (guard++ < 40) {
                if (sdx < sdy) { sdx += ddx; mx += stepX; side = 0 } else { sdy += ddy; my += stepY; side = 1 }
                if (mx < 0 || my < 0 || mx >= n || my >= n) { ch = '#'; break }
                val g = grid[my][mx]
                if (g != '.' && g != 'P') { ch = g; break }
            }
            val perp = max(0.05f, if (side == 0) sdx - ddx else sdy - ddy)
            zbuf[i] = perp

            val base = map.walls[ch] ?: Color.GRAY
            val k = (1f - perp / 14f).coerceIn(0.3f, 1f) * (if (side == 1) 0.78f else 1f)
            wallP.color = Color.rgb(
                (Color.red(base) * k).toInt(), (Color.green(base) * k).toInt(), (Color.blue(base) * k).toInt()
            )
            val lineH = h / perp
            val left = (i * colW).toFloat()
            c.drawRect(left, horizon - lineH / 2f, left + colW, horizon + lineH / 2f, wallP)
        }
    }

    private fun drawSprites(c: Canvas, horizon: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val dirX = cos(ang)
        val dirY = sin(ang)
        val plX = -dirY * FOV
        val plY = dirX * FOV
        val inv = 1f / (plX * dirY - dirX * plY)
        val frame = ((SystemClock.uptimeMillis() / 160) % 2).toInt()
        val order = bots.indices.sortedByDescending { hypot(bots[it].x - px, bots[it].y - py) }
        for (i in order) {
            val b = bots[i]
            val sx = b.x - px
            val sy = b.y - py
            val tx = inv * (dirY * sx - dirX * sy)
            val ty = inv * (-plY * sx + plX * sy)
            if (ty < 0.15f) continue
            val screenX = w / 2f * (1f + tx / ty)
            val unit = h / ty
            val sh = unit * 0.8f
            val bmp = sprites[b.look][if (b.moving) frame else 0]
            val sw = sh * bmp.width / bmp.height
            val floorY = horizon + unit / 2f
            val left = screenX - sw / 2f
            val right = screenX + sw / 2f
            val top = floorY - sh * 1.02f
            val flip = (cos(b.ang) * -dirY + sin(b.ang) * dirX) < 0f

            // draw only the columns where nothing is standing in front of the goose
            val c0 = max(0, (left / colW).toInt())
            val c1 = min(zbuf.size - 1, (right / colW).toInt())
            var runStart = -1
            for (col in c0..c1 + 1) {
                val visible = col <= c1 && zbuf[col] > ty
                if (visible && runStart < 0) runStart = col
                if (!visible && runStart >= 0) {
                    c.save()
                    c.clipRect((runStart * colW).toFloat(), 0f, (col * colW).toFloat(), h)
                    if (flip) c.scale(-1f, 1f, screenX, 0f)
                    c.drawBitmap(bmp, null, android.graphics.RectF(left, top, right, floorY + sh * 0.02f), spriteP)
                    c.restore()
                    runStart = -1
                }
            }

            // red marker over the goose that is "it"
            val mid = (screenX / colW).toInt().coerceIn(0, zbuf.size - 1)
            if (i == itId && zbuf[mid] > ty) {
                val tri = Path().apply {
                    moveTo(screenX - sh * 0.13f, top - sh * 0.28f)
                    lineTo(screenX + sh * 0.13f, top - sh * 0.28f)
                    lineTo(screenX, top - sh * 0.06f)
                    close()
                }
                markLine.strokeWidth = max(1f, sh * 0.02f)
                c.drawPath(tri, markP)
                c.drawPath(tri, markLine)
            }
        }
    }

    private fun drawOverlay(c: Canvas, w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        if (itId < 0) { // red pulsing frame while you are "it"
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 14f * d
            uiP.color = Color.argb(60 + (40 * (1 + sin(now / 150f))).toInt(), 229, 57, 53)
            c.drawRect(0f, 0f, w, h, uiP)
        }

        val m = mini
        if (m != null) {
            val mx = w - m.width - 8 * d
            val my = 8 * d
            c.drawBitmap(m, mx, my, null)
            val cs = m.width.toFloat() / n
            uiP.style = Paint.Style.FILL
            for (i in bots.indices) {
                uiP.color = if (i == itId) Color.rgb(255, 60, 60) else Color.rgb(255, 235, 59)
                c.drawCircle(mx + bots[i].x * cs, my + bots[i].y * cs, cs * 0.45f, uiP)
            }
            val ax = mx + px * cs
            val ay = my + py * cs
            uiP.color = if (itId < 0) Color.rgb(255, 60, 60) else Color.WHITE
            val tri = Path().apply {
                moveTo(ax + cos(ang) * cs * 0.9f, ay + sin(ang) * cs * 0.9f)
                lineTo(ax + cos(ang + 2.5f) * cs * 0.7f, ay + sin(ang + 2.5f) * cs * 0.7f)
                lineTo(ax + cos(ang - 2.5f) * cs * 0.7f, ay + sin(ang - 2.5f) * cs * 0.7f)
                close()
            }
            c.drawPath(tri, uiP)
        }

        if (movePid != -1) { // on-screen joystick
            val r = 56f * d
            var jx = moveX - moveOx
            var jy = moveY - moveOy
            val len = hypot(jx, jy)
            if (len > r) { jx = jx / len * r; jy = jy / len * r }
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 3f * d
            uiP.color = Color.argb(130, 255, 255, 255)
            c.drawCircle(moveOx, moveOy, r, uiP)
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(170, 255, 255, 255)
            c.drawCircle(moveOx + jx, moveOy + jy, 20f * d, uiP)
        }

        if (now < flashUntil) {
            textP.textSize = 26f * d
            c.drawText(flash, w / 2f, h * 0.22f, textP)
        }
        if (now - startAt < 5000L) {
            textP.textSize = 14f * d
            c.drawText(tr("Left thumb: move   Right thumb: look around"), w / 2f, h * 0.86f, textP)
        }
    }
}
