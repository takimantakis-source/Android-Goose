plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.goosedroid"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.goosedroid"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "FIREBASE_API_KEY", "\"${System.getenv("FIREBASE_API_KEY") ?: ""}\"")
        buildConfigField("String", "FIREBASE_DB_URL", "\"${System.getenv("FIREBASE_DB_URL") ?: ""}\"")
        buildConfigField("String", "YT_API_KEY", "\"${System.getenv("YT_API_KEY") ?: ""}\"")
        buildConfigField("String", "GROQ_KEY", "\"${System.getenv("GROQ_KEY") ?: ""}\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
}

dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
}
