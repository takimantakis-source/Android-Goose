package com.example.goosedroid

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * The goose chatbot. With a Claude API key (entered in the chat) it is a real AI.
 * Without a key it answers a few simple things on its own.
 */
object Chat {
    val history = ArrayList<Pair<String, String>>() // "user" / "assistant", text

    fun key(ctx: Context): String = Store.prefs(ctx).getString("chat_key", "") ?: ""
    fun hasKey(ctx: Context) = key(ctx).isNotBlank()
    fun setKey(ctx: Context, k: String) { Store.prefs(ctx).edit().putString("chat_key", k.trim()).apply() }
    private fun model(ctx: Context) = Store.prefs(ctx).getString("chat_model", "claude-haiku-5-5") ?: "claude-haiku-5-5"

    private fun system(): String = listOf(
        "You are Gus, a cheerful goose who lives inside the GooseDroid Android app.",
        "Be friendly and playful, keep answers short (1 to 4 sentences) and honk now and then.",
        "Always answer in ${Lang.englishName(Lang.code)} unless the user writes in another language.",
        "You can explain the app: a goose walks over the screen (tap = honk, drag = move);",
        "minigames earn coins (Catch the Goose, Bread Catch, Honk Memory, Flappy Goose, Whack-a-Goose,",
        "Goose Hunt, Goose Obby, Goose Shove); the shop sells skins and accessories;",
        "swipe right on the main menu for the Extras shop (pets and honk sounds);",
        "the music player has covers, playlists, designs and settings; swipe left opens this chat;",
        "the gear icon has language settings. Never ask for passwords or personal data."
    ).joinToString(" ")

    /** Sends the conversation to the Claude API. onDone(reply, error) runs on the main thread. */
    fun ask(ctx: Context, onDone: (String?, String?) -> Unit) {
        val app = ctx.applicationContext
        val k = key(app)
        val m = model(app)
        val msgs = JSONArray()
        var started = false
        for ((role, text) in history.takeLast(12)) {
            if (!started && role != "user") continue // the API wants the first message from the user
            started = true
            msgs.put(JSONObject().put("role", role).put("content", text))
        }
        thread {
            var reply: String? = null
            var err: String? = null
            try {
                val body = JSONObject()
                    .put("model", m)
                    .put("max_tokens", 500)
                    .put("system", system())
                    .put("messages", msgs)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-api-key", k)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code in 200..299) {
                    val arr = JSONObject(txt).getJSONArray("content")
                    val sb = StringBuilder()
                    for (i in 0 until arr.length()) {
                        val b = arr.getJSONObject(i)
                        if (b.optString("type") == "text") sb.append(b.optString("text"))
                    }
                    reply = sb.toString().trim().ifEmpty { "HONK?" }
                } else {
                    err = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (_: Exception) { "HTTP $code" }
                }
                c.disconnect()
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            Handler(Looper.getMainLooper()).post { onDone(reply, err) }
        }
    }

    /** Answers without a key: a few simple things about the app. */
    fun offline(text: String): String {
        val s = text.lowercase()
        return when {
            s.contains("hello") || s.contains("hi") || s.contains("hallo") -> tr("HONK! Hello!")
            s.contains("coin") || s.contains("münz") -> tr("Coins come from the minigames. Spend them in the shop!")
            s.contains("shop") || s.contains("buy") || s.contains("kauf") -> tr("Swipe right for the Extras shop, or tap 🛍 for skins and accessories.")
            s.contains("game") || s.contains("play") || s.contains("spiel") -> tr("Try Goose Obby, Goose Hunt or Goose Shove. They are 3D!")
            s.contains("music") || s.contains("song") || s.contains("musik") -> tr("Tap 🎵 at the top left for the music player.")
            else -> tr("I only know simple things without a key. Tap 🔑 above to add a Claude API key, then I can really talk!")
        }
    }
}
