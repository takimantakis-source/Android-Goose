package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Swipe left on the main menu to chat with the goose. */
class ChatActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var swipe: android.view.GestureDetector

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        swipe = makeSwipe(this, null) { finish() }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = tr("💬 Goose Chat"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Button(this).apply { text = "🔑"; setOnClickListener { keyDialog() } })
        head.addView(Button(this).apply { text = "🗑"; setOnClickListener { Chat.history.clear(); seed() } })
        root.addView(head)

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(box) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = tr("Type a message..."); maxLines = 4 }
        sendBtn = Button(this).apply { text = tr("Send"); setOnClickListener { send() } }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sendBtn)
        root.addView(row)
        setContentView(root)
        seed()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun seed() {
        box.removeAllViews()
        if (Chat.history.isEmpty()) Chat.history.add("assistant" to tr("Honk! I'm your goose. Ask me anything!"))
        for ((role, text) in Chat.history) addBubble(text, role == "user")
        scrollDown()
    }

    private fun addBubble(text: String, mine: Boolean): TextView {
        val dark = ThemeMode.dark(this)
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (mine) Color.WHITE else if (dark) Color.WHITE else Color.BLACK)
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            maxWidth = (resources.displayMetrics.widthPixels * 0.8f).toInt()
            background = GradientDrawable().apply {
                cornerRadius = dp(18f).toFloat()
                setColor(if (mine) Color.rgb(33, 150, 243) else if (dark) Color.rgb(60, 63, 70) else Color.rgb(235, 235, 235))
            }
        }
        box.addView(tv, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(8f)
        })
        return tv
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        addBubble(t, true)
        Chat.history.add("user" to t)
        if (!Chat.hasKey(this)) {
            val r = Chat.offline(t)
            Chat.history.add("assistant" to r)
            addBubble(r, false)
            scrollDown()
            return
        }
        val typing = addBubble(tr("Thinking..."), false)
        sendBtn.isEnabled = false
        scrollDown()
        Chat.ask(this) { reply, err ->
            sendBtn.isEnabled = true
            if (reply != null) {
                typing.text = reply
                Chat.history.add("assistant" to reply)
            } else {
                typing.text = "⚠ " + (err ?: "")
                if (Chat.history.isNotEmpty() && Chat.history.last().first == "user") Chat.history.removeAt(Chat.history.size - 1)
            }
            scrollDown()
        }
    }

    private fun keyDialog() {
        val et = EditText(this)
        et.hint = "sk-ant-..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        et.setText(Chat.key(this))
        AlertDialog.Builder(this)
            .setTitle(tr("Chat key (Claude API)"))
            .setMessage(tr("Paste an API key from console.anthropic.com. It is saved only on this phone and sent only to Anthropic. Using it can cost money. Without a key I only know a few simple things."))
            .setView(et)
            .setPositiveButton(tr("Save")) { _, _ ->
                Chat.setKey(this, et.text.toString())
                Toast.makeText(this, "✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }
}
