package com.example.goosedroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/**
 * Real accounts: e-mail + password with e-mail verification (Firebase Authentication), and your
 * coins, playlists, shop items and settings saved in the cloud (Firebase Realtime Database), so you
 * can sign in on any phone. You create the free Firebase project yourself; see the setup steps.
 */
object Cloud {
    class Session(val uid: String, val idToken: String, val refresh: String)
    class Login(val session: Session?, val verified: Boolean, val error: String?)
    private class Res(val code: Int, val body: String)

    private fun p(ctx: Context) = Store.prefs(ctx)

    private fun pref(ctx: Context, k: String, d: String): String {
        val v = p(ctx).getString(k, "") ?: ""
        return if (v.isNotBlank()) v.trim() else d
    }

    fun apiKey(ctx: Context) = pref(ctx, "fb_key", BuildConfig.FIREBASE_API_KEY)
    fun dbUrl(ctx: Context) = pref(ctx, "fb_db", BuildConfig.FIREBASE_DB_URL).trimEnd('/')
    fun configured(ctx: Context) = apiKey(ctx).isNotBlank() && dbUrl(ctx).isNotBlank()
    fun signedIn(ctx: Context) = p(ctx).getBoolean("cloud_in", false)

    // ---------- plumbing ----------

    private fun http(method: String, url: String, body: String? = null, type: String = "application/json"): Res {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 30000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("content-type", type)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Res(code, txt)
    }

    private fun idp(ctx: Context, action: String, body: JSONObject) =
        http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:$action?key=${apiKey(ctx)}", body.toString())

    private fun err(r: Res): String = try {
        JSONObject(r.body).getJSONObject("error").getString("message")
    } catch (_: Exception) {
        try { JSONObject(r.body).getString("error") } catch (_: Exception) { "HTTP ${r.code}" }
    }

    private fun friendly(m: String): String = when {
        m.startsWith("EMAIL_EXISTS") -> tr("That email already has an account. Use \"Sign in to an existing account\".")
        m.startsWith("INVALID_LOGIN_CREDENTIALS") || m.startsWith("INVALID_PASSWORD") || m.startsWith("EMAIL_NOT_FOUND") ->
            tr("Wrong email or password.")
        m.startsWith("WEAK_PASSWORD") -> tr("Password: at least 6 characters.")
        m.startsWith("INVALID_EMAIL") -> tr("Please enter a valid email address.")
        m.startsWith("TOO_MANY_ATTEMPTS") -> tr("Too many attempts. Try again later.")
        else -> m
    }

    private fun session(r: Res): Session {
        val j = JSONObject(r.body)
        return Session(j.getString("localId"), j.getString("idToken"), j.getString("refreshToken"))
    }

    private fun sendVerify(ctx: Context, idToken: String) {
        idp(ctx, "sendOobCode", JSONObject().put("requestType", "VERIFY_EMAIL").put("idToken", idToken))
    }

    // ---------- accounts ----------

    fun signUp(ctx: Context, email: String, pw: String): Login {
        val r = idp(ctx, "signUp", JSONObject().put("email", email).put("password", pw).put("returnSecureToken", true))
        if (r.code !in 200..299) return Login(null, false, friendly(err(r)))
        val s = session(r)
        sendVerify(ctx, s.idToken) // the account only works after the link in this email was opened
        return Login(s, false, null)
    }

    fun signIn(ctx: Context, email: String, pw: String): Login {
        val r = idp(ctx, "signInWithPassword", JSONObject().put("email", email).put("password", pw).put("returnSecureToken", true))
        if (r.code !in 200..299) return Login(null, false, friendly(err(r)))
        val s = session(r)
        val look = idp(ctx, "lookup", JSONObject().put("idToken", s.idToken))
        val verified = try {
            JSONObject(look.body).getJSONArray("users").getJSONObject(0).optBoolean("emailVerified", false)
        } catch (_: Exception) { false }
        return Login(s, verified, null)
    }

    /** Sends the verification email again. Returns an error message or null. */
    fun resend(ctx: Context, email: String, pw: String): String? {
        val l = signIn(ctx, email, pw)
        if (l.session == null) return l.error
        sendVerify(ctx, l.session.idToken)
        return null
    }

    private fun token(ctx: Context): String? {
        val rt = p(ctx).getString("cloud_refresh", "") ?: ""
        if (rt.isBlank()) return null
        val r = http(
            "POST", "https://securetoken.googleapis.com/v1/token?key=${apiKey(ctx)}",
            "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8"), "application/x-www-form-urlencoded"
        )
        if (r.code !in 200..299) return null
        val j = JSONObject(r.body)
        p(ctx).edit().putString("cloud_refresh", j.optString("refresh_token", rt)).apply()
        return j.getString("id_token")
    }

    /**
     * Finishes a login. New account: uploads what this phone has. Existing account: downloads the
     * saved data (coins, playlists, ...) onto this phone. Returns an error message or null.
     */
    fun completeLogin(ctx: Context, s: Session, email: String, newName: String?): String? {
        p(ctx).edit()
            .putString("cloud_uid", s.uid).putString("cloud_refresh", s.refresh)
            .putString("acc_email", email.trim().lowercase())
            .putBoolean("cloud_in", true).putBoolean("acc_in", true).apply()
        if (newName != null) {
            p(ctx).edit().putString("acc_name", newName).apply()
            return push(ctx)
        }
        val rc = pullApply(ctx, false)
        if (rc < 0) return tr("Couldn't reach the cloud. Check your internet.")
        if ((p(ctx).getString("acc_name", "") ?: "").isBlank()) {
            val base = email.substringBefore('@').filter { it.isLetterOrDigit() || it == '_' }.take(14)
            p(ctx).edit().putString("acc_name", if (base.length >= 3) base else "goose$base").apply()
        }
        return if (rc == 0) push(ctx) else null
    }

    // ---------- saved data ----------

    private fun excluded(k: String): Boolean =
        k.startsWith("acc_") || k.startsWith("cloud_") || k.startsWith("fb_") || k.startsWith("trn_") ||
            k == "chat_key" || k == "yt_key" || k == "m_bg_uri" || k == "voter_id" ||
            (k.startsWith("tr_") && Lang.languages.contains(k.removePrefix("tr_")))

    private fun snapshot(ctx: Context): JSONObject {
        val out = JSONObject()
        for ((k, v) in p(ctx).all) {
            if (excluded(k) || v == null) continue
            val e = JSONObject()
            when (v) {
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Boolean -> e.put("t", "b").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                else -> continue
            }
            out.put(k, e)
        }
        return out
    }

    private fun avatarB64(ctx: Context): String? {
        val a = Profile.avatar(ctx) ?: return null
        val s = Bitmap.createScaledBitmap(a, 128, 128, true)
        val bo = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    /** Uploads this phone's data. Returns an error message or null. */
    fun push(ctx: Context): String? {
        val tok = token(ctx) ?: return tr("Couldn't reach the cloud. Check your internet.")
        val uid = p(ctx).getString("cloud_uid", "") ?: ""
        val now = System.currentTimeMillis()
        val node = JSONObject().put("name", Profile.username(ctx)).put("updated", now).put("data", snapshot(ctx))
        avatarB64(ctx)?.let { node.put("avatar", it) }
        val r = http("PUT", "${dbUrl(ctx)}/users/$uid.json?auth=$tok", node.toString())
        if (r.code !in 200..299) return err(r)
        p(ctx).edit().putLong("cloud_last", now).apply()
        return null
    }

    /** Downloads the saved data. Returns 1 = applied, 0 = nothing to apply, -1 = error. */
    fun pullApply(ctx: Context, onlyIfNewer: Boolean): Int {
        val tok = token(ctx) ?: return -1
        val uid = p(ctx).getString("cloud_uid", "") ?: ""
        val r = http("GET", "${dbUrl(ctx)}/users/$uid.json?auth=$tok")
        if (r.code !in 200..299) return -1
        if (r.body.isBlank() || r.body.trim() == "null") return 0
        val node = JSONObject(r.body)
        val upd = node.optLong("updated", 0L)
        if (onlyIfNewer && upd <= p(ctx).getLong("cloud_last", 0L)) return 0
        val ed = p(ctx).edit()
        val data = node.optJSONObject("data")
        if (data != null) {
            for (k in data.keys()) {
                if (excluded(k)) continue
                val e = data.getJSONObject(k)
                when (e.getString("t")) {
                    "i" -> ed.putInt(k, e.getInt("v"))
                    "l" -> ed.putLong(k, e.getLong("v"))
                    "b" -> ed.putBoolean(k, e.getBoolean("v"))
                    "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                    else -> ed.putString(k, e.getString("v"))
                }
            }
        }
        val name = node.optString("name")
        if (name.isNotBlank()) ed.putString("acc_name", name)
        ed.putLong("cloud_last", upd)
        ed.apply()
        val av = node.optString("avatar")
        if (av.isNotBlank()) {
            try {
                val bytes = Base64.decode(av, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { Profile.saveAvatar(ctx, it) }
            } catch (_: Exception) {}
        }
        Lang.init(ctx)
        Cosmetics.refresh(ctx)
        return 1
    }

    private val main = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null

    /** Saves to the cloud a few seconds after the last change (many changes -> one upload). */
    fun syncSoon(ctx: Context) {
        if (!signedIn(ctx) || !configured(ctx)) return
        val app = ctx.applicationContext
        pending?.let { main.removeCallbacks(it) }
        val r = Runnable { thread { try { push(app) } catch (_: Exception) {} } }
        pending = r
        main.postDelayed(r, 8000L)
    }

    /** On app start: if another phone saved newer data, take it. cb(true) means something changed. */
    fun pullIfNewer(ctx: Context, cb: (Boolean) -> Unit) {
        if (!signedIn(ctx) || !configured(ctx)) return
        val app = ctx.applicationContext
        thread {
            val rc = try { pullApply(app, true) } catch (_: Exception) { -1 }
            main.post { cb(rc == 1) }
        }
    }

    /** Deletes the account and its saved data for good. Returns an error message or null. */
    fun deleteAccount(ctx: Context): String? {
        val tok = token(ctx) ?: return tr("Couldn't reach the cloud. Check your internet.")
        val uid = p(ctx).getString("cloud_uid", "") ?: ""
        http("DELETE", "${dbUrl(ctx)}/users/$uid.json?auth=$tok")
        val r = idp(ctx, "delete", JSONObject().put("idToken", tok))
        return if (r.code in 200..299) null else err(r)
    }
}
