package com.example.goosedroid

import android.content.Context

/** The second shop: little pets that follow your goose over the screen, and honk sounds. Not accessories. */
object Extras {
    class Pet(val id: String, val name: String, val price: Int, val skin: String, val hat: String)
    class Snd(val id: String, val name: String, val price: Int)

    val pets = listOf(
        Pet("pet_gosling", "Gosling", 100, "skin_gold", ""),
        Pet("pet_pink", "Pink chick", 100, "skin_pink", ""),
        Pet("pet_mint", "Mint chick", 120, "skin_mint", ""),
        Pet("pet_shadow", "Shadow chick", 150, "skin_dark", "hat_halo"),
        Pet("pet_party", "Party gosling", 200, "skin_gold", "hat_party"),
        Pet("pet_king", "King gosling", 300, "skin_classic", "hat_crown")
    )
    val sounds = listOf(
        Snd("honk_classic", "Classic honk", 0),
        Snd("honk_squeaky", "Squeaky toy", 80),
        Snd("honk_trumpet", "Trumpet", 120),
        Snd("honk_bass", "Deep bass", 150),
        Snd("honk_robot", "Robot", 200),
        Snd("honk_alarm", "Alarm", 250)
    )

    fun pet(id: String) = pets.firstOrNull { it.id == id }

    fun owned(ctx: Context, id: String) = id == "honk_classic" || Store.prefs(ctx).getBoolean("own_$id", false)

    fun buy(ctx: Context, id: String, price: Int): Boolean {
        if (owned(ctx, id)) return true
        val c = Store.coins(ctx)
        if (c < price) return false
        Store.prefs(ctx).edit().putInt("coins", c - price).putBoolean("own_$id", true).apply()
        Cloud.syncSoon(ctx)
        return true
    }

    fun equippedPets(ctx: Context): List<String> =
        (Store.prefs(ctx).getString("pets_eq", "") ?: "").split(",").filter { it.isNotEmpty() && pet(it) != null }

    fun setPets(ctx: Context, list: List<String>) {
        Store.prefs(ctx).edit().putString("pets_eq", list.joinToString(",")).apply()
        Cloud.syncSoon(ctx)
    }

    fun honkPack(ctx: Context): String = Store.prefs(ctx).getString("honk_pack", "honk_classic") ?: "honk_classic"

    fun setHonk(ctx: Context, id: String) {
        Store.prefs(ctx).edit().putString("honk_pack", id).apply()
        Cloud.syncSoon(ctx)
    }
}
