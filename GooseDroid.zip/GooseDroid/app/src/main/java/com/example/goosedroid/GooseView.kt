package com.example.goosedroid

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Draws the goose with plain Canvas shapes, so no image assets are needed. */
class GooseView(context: Context) : View(context) {
    var facingLeft = false
    var walking = false
    var phase = 0f
    var bubble: String? = null

    private val d = resources.displayMetrics.density
    val sizeW = (110 * d).toInt()
    val sizeH = (130 * d).toInt() // extra 20dp on top for the speech bubble

    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun stroke(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val white = fill(Color.WHITE)
    private val orange = fill(Color.rgb(255, 140, 0))
    private val black = fill(Color.BLACK)
    private val outline = stroke(Color.rgb(80, 80, 80), 1.3f)
    private val neckOutline = stroke(Color.rgb(80, 80, 80), 11f)
    private val neckWhite = stroke(Color.WHITE, 8.6f)
    private val legs = stroke(Color.rgb(255, 140, 0), 2.6f)
    private val bubbleFill = fill(Color.WHITE)
    private val bubbleLine = stroke(Color.DKGRAY, 2f * d)
    private val bubbleText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; textSize = 13 * d; typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        bubble?.let {
            val r = RectF(width * 0.12f, 1 * d, width * 0.88f, 20 * d)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleFill)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleLine)
            c.drawText(it, r.centerX(), r.centerY() + 5 * d, bubbleText)
        }

        c.save()
        c.translate(0f, (height - width).toFloat())
        val s = width / 100f
        c.scale(s, s)
        if (facingLeft) c.scale(-1f, 1f, 50f, 50f)
        if (walking) c.translate(0f, -abs(sin(phase)) * 2f)

        // legs + feet
        val step = if (walking) sin(phase) * 5f else 0f
        for (fx in floatArrayOf(42f + step, 54f - step)) {
            c.drawLine(fx, 80f, fx, 91f, legs)
            c.drawOval(RectF(fx - 6f, 89f, fx + 6f, 95f), orange)
        }
        // tail
        val tail = Path().apply { moveTo(24f, 66f); lineTo(6f, 56f); lineTo(26f, 78f); close() }
        c.drawPath(tail, white); c.drawPath(tail, outline)
        // body + wing
        val body = RectF(20f, 56f, 72f, 88f)
        c.drawOval(body, white); c.drawOval(body, outline)
        c.drawArc(RectF(30f, 62f, 62f, 82f), 10f, 150f, false, outline)
        // neck
        c.drawLine(62f, 64f, 72f, 36f, neckOutline)
        c.drawLine(62f, 64f, 72f, 36f, neckWhite)
        // head
        c.drawCircle(74f, 30f, 9f, white); c.drawCircle(74f, 30f, 9f, outline)
        // beak
        val beak = Path().apply { moveTo(81f, 27f); lineTo(96f, 32f); lineTo(81f, 37f); close() }
        c.drawPath(beak, orange); c.drawPath(beak, outline)
        // eye
        c.drawCircle(77f, 27f, 2f, black)
        c.restore()
    }
}
