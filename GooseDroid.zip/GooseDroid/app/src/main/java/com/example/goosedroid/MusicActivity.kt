package com.example.goosedroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MusicActivity : Activity() {
    private class Holder(val row: LinearLayout, val img: ImageView, val t1: TextView, val t2: TextView)

    private var all: List<Player.Track> = emptyList()
    private var list: List<Player.Track> = emptyList() // what the list currently shows
    private var kind = "all"                           // all | playlist | artist | album
    private var key: String? = null

    private lateinit var bgView: ImageView
    private lateinit var scrim: View
    private lateinit var titleView: TextView
    private lateinit var settingsBtn: Button
    private lateinit var ytBtn: Button
    private lateinit var search: EditText
    private lateinit var modeBtn: Button
    private lateinit var delBtn: Button
    private lateinit var info: TextView
    private lateinit var listView: ListView
    private lateinit var nowCard: LinearLayout
    private lateinit var artView: ImageView
    private lateinit var nowText: TextView
    private lateinit var seek: SeekBar
    private lateinit var prevBtn: Button
    private lateinit var playBtn: Button
    private lateinit var nextBtn: Button
    private lateinit var shuffleBtn: Button

    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var txt = Color.BLACK
    private var sig = ""

    private val placeholder: Bitmap by lazy {
        val b = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(224, 224, 224))
        c.drawText("🎵", 128f, 170f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 130f; textAlign = Paint.Align.CENTER
        })
        b
    }

    private val ticker = object : Runnable {
        override fun run() { progress(); handler.postDelayed(this, 500) }
    }

    private val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this, true)
        super.onCreate(savedInstanceState)
        val pad = dp(14f)

        val frame = FrameLayout(this)
        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(bgView, FrameLayout.LayoutParams(-1, -1))
        scrim = View(this)
        frame.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        frame.addView(content, FrameLayout.LayoutParams(-1, -1))

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        // header
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        titleView = TextView(this).apply { text = tr("🎵 Music"); textSize = 26f; typeface = Typeface.DEFAULT_BOLD }
        head.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        settingsBtn = btn("⚙") { startActivity(Intent(this, MusicSettingsActivity::class.java)) }
        settingsBtn.textSize = 20f
        ytBtn = btn("🎞") { startActivity(Intent(this, YtMusicActivity::class.java)) }
        ytBtn.textSize = 20f
        head.addView(ytBtn)
        head.addView(settingsBtn)
        content.addView(head)

        // search
        search = EditText(this).apply {
            hint = tr("Search songs...")
            isSingleLine = true
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyView() }
            })
        }
        content.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8f) })

        // browse row
        val modeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        modeBtn = btn("📂 ${tr("📱 Local music")} ▾") { browse() }
        delBtn = btn("🗑") { confirmDelete() }
        delBtn.visibility = View.GONE
        modeRow.addView(modeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        modeRow.addView(delBtn)
        content.addView(modeRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8f) })

        info = TextView(this).apply { text = tr("Loading your music..."); textSize = 13f; setPadding(dp(4f), dp(6f), 0, dp(6f)) }
        content.addView(info)

        // song list with covers
        listView = ListView(this).apply {
            divider = null
            setSelector(android.R.color.transparent)
            setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
        }
        content.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))

        // now playing card
        nowCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, dp(8f))
        }
        val nowRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        artView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        nowRow.addView(artView, LinearLayout.LayoutParams(dp(80f), dp(80f)))
        nowText = TextView(this).apply { textSize = 16f; setPadding(pad, 0, 0, 0) }
        nowRow.addView(nowText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nowCard.addView(nowRow)

        seek = SeekBar(this)
        nowCard.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                Player.seekTo(seek.progress * 1000)
            }
        })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        prevBtn = btn("⏮") { Player.prev() }
        playBtn = btn("▶") {
            if (Player.index < 0 && list.isNotEmpty()) { Player.tracks = list; Player.play(this, 0) }
            else Player.toggle()
        }
        nextBtn = btn("⏭") { Player.next() }
        shuffleBtn = btn("🔀") { Player.shuffle = !Player.shuffle; refresh() }
        for (b in listOf(prevBtn, playBtn, nextBtn, shuffleBtn)) {
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4f), 0, dp(4f), 0) })
        }
        nowCard.addView(row)
        content.addView(nowCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10f) })

        setContentView(frame)
        listView.adapter = SongAdapter()
        applyDesign()

        listView.setOnItemClickListener { _, _, pos, _ ->
            Player.tracks = list
            Player.play(this, pos)
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos < list.size) songMenu(list[pos])
            true
        }

        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(permission), 7)
    }

    // ---------- design ----------

    private fun applyDesign() {
        val accent = MusicDesign.accent(this)
        txt = MusicDesign.textColor(this)
        val onA = MusicDesign.onAccent(accent)
        val dim = Color.argb(160, Color.red(txt), Color.green(txt), Color.blue(txt))
        scrim.setBackgroundColor(MusicDesign.scrim(this))
        for (t in listOf(titleView, info, nowText, search)) t.setTextColor(txt)
        search.setHintTextColor(dim)
        search.background = MusicDesign.panel(this, 16f)
        listView.background = MusicDesign.panel(this, 20f)
        nowCard.background = MusicDesign.panel(this, 22f)
        for (b in listOf(settingsBtn, ytBtn, modeBtn, delBtn, prevBtn, playBtn, nextBtn, shuffleBtn)) {
            b.background = MusicDesign.button(this)
            b.setTextColor(onA)
            b.isAllCaps = false
            b.stateListAnimator = null
            b.minimumWidth = 0
            b.minimumHeight = 0
            b.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        }
        seek.progressTintList = ColorStateList.valueOf(accent)
        seek.thumbTintList = ColorStateList.valueOf(accent)
        (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()

        val s = "$accent-${MusicDesign.glass(this)}-${MusicDesign.bgKey(this)}-${MusicDesign.bgUri(this)}-${ThemeMode.dark(this)}"
        if (s != sig) {
            sig = s
            thread {
                val dm = resources.displayMetrics
                val bmp = MusicDesign.background(this, dm.widthPixels, dm.heightPixels)
                runOnUiThread { bgView.setImageBitmap(bmp) }
            }
        }
    }

    // ---------- song list ----------

    private inner class SongAdapter : BaseAdapter() {
        override fun getCount() = list.size
        override fun getItem(position: Int) = list[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val h: Holder
            if (convertView == null) {
                val row = LinearLayout(this@MusicActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                }
                val img = ImageView(this@MusicActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                row.addView(img, LinearLayout.LayoutParams(dp(52f), dp(52f)))
                val col = LinearLayout(this@MusicActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12f), 0, 0, 0)
                }
                val t1 = TextView(this@MusicActivity).apply {
                    textSize = 16f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                }
                val t2 = TextView(this@MusicActivity).apply {
                    textSize = 13f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                }
                col.addView(t1)
                col.addView(t2)
                row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                h = Holder(row, img, t1, t2)
                row.tag = h
            } else {
                h = convertView.tag as Holder
            }

            val t = list[position]
            val playing = Player.current?.uri == t.uri
            h.t1.text = t.title
            h.t1.setTextColor(if (playing) MusicDesign.accent(this@MusicActivity) else txt)
            h.t1.typeface = if (playing) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            h.t2.text = if (t.artist.isBlank() || t.artist == "<unknown>") t.album else t.artist
            h.t2.setTextColor(Color.argb(170, Color.red(txt), Color.green(txt), Color.blue(txt)))

            val id = ContentUris.parseId(t.uri)
            h.img.tag = id
            val c = Covers.cached(t)
            h.img.setImageBitmap(c ?: placeholder)
            if (c == null && !Covers.isMissing(t)) {
                Covers.load(this@MusicActivity, t) { b -> if (b != null && h.img.tag == id) h.img.setImageBitmap(b) }
            }
            return h.row
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) load()
        else info.text = tr("GooseDroid needs permission to read your music files.")
    }

    private fun load() {
        thread {
            val out = ArrayList<Player.Track>()
            val media = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.ALBUM
            )
            try {
                contentResolver.query(
                    media, proj,
                    "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000",
                    null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        out.add(
                            Player.Track(
                                ContentUris.withAppendedId(media, c.getLong(0)),
                                c.getString(1) ?: "Unknown", c.getString(2) ?: "", c.getLong(3),
                                c.getString(4) ?: ""
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread { show(out) }
        }
    }

    private fun show(tracks: List<Player.Track>) {
        all = tracks
        if (Player.tracks.isEmpty() || Player.index < 0) Player.tracks = tracks
        applyView()
    }

    private fun base(): List<Player.Track> {
        val k = key ?: ""
        return when (kind) {
            "playlist" -> {
                val byId = all.associateBy { ContentUris.parseId(it.uri) }
                (Playlists.get(this)[k] ?: emptyList<Long>()).mapNotNull { byId[it] }
            }
            "artist" -> all.filter { it.artist == k }
            "album" -> all.filter { it.album == k }
            else -> all
        }
    }

    /** Fills the list: all songs, an artist, an album or a playlist, narrowed by the search box. */
    private fun applyView() {
        if (kind == "playlist" && !Playlists.get(this).containsKey(key ?: "")) { kind = "all"; key = null }
        val q = search.text.toString().trim().lowercase()
        val b = base()
        list = if (q.isEmpty()) b else b.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
        val label = when (kind) {
            "playlist" -> "📋 $key"
            "artist" -> "👤 $key"
            "album" -> "💿 $key"
            else -> tr("📱 Local music")
        }
        modeBtn.text = "📂 $label ▾"
        delBtn.visibility = if (kind == "playlist") View.VISIBLE else View.GONE
        info.text = when {
            all.isEmpty() -> tr("No music files found on this device.")
            kind == "playlist" && list.isEmpty() && q.isEmpty() -> tr("This playlist is empty. Hold a song to add it.")
            else -> trf("%d songs - tap to play, hold for options", list.size)
        }
        if (kind == "playlist") {
            val n = Playlists.getYt(this)[key ?: ""]?.size ?: 0
            if (n > 0) info.text = info.text.toString() + "  " + trf("+ %d YouTube tracks (open 🎞)", n)
        }
        (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    // ---------- browse + playlists ----------

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun browse() {
        val items = arrayOf(tr("Playlists"), tr("Artists"), tr("Albums"), tr("🎞 YouTube Music"))
        AlertDialog.Builder(this).setTitle(tr("Browse")).setItems(items) { _, i ->
            when (i) {
                0 -> pickPlaylist()
                1 -> pickGroup("artist")
                2 -> pickGroup("album")
                else -> startActivity(Intent(this, YtMusicActivity::class.java))
            }
        }.show()
    }

    private fun pickGroup(k: String) {
        val groups = all.groupBy { if (k == "artist") it.artist else it.album }
            .filterKeys { it.isNotBlank() && it != "<unknown>" }
            .toSortedMap(String.CASE_INSENSITIVE_ORDER)
        val names = groups.keys.toList()
        if (names.isEmpty()) { toast(tr("Nothing here yet")); return }
        val labels = names.map { "$it (${groups[it]?.size ?: 0})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (k == "artist") tr("Artists") else tr("Albums"))
            .setItems(labels) { _, i -> kind = k; key = names[i]; applyView() }
            .show()
    }

    private fun pickPlaylist() {
        val names = Playlists.get(this).keys.toList()
        val items = (listOf(tr("📱 Local music")) + names + tr("➕ New playlist...")).toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Playlists")).setItems(items) { _, i ->
            when {
                i == 0 -> { kind = "all"; key = null; applyView() }
                i <= names.size -> { kind = "playlist"; key = names[i - 1]; applyView() }
                else -> askName { n -> Playlists.create(this, n); kind = "playlist"; key = n; applyView() }
            }
        }.show()
    }

    private fun askName(done: (String) -> Unit) {
        val et = EditText(this)
        et.hint = tr("Playlist name")
        AlertDialog.Builder(this)
            .setTitle(tr("New playlist"))
            .setView(et)
            .setPositiveButton(tr("Create")) { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) done(n)
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun confirmDelete() {
        val n = key ?: return
        AlertDialog.Builder(this)
            .setTitle(trf("Delete \"%s\"?", n))
            .setMessage(tr("The songs stay on your phone."))
            .setPositiveButton(tr("Delete")) { _, _ -> Playlists.delete(this, n); kind = "all"; key = null; applyView() }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun songMenu(t: Player.Track) {
        val id = ContentUris.parseId(t.uri)
        val opts = ArrayList<String>()
        opts.add(tr("Add to playlist..."))
        val cur = if (kind == "playlist") key else null
        if (cur != null) opts.add(trf("Remove from \"%s\"", cur))
        AlertDialog.Builder(this).setTitle(t.title).setItems(opts.toTypedArray()) { _, i ->
            if (i == 0) addTo(id)
            else if (cur != null) { Playlists.remove(this, cur, id); applyView() }
        }.show()
    }

    private fun addTo(id: Long) {
        val names = Playlists.get(this).keys.toList()
        val items = (names + tr("➕ New playlist...")).toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Add to playlist")).setItems(items) { _, i ->
            if (i < names.size) { Playlists.add(this, names[i], id); toast(trf("Added to %s", names[i])) }
            else askName { n -> Playlists.create(this, n); Playlists.add(this, n, id); toast(trf("Added to %s", n)) }
        }.show()
    }

    // ---------- now playing ----------

    private fun refresh() {
        val t = Player.current
        nowText.text = when {
            t == null -> tr("Nothing playing")
            t.artist.isBlank() || t.artist == "<unknown>" -> t.title
            else -> "${t.title}\n${t.artist}"
        }
        artView.setImageBitmap(Player.art ?: placeholder)
        playBtn.text = if (Player.isPlaying) "⏸" else "▶"
        shuffleBtn.text = if (Player.shuffle) "🔀 ✓" else "🔀"
        seek.max = ((t?.durationMs ?: 0L) / 1000).toInt()
        (listView.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    private fun progress() {
        if (!dragging) seek.progress = Player.position / 1000
    }

    override fun onResume() {
        super.onResume()
        applyDesign()
        Player.listener = { runOnUiThread { refresh() } }
        refresh()
        handler.post(ticker)
    }

    override fun onPause() {
        Player.listener = null
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
