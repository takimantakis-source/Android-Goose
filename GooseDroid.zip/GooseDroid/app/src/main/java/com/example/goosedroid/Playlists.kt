package com.example.goosedroid

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Playlists = name -> list of MediaStore song ids, stored as JSON in SharedPreferences. */
object Playlists {
    fun get(ctx: Context): LinkedHashMap<String, MutableList<Long>> {
        val out = LinkedHashMap<String, MutableList<Long>>()
        try {
            val j = JSONObject(Store.prefs(ctx).getString("playlists", "{}") ?: "{}")
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                val l = ArrayList<Long>()
                for (i in 0 until a.length()) l.add(a.getLong(i))
                out[k] = l
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(ctx: Context, m: Map<String, List<Long>>) {
        val j = JSONObject()
        for ((k, v) in m) j.put(k, JSONArray(v))
        Store.prefs(ctx).edit().putString("playlists", j.toString()).apply()
        Cloud.syncSoon(ctx)
    }

    fun create(ctx: Context, name: String) {
        val m = get(ctx)
        if (!m.containsKey(name)) { m[name] = ArrayList(); save(ctx, m) }
    }

    fun delete(ctx: Context, name: String) {
        val m = get(ctx)
        m.remove(name)
        save(ctx, m)
        val y = getYt(ctx)
        if (y.remove(name) != null) saveYt(ctx, y)
    }

    fun add(ctx: Context, name: String, id: Long) {
        val m = get(ctx)
        val l = m.getOrPut(name) { ArrayList() }
        if (!l.contains(id)) l.add(id)
        save(ctx, m)
    }

    fun remove(ctx: Context, name: String, id: Long) {
        val m = get(ctx)
        m[name]?.remove(id)
        save(ctx, m)
    }

    // ----- YouTube tracks in playlists: name -> list of [videoId, title, artist] -----

    fun getYt(ctx: Context): LinkedHashMap<String, MutableList<Array<String>>> {
        val out = LinkedHashMap<String, MutableList<Array<String>>>()
        try {
            val j = JSONObject(Store.prefs(ctx).getString("ytlists", "{}") ?: "{}")
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                val l = ArrayList<Array<String>>()
                for (i in 0 until a.length()) {
                    val e = a.getJSONArray(i)
                    l.add(arrayOf(e.getString(0), e.getString(1), e.getString(2)))
                }
                out[k] = l
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveYt(ctx: Context, m: Map<String, List<Array<String>>>) {
        val j = JSONObject()
        for ((k, v) in m) {
            val a = JSONArray()
            for (e in v) a.put(JSONArray().put(e[0]).put(e[1]).put(e[2]))
            j.put(k, a)
        }
        Store.prefs(ctx).edit().putString("ytlists", j.toString()).apply()
        Cloud.syncSoon(ctx)
    }

    fun addYt(ctx: Context, name: String, id: String, title: String, artist: String) {
        create(ctx, name)
        val m = getYt(ctx)
        val l = m.getOrPut(name) { ArrayList() }
        if (l.none { it[0] == id }) l.add(arrayOf(id, title, artist))
        saveYt(ctx, m)
    }

    fun removeYt(ctx: Context, name: String, id: String) {
        val m = getYt(ctx)
        m[name]?.removeAll { it[0] == id }
        saveYt(ctx, m)
    }
}
