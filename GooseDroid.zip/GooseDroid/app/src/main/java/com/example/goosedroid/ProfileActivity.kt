package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/**
 * Two options: "Create an account" and "Sign in to an existing account".
 * With the cloud set up, e-mails must be verified and your data follows you to any phone.
 */
class ProfileActivity : Activity() {
    private lateinit var root: LinearLayout
    private var view = "home" // home | create | login | verify
    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun cloud() = Cloud.configured(this)
    private fun pendEmail() = Store.prefs(this).getString("acc_pend_email", "") ?: ""
    private fun pendName() = Store.prefs(this).getString("acc_pend_name", "") ?: ""

    private val placeholder: Bitmap by lazy {
        val b = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(200, 220, 240))
        c.drawText("🪿", 128f, 170f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 140f; textAlign = Paint.Align.CENTER })
        b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(16f), dp(20f), dp(16f))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        if (!Profile.signedIn(this) && cloud() && pendEmail().isNotBlank()) view = "verify"
        render()
    }

    private fun tv(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(8f), 0, dp(4f))
    }

    private fun field(hint: String, type: Int) = EditText(this).apply {
        this.hint = hint
        inputType = type
        isSingleLine = true
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun runCloud(work: () -> Unit) {
        toast("…")
        thread {
            try { work() } catch (e: Exception) { runOnUiThread { toast(e.message ?: "error") } }
        }
    }

    private val emailType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    private val pwType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    private val emailRe = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

    private fun render() {
        root.removeAllViews()
        root.addView(tv(tr("👤 Profile"), 26f, true))
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            clipToOutline = true
            setImageBitmap(Profile.avatar(this@ProfileActivity) ?: placeholder)
        }
        root.addView(img, LinearLayout.LayoutParams(dp(110f), dp(110f)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(6f) })

        if (Profile.signedIn(this)) signedInView()
        else when (view) {
            "create" -> createView()
            "login" -> loginView()
            "verify" -> verifyView()
            else -> homeView()
        }
        root.addView(tv(
            if (cloud()) tr("Your coins, playlists and settings are saved to your account in the cloud. Other players see your username, not your email.")
            else tr("Your account is stored on this phone only. Other players see your username, not your email."), 12f
        ))
    }

    // ----- not signed in -----

    private fun homeView() {
        if (!cloud()) root.addView(tv(tr("Cloud accounts aren't set up yet, so accounts only exist on this phone. Tap ☁ Cloud setup."), 13f))
        root.addView(btn(tr("Create an account")) { view = "create"; render() })
        root.addView(btn(tr("Sign in to an existing account")) { view = "login"; render() })
        root.addView(btn(tr("☁ Cloud setup")) { setupDialog() })
    }

    private fun createView() {
        val e = field(tr("Email"), emailType)
        val n = field(tr("Username"), InputType.TYPE_CLASS_TEXT)
        val pw = field(tr("Password"), pwType)
        val pw2 = field(tr("Repeat password"), pwType)
        for (v in listOf(e, n, pw, pw2)) root.addView(v)
        root.addView(btn(tr("Create account")) {
            val email = e.text.toString().trim().lowercase()
            val name = n.text.toString().trim()
            val p1 = pw.text.toString()
            when {
                !emailRe.matches(email) -> toast(tr("Please enter a valid email address."))
                Profile.nameError(name) != null -> toast(Profile.nameError(name) ?: "")
                p1.length < 6 -> toast(tr("Password: at least 6 characters."))
                p1 != pw2.text.toString() -> toast(tr("The passwords don't match."))
                !cloud() -> {
                    val err = Profile.signUp(this, email, name, p1)
                    if (err != null) toast(err) else render()
                }
                else -> runCloud {
                    val r = Cloud.signUp(applicationContext, email, p1)
                    runOnUiThread {
                        if (r.error != null) toast(r.error)
                        else {
                            Store.prefs(this).edit().putString("acc_pend_email", email).putString("acc_pend_name", name).apply()
                            view = "verify"
                            render()
                        }
                    }
                }
            }
        })
        root.addView(btn(tr("◀ Back")) { view = "home"; render() })
    }

    private fun loginView() {
        val e = field(tr("Email"), emailType)
        val pw = field(tr("Password"), pwType)
        root.addView(e); root.addView(pw)
        root.addView(btn(tr("Sign in")) {
            val email = e.text.toString().trim().lowercase()
            val p1 = pw.text.toString()
            if (!cloud()) {
                if (Profile.signIn(this, email, p1)) render() else toast(tr("Wrong email or password."))
            } else runCloud {
                val l = Cloud.signIn(applicationContext, email, p1)
                if (l.error != null || l.session == null) {
                    runOnUiThread { toast(l.error ?: "error") }
                } else if (!l.verified) {
                    Store.prefs(this).edit().putString("acc_pend_email", email).putString("acc_pend_name", "").apply()
                    runOnUiThread { view = "verify"; toast(tr("Not verified yet. Open the link in the email first.")); render() }
                } else {
                    val err = Cloud.completeLogin(applicationContext, l.session, email, null)
                    runOnUiThread { if (err != null) toast(err) else { view = "home"; render() } }
                }
            }
        })
        root.addView(btn(tr("◀ Back")) { view = "home"; render() })
    }

    private fun verifyView() {
        root.addView(tv(trf("We sent a verification email to %s. Open the link in it, then tap the button below.", pendEmail()), 15f))
        val pw = field(tr("Password"), pwType)
        root.addView(pw)
        root.addView(btn(tr("✅ I verified my email")) {
            val email = pendEmail()
            val name = pendName()
            runCloud {
                val l = Cloud.signIn(applicationContext, email, pw.text.toString())
                if (l.error != null || l.session == null) {
                    runOnUiThread { toast(l.error ?: "error") }
                } else if (!l.verified) {
                    runOnUiThread { toast(tr("Not verified yet. Open the link in the email first.")) }
                } else {
                    val err = Cloud.completeLogin(applicationContext, l.session, email, if (name.isNotBlank()) name else null)
                    Store.prefs(this).edit().remove("acc_pend_email").remove("acc_pend_name").apply()
                    runOnUiThread { if (err != null) toast(err) else { view = "home"; render() } }
                }
            }
        })
        root.addView(btn(tr("Resend email")) {
            val email = pendEmail()
            runCloud {
                val err = Cloud.resend(applicationContext, email, pw.text.toString())
                runOnUiThread { toast(err ?: tr("Verification email sent.")) }
            }
        })
        root.addView(btn(tr("Cancel")) {
            Store.prefs(this).edit().remove("acc_pend_email").remove("acc_pend_name").apply()
            view = "home"; render()
        })
    }

    // ----- signed in -----

    private fun signedInView() {
        root.addView(tv(Profile.username(this), 22f, true).apply { gravity = Gravity.CENTER })
        root.addView(tv(Profile.email(this), 14f).apply { gravity = Gravity.CENTER })
        root.addView(btn(tr("Change profile picture")) {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 31
            )
        })
        root.addView(btn(tr("Change username")) { renameDialog() })
        if (cloud() && Cloud.signedIn(this)) {
            root.addView(btn(tr("☁ Sync now")) {
                runCloud {
                    val err = Cloud.push(applicationContext)
                    runOnUiThread { toast(err ?: tr("Saved to the cloud ✓")) }
                }
            })
        }
        root.addView(btn(tr("Sign out")) {
            if (cloud() && Cloud.signedIn(this)) runCloud {
                Cloud.push(applicationContext)
                Profile.signOut(applicationContext)
                runOnUiThread { view = "home"; render() }
            } else { Profile.signOut(this); render() }
        })
        root.addView(btn(tr("Delete account")) { confirmDelete() })
    }

    private fun renameDialog() {
        val et = EditText(this)
        et.setText(Profile.username(this))
        AlertDialog.Builder(this)
            .setTitle(tr("Change username"))
            .setView(et)
            .setPositiveButton(tr("Save")) { _, _ ->
                val err = Profile.rename(this, et.text.toString())
                if (err != null) toast(err) else Cloud.syncSoon(this)
                render()
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(tr("Delete account"))
            .setPositiveButton(tr("Delete")) { _, _ ->
                if (cloud() && Cloud.signedIn(this)) runCloud {
                    val err = Cloud.deleteAccount(applicationContext)
                    if (err == null) Profile.delete(applicationContext)
                    runOnUiThread { if (err != null) toast(err); view = "home"; render() }
                } else { Profile.delete(this); render() }
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun setupDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20f), dp(8f), dp(20f), 0) }
        val k = field(tr("Web API key"), InputType.TYPE_CLASS_TEXT)
        k.setText(Store.prefs(this).getString("fb_key", "") ?: "")
        val u = field(tr("Database URL"), InputType.TYPE_CLASS_TEXT)
        u.setText(Store.prefs(this).getString("fb_db", "") ?: "")
        col.addView(k); col.addView(u)
        AlertDialog.Builder(this)
            .setTitle(tr("☁ Cloud setup"))
            .setMessage(tr("Paste the Web API key and the Realtime Database URL of your free Firebase project."))
            .setView(col)
            .setPositiveButton(tr("Save")) { _, _ ->
                Store.prefs(this).edit().putString("fb_key", k.text.toString().trim()).putString("fb_db", u.text.toString().trim()).apply()
                render()
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 31 && res == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                val o2 = BitmapFactory.Options().apply { inSampleSize = maxOf(1, minOf(o.outWidth, o.outHeight) / 512) }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                if (bmp != null) { Profile.saveAvatar(this, bmp); Cloud.syncSoon(this) }
            } catch (_: Exception) {}
            render()
        }
    }
}
