package com.example.goosedroid

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import kotlin.random.Random

/** Coins, shop items, ownership and what the goose is wearing. All saved in SharedPreferences. */
object Store {
    var app: Context? = null

    class Item(
        val id: String, val slot: String, val name: String, val price: Int,
        val c1: Int = Color.WHITE, val c2: Int = Color.rgb(255, 140, 0)
    )

    private val orange = Color.rgb(255, 140, 0)
    val slots = listOf("skin" to "Skins", "hat" to "Hats", "face" to "Face", "neck" to "Neck", "back" to "Back", "feet" to "Feet")
    val items = listOf(
        Item("skin_classic", "skin", "Classic white", 0),
        Item("skin_gray", "skin", "Gray goose", 60, Color.rgb(200, 200, 200), orange),
        Item("skin_pink", "skin", "Pink goose", 90, Color.rgb(248, 187, 208), Color.rgb(233, 30, 99)),
        Item("skin_mint", "skin", "Mint goose", 120, Color.rgb(165, 214, 167), Color.rgb(0, 150, 136)),
        Item("skin_dark", "skin", "Shadow goose", 180, Color.rgb(97, 97, 97), Color.rgb(255, 171, 0)),
        Item("skin_gold", "skin", "Golden goose", 300, Color.rgb(255, 213, 79), Color.rgb(255, 111, 0)),
        Item("hat_halo", "hat", "Halo", 40),
        Item("hat_party", "hat", "Party hat", 60),
        Item("hat_cowboy", "hat", "Cowboy hat", 90),
        Item("hat_top", "hat", "Top hat", 120),
        Item("hat_crown", "hat", "Crown", 200),
        Item("face_shades", "face", "Sunglasses", 70),
        Item("face_stache", "face", "Mustache", 90),
        Item("face_monocle", "face", "Monocle", 110),
        Item("neck_bowtie", "neck", "Bow tie", 60),
        Item("neck_scarf", "neck", "Scarf", 80),
        Item("neck_medal", "neck", "Gold medal", 150),
        Item("hat_santa", "hat", "Santa hat", 80),
        Item("hat_bunny", "hat", "Bunny ears", 90),
        Item("hat_flowers", "hat", "Flower crown", 100),
        Item("hat_chef", "hat", "Chef hat", 110),
        Item("hat_pirate", "hat", "Pirate hat", 130),
        Item("hat_prop", "hat", "Propeller cap", 140),
        Item("hat_wizard", "hat", "Wizard hat", 170),
        Item("hat_viking", "hat", "Viking helmet", 190),
        Item("face_blush", "face", "Blush", 50),
        Item("face_eyepatch", "face", "Eyepatch", 80),
        Item("face_heart", "face", "Heart glasses", 100),
        Item("face_3d", "face", "3D glasses", 120),
        Item("neck_tie", "neck", "Tie", 70),
        Item("neck_bell", "neck", "Bell collar", 90),
        Item("neck_pearls", "neck", "Pearl necklace", 110),
        Item("neck_lei", "neck", "Flower garland", 130),
        Item("back_backpack", "back", "Backpack", 100),
        Item("back_cape", "back", "Cape", 150),
        Item("back_wings", "back", "Angel wings", 220),
        Item("back_jet", "back", "Jetpack", 300),
        Item("feet_sneakers", "feet", "Sneakers", 80),
        Item("feet_flippers", "feet", "Flippers", 100),
        Item("feet_skates", "feet", "Roller skates", 140)
    )

    fun byId(id: String) = items.firstOrNull { it.id == id }
    fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences("goosedroid", Context.MODE_PRIVATE)

    fun coins(ctx: Context) = prefs(ctx).getInt("coins", 0)
    fun addCoins(ctx: Context, n: Int) { prefs(ctx).edit().putInt("coins", coins(ctx) + n).apply(); Cloud.syncSoon(ctx) }

    fun owned(ctx: Context, id: String) = id == "skin_classic" || prefs(ctx).getBoolean("own_$id", false)

    fun buy(ctx: Context, item: Item): Boolean {
        if (owned(ctx, item.id)) return true
        val c = coins(ctx)
        if (c < item.price) return false
        prefs(ctx).edit().putInt("coins", c - item.price).putBoolean("own_${item.id}", true).apply()
        Cloud.syncSoon(ctx)
        return true
    }

    fun equipped(ctx: Context, slot: String): String =
        prefs(ctx).getString("eq_$slot", if (slot == "skin") "skin_classic" else "") ?: ""

    fun equip(ctx: Context, slot: String, id: String) {
        prefs(ctx).edit().putString("eq_$slot", id).apply()
        Cloud.syncSoon(ctx)
        Cosmetics.refresh(ctx)
    }

    fun nick(ctx: Context): String {
        val p = prefs(ctx)
        val existing = p.getString("nick", null)
        if (existing != null) return existing
        val n = "Goose" + Random.nextInt(1000, 10000)
        p.edit().putString("nick", n).apply()
        return n
    }
}

/** What the goose currently looks like. GooseView reads this every frame. */
object Cosmetics {
    var body = Color.WHITE
    var beak = Color.rgb(255, 140, 0)
    var hat = ""
    var face = ""
    var neck = ""
    var back = ""
    var feet = ""

    fun refresh(ctx: Context) {
        val skin = Store.byId(Store.equipped(ctx, "skin")) ?: Store.items[0]
        body = skin.c1
        beak = skin.c2
        hat = Store.equipped(ctx, "hat")
        face = Store.equipped(ctx, "face")
        neck = Store.equipped(ctx, "neck")
        back = Store.equipped(ctx, "back")
        feet = Store.equipped(ctx, "feet")
    }
}
