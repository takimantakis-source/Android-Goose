package com.example.goosedroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** Search through the official YouTube Data API (you need a free API key from Google Cloud). */
object Yt {
    class Item(val kind: String, val id: String, val title: String, val sub: String, val thumb: String)

    fun key(ctx: Context): String {
        val v = Store.prefs(ctx).getString("yt_key", "") ?: ""
        return if (v.isNotBlank()) v.trim() else BuildConfig.YT_API_KEY
    }

    fun configured(ctx: Context) = key(ctx).isNotBlank()

    private val main = Handler(Looper.getMainLooper())

    private fun html(s: String) = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()

    private fun parse(j: JSONObject, kind: String): List<Item> {
        val arr = j.optJSONArray("items") ?: return emptyList()
        val out = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sn = o.optJSONObject("snippet") ?: continue
            val idObj = o.opt("id")
            val id = when {
                kind == "playlistitem" -> sn.optJSONObject("resourceId")?.optString("videoId") ?: ""
                idObj is JSONObject -> idObj.optString("videoId").ifEmpty { idObj.optString("channelId").ifEmpty { idObj.optString("playlistId") } }
                else -> ""
            }
            if (id.isEmpty()) continue
            val thumb = sn.optJSONObject("thumbnails")?.optJSONObject("default")?.optString("url") ?: ""
            out.add(Item(if (kind == "playlistitem") "video" else kind, id, html(sn.optString("title")), html(sn.optString("channelTitle")), thumb))
        }
        return out
    }

    private fun call(ctx: Context, path: String, kind: String, cb: (List<Item>?, String?) -> Unit) {
        val app = ctx.applicationContext
        thread {
            var items: List<Item>? = null
            var error: String? = null
            try {
                val c = URL("https://www.googleapis.com/youtube/v3/$path&key=${key(app)}").openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 20000
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                c.disconnect()
                val j = JSONObject(txt)
                if (code in 200..299) items = parse(j, kind)
                else error = j.optJSONObject("error")?.optString("message") ?: "HTTP $code"
            } catch (e: Exception) {
                error = e.message ?: "error"
            }
            main.post { cb(items, error) }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** type: video (songs), channel (artists) or playlist (albums). */
    fun search(ctx: Context, q: String, type: String, cb: (List<Item>?, String?) -> Unit) {
        val extra = if (type == "video") "&videoCategoryId=10" else ""
        call(ctx, "search?part=snippet&maxResults=25&type=$type&q=${enc(q)}$extra", type, cb)
    }

    fun playlist(ctx: Context, id: String, cb: (List<Item>?, String?) -> Unit) =
        call(ctx, "playlistItems?part=snippet&maxResults=50&playlistId=${enc(id)}", "playlistitem", cb)

    fun channelSongs(ctx: Context, id: String, cb: (List<Item>?, String?) -> Unit) =
        call(ctx, "search?part=snippet&maxResults=25&type=video&order=viewCount&channelId=${enc(id)}", "video", cb)
}

/** Small thumbnails for the search results. */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(80)
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(url: String, iv: ImageView) {
        iv.tag = url
        iv.setImageDrawable(null)
        if (url.isEmpty()) return
        val hit = cache.get(url)
        if (hit != null) { iv.setImageBitmap(hit); return }
        pool.execute {
            try {
                val b = BitmapFactory.decodeStream(URL(url).openStream())
                if (b != null) {
                    cache.put(url, b)
                    main.post { if (iv.tag == url) iv.setImageBitmap(b) }
                }
            } catch (_: Exception) {}
        }
    }
}
