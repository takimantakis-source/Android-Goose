package com.example.goosedroid

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * YouTube Music search and playback. Searching uses the official YouTube Data API; playing uses
 * YouTube's own embedded player, which stays visible while a song plays (that is YouTube's rule).
 * Ads are YouTube's: this screen only offers a manual mute button.
 */
class YtMusicActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var playerBox: FrameLayout
    private lateinit var nowText: TextView
    private lateinit var list: LinearLayout
    private lateinit var query: EditText
    private lateinit var muteBtn: Button

    private var items: List<Yt.Item> = emptyList()
    private var queue: List<Yt.Item> = emptyList()
    private var qi = -1
    private var tab = "video"
    private var savedName: String? = null
    private var muted = false

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private val page = """
        <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
        <style>html,body{margin:0;height:100%;background:#000}#p{width:100%;height:100%}</style></head><body><div id="p"></div>
        <script>
        var player=null,ready=false,pending=null;
        var tag=document.createElement('script');tag.src='https://www.youtube.com/iframe_api';document.head.appendChild(tag);
        function onYouTubeIframeAPIReady(){
          player=new YT.Player('p',{width:'100%',height:'100%',playerVars:{playsinline:1,rel:0,autoplay:1},
            events:{onReady:function(){ready=true;if(pending){player.loadVideoById(pending);pending=null;}},
                    onStateChange:function(e){Android.state(e.data);},
                    onError:function(e){Android.error(e.data);}}});
        }
        function playId(id){if(ready){player.loadVideoById(id);}else{pending=id;}}
        function toggle(){if(!ready)return;if(player.getPlayerState()==1){player.pauseVideo();}else{player.playVideo();}}
        function pauseIt(){if(ready){player.pauseVideo();}}
        function toggleMute(){if(!ready)return;if(player.isMuted()){player.unMute();}else{player.mute();}}
        </script></body></html>
    """.trimIndent()

    private inner class Bridge {
        @JavascriptInterface fun state(s: Int) { if (s == 0) runOnUiThread { playIndex(qi + 1) } }
        @JavascriptInterface fun error(c: Int) { runOnUiThread { playIndex(qi + 1) } } // can't be embedded: skip it
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
        }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = tr("🎞 YouTube Music"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Button(this).apply { text = "🔑"; setOnClickListener { keyDialog() } })
        root.addView(head)

        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        query = EditText(this).apply {
            hint = tr("Search songs, artists, albums...")
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> doSearch(); true }
        }
        sr.addView(query, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(Button(this).apply { text = "🔎"; setOnClickListener { doSearch() } })
        root.addView(sr)

        val tabRow = LinearLayout(this)
        for ((t, label) in listOf("video" to tr("Songs"), "channel" to tr("Artists"), "playlist" to tr("Albums"), "saved" to tr("Saved"))) {
            tabRow.addView(Button(this).apply {
                text = label; isAllCaps = false; textSize = 12f
                setOnClickListener { setTab(t) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabRow)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadDataWithBaseURL("https://www.youtube.com", page, "text/html", "utf-8", null)
        playerBox = FrameLayout(this).apply { visibility = View.GONE; addView(web, FrameLayout.LayoutParams(-1, -1)) }
        val w = resources.displayMetrics.widthPixels - dp(32f)
        root.addView(playerBox, LinearLayout.LayoutParams(-1, w * 9 / 16).apply { topMargin = dp(8f) })

        nowText = TextView(this).apply { textSize = 14f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(6f), 0, 0) }
        root.addView(nowText)
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun cb(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        ctl.addView(cb("⏮") { playIndex(qi - 1) })
        ctl.addView(cb("⏯") { web.evaluateJavascript("toggle()", null) })
        ctl.addView(cb("⏭") { playIndex(qi + 1) })
        muteBtn = cb("🔊") {
            muted = !muted
            muteBtn.text = if (muted) "🔇" else "🔊"
            web.evaluateJavascript("toggleMute()", null)
        }
        ctl.addView(muteBtn)
        ctl.addView(cb("➕") { if (qi in queue.indices) addToPlaylist(queue[qi]) })
        root.addView(ctl)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
        msg(tr("Search for any song, artist or album. The video player stays visible while a song plays (YouTube's rules), and playback stops when you leave this screen."))
    }

    override fun onPause() {
        web.evaluateJavascript("pauseIt()", null)
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun msg(s: String) {
        list.removeAllViews()
        list.addView(TextView(this).apply { text = s; textSize = 14f; setPadding(0, dp(12f), 0, 0) })
    }

    // ---------- search ----------

    private fun setTab(t: String) {
        tab = t
        savedName = null
        if (t == "saved") showSaved() else doSearch()
    }

    private fun doSearch() {
        val q = query.text.toString().trim()
        if (q.isEmpty()) return
        if (!Yt.configured(this)) { msg(tr("YouTube search isn't set up yet. Tap 🔑 and paste a YouTube Data API key.")); return }
        if (tab == "saved") tab = "video"
        savedName = null
        msg(tr("Searching..."))
        Yt.search(this, q, tab) { r, e ->
            if (!isFinishing) { if (r == null) msg("⚠ " + (e ?: "")) else showItems(r) }
        }
    }

    private fun showItems(r: List<Yt.Item>) {
        items = r
        list.removeAllViews()
        if (r.isEmpty()) { msg(tr("No results.")); return }
        for (it0 in r) {
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2f), dp(6f), dp(2f), dp(6f))
            }
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            row.addView(iv, LinearLayout.LayoutParams(dp(64f), dp(48f)))
            Thumbs.load(it0.thumb, iv)
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10f), 0, 0, 0) }
            col.addView(TextView(this).apply { text = it0.title; textSize = 15f; maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            col.addView(TextView(this).apply {
                text = (if (it0.kind == "channel") "👤 " else if (it0.kind == "playlist") "💿 " else "") + it0.sub
                textSize = 12f
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener {
                when (it0.kind) {
                    "video" -> { queue = items.filter { x -> x.kind == "video" }; playIndex(queue.indexOf(it0)) }
                    "channel" -> {
                        msg(tr("Searching..."))
                        Yt.channelSongs(this, it0.id) { res, e -> if (!isFinishing) { if (res == null) msg("⚠ " + (e ?: "")) else showItems(res) } }
                    }
                    else -> {
                        msg(tr("Searching..."))
                        Yt.playlist(this, it0.id) { res, e -> if (!isFinishing) { if (res == null) msg("⚠ " + (e ?: "")) else showItems(res) } }
                    }
                }
            }
            if (it0.kind == "video") row.setOnLongClickListener {
                val sn = savedName
                if (sn != null) confirmRemove(sn, it0) else addToPlaylist(it0)
                true
            }
            list.addView(row)
        }
    }

    // ---------- saved playlists ----------

    private fun showSaved() {
        val m = Playlists.getYt(this)
        if (m.isEmpty()) { msg(tr("Nothing saved yet. Long-press a song to add it to a playlist.")); return }
        list.removeAllViews()
        for ((name, l) in m) {
            list.addView(TextView(this).apply {
                text = "📋 $name  (" + trf("%d tracks", l.size) + ")"
                textSize = 17f
                setPadding(dp(4f), dp(14f), dp(4f), dp(14f))
                setOnClickListener {
                    savedName = name
                    showItems(l.map { Yt.Item("video", it[0], it[1], it[2], "") })
                }
            })
        }
    }

    private fun confirmRemove(name: String, item: Yt.Item) {
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setMessage(tr("Remove from this playlist?"))
            .setPositiveButton(tr("Delete")) { _, _ ->
                Playlists.removeYt(this, name, item.id)
                showItems(Playlists.getYt(this)[name].orEmpty().map { Yt.Item("video", it[0], it[1], it[2], "") })
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun addToPlaylist(item: Yt.Item) {
        val names = (Playlists.get(this).keys + Playlists.getYt(this).keys).toList().distinct()
        val labels = (names + tr("➕ New playlist...")).toTypedArray()
        AlertDialog.Builder(this).setTitle(tr("Add to playlist")).setItems(labels) { _, i ->
            if (i < names.size) {
                Playlists.addYt(this, names[i], item.id, item.title, item.sub)
                toast(trf("Added to %s", names[i]))
            } else {
                val et = EditText(this)
                et.hint = tr("Playlist name")
                AlertDialog.Builder(this)
                    .setTitle(tr("New playlist"))
                    .setView(et)
                    .setPositiveButton(tr("Create")) { _, _ ->
                        val n = et.text.toString().trim()
                        if (n.isNotEmpty()) { Playlists.addYt(this, n, item.id, item.title, item.sub); toast(trf("Added to %s", n)) }
                    }
                    .setNegativeButton(tr("Cancel"), null)
                    .show()
            }
        }.show()
    }

    // ---------- playing ----------

    private fun playIndex(i: Int) {
        if (i < 0 || i >= queue.size) return
        qi = i
        val t = queue[i]
        if (Player.isPlaying) Player.toggle() // pause the music from your phone
        playerBox.visibility = View.VISIBLE
        web.evaluateJavascript("playId('${t.id}')", null)
        nowText.text = t.title + "\n" + t.sub
    }

    private fun keyDialog() {
        val et = EditText(this)
        et.hint = "AIza..."
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setText(Store.prefs(this).getString("yt_key", "") ?: "")
        AlertDialog.Builder(this)
            .setTitle(tr("YouTube API key"))
            .setMessage(tr("Paste a YouTube Data API key (Google Cloud Console, YouTube Data API v3). It is saved only on this phone."))
            .setView(et)
            .setPositiveButton(tr("Save")) { _, _ ->
                Store.prefs(this).edit().putString("yt_key", et.text.toString().trim()).apply()
                toast("✓")
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }
}
