package com.example.goosedroid

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.app = this
        Lang.init(this)
    }
}
