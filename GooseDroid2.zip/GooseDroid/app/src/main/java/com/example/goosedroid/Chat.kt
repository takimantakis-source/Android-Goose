package com.example.goosedroid

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * The goose chatbot. With an API key it is a real AI: Claude, ChatGPT, Gemini, or any
 * OpenAI-compatible service (Groq, OpenRouter, Mistral, ...). Without a key it answers a few simple things.
 */
object Chat {
    val history = ArrayList<Pair<String, String>>() // "user" / "assistant", text

    val PROVIDERS = listOf("claude", "openai", "gemini", "custom")

    fun providerName(id: String) = when (id) {
        "claude" -> "Claude (Anthropic)"
        "openai" -> "ChatGPT (OpenAI)"
        "gemini" -> "Gemini (Google)"
        else -> tr("Other (OpenAI-compatible)")
    }

    /** Model names change over time, so the model is always editable in the key dialog. */
    fun defaultModel(p: String) = when (p) {
        "claude" -> "claude-haiku-5-5"
        "openai" -> "gpt-4o-mini"
        "gemini" -> "gemini-2.0-flash"
        else -> ""
    }

    fun provider(ctx: Context): String = Store.prefs(ctx).getString("chat_provider", "claude") ?: "claude"
    fun key(ctx: Context): String = Store.prefs(ctx).getString("chat_key", "") ?: ""
    fun url(ctx: Context): String = Store.prefs(ctx).getString("chat_url", "") ?: ""
    fun model(ctx: Context): String {
        val m = Store.prefs(ctx).getString("chat_model", "") ?: ""
        return if (m.isBlank()) defaultModel(provider(ctx)) else m
    }

    fun hasKey(ctx: Context) = key(ctx).isNotBlank() && (provider(ctx) != "custom" || url(ctx).isNotBlank())

    fun save(ctx: Context, provider: String, key: String, model: String, url: String) {
        Store.prefs(ctx).edit()
            .putString("chat_provider", provider)
            .putString("chat_key", key.trim())
            .putString("chat_model", model.trim())
            .putString("chat_url", url.trim())
            .apply()
    }

    private fun system(): String = listOf(
        "You are Gus, a cheerful goose who lives inside the GooseDroid Android app.",
        "Be friendly and playful, keep answers short (1 to 4 sentences) and honk now and then.",
        "Always answer in ${Lang.englishName(Lang.code)} unless the user writes in another language.",
        "You can explain the app: a goose walks over the screen (tap = honk, drag = move);",
        "minigames earn coins (Catch the Goose, Bread Catch, Honk Memory, Flappy Goose, Whack-a-Goose,",
        "Goose Hunt, Goose Obby, Goose Shove); the shop sells skins and accessories;",
        "swipe right on the main menu for the Extras shop (pets and honk sounds);",
        "the music player has covers, playlists, designs and settings; swipe left opens this chat;",
        "the gear icon has language settings. Never ask for passwords or personal data."
    ).joinToString(" ")

    // ---------- request bodies for the different services ----------

    private fun claudeBody(m: String, turns: List<Pair<String, String>>): JSONObject {
        val msgs = JSONArray()
        for ((r, t) in turns) msgs.put(JSONObject().put("role", r).put("content", t))
        return JSONObject().put("model", m).put("max_tokens", 500).put("system", system()).put("messages", msgs)
    }

    private fun openAiBody(m: String, turns: List<Pair<String, String>>): JSONObject {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system()))
        for ((r, t) in turns) msgs.put(JSONObject().put("role", r).put("content", t))
        return JSONObject().put("model", m).put("messages", msgs)
    }

    private fun geminiBody(turns: List<Pair<String, String>>): JSONObject {
        val contents = JSONArray()
        for ((r, t) in turns) {
            contents.put(
                JSONObject()
                    .put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("content-type", "application/json")
        for ((h, v) in headers) c.setRequestProperty(h, v)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return code to txt
    }

    private fun parse(prov: String, txt: String): String {
        val j = JSONObject(txt)
        val sb = StringBuilder()
        when (prov) {
            "claude" -> {
                val a = j.getJSONArray("content")
                for (i in 0 until a.length()) {
                    val b = a.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.optString("text"))
                }
            }
            "gemini" -> {
                val parts = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            }
            else -> sb.append(j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content"))
        }
        return sb.toString().trim()
    }

    private fun errorMessage(txt: String, code: Int): String = try {
        val e = JSONObject(txt).opt("error")
        when (e) {
            is JSONObject -> e.optString("message", "HTTP $code")
            is String -> e
            else -> "HTTP $code"
        }
    } catch (_: Exception) {
        "HTTP $code"
    }

    /** Sends the conversation to the chosen AI service. onDone(reply, error) runs on the main thread. */
    fun ask(ctx: Context, onDone: (String?, String?) -> Unit) {
        val app = ctx.applicationContext
        val prov = provider(app)
        val k = key(app)
        val m = model(app)
        val u = url(app)
        val turns = ArrayList<Pair<String, String>>()
        var started = false
        for ((role, text) in history.takeLast(12)) {
            if (!started && role != "user") continue // the first message must come from the user
            started = true
            turns.add(role to text)
        }
        thread {
            var reply: String? = null
            var err: String? = null
            try {
                val res = when (prov) {
                    "claude" -> post(
                        "https://api.anthropic.com/v1/messages",
                        mapOf("x-api-key" to k, "anthropic-version" to "2023-06-01"), claudeBody(m, turns)
                    )
                    "gemini" -> post(
                        "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                        mapOf("x-goog-api-key" to k), geminiBody(turns)
                    )
                    "openai" -> post(
                        "https://api.openai.com/v1/chat/completions",
                        mapOf("Authorization" to "Bearer $k"), openAiBody(m, turns)
                    )
                    else -> post(u, mapOf("Authorization" to "Bearer $k"), openAiBody(m, turns))
                }
                if (res.first in 200..299) reply = parse(prov, res.second).ifEmpty { "HONK?" }
                else err = errorMessage(res.second, res.first)
            } catch (e: Exception) {
                err = e.message ?: "error"
            }
            Handler(Looper.getMainLooper()).post { onDone(reply, err) }
        }
    }

    /** Answers without a key: a few simple things about the app. */
    fun offline(text: String): String {
        val s = text.lowercase()
        return when {
            s.contains("hello") || s.contains("hi") || s.contains("hallo") -> tr("HONK! Hello!")
            s.contains("coin") || s.contains("münz") -> tr("Coins come from the minigames. Spend them in the shop!")
            s.contains("shop") || s.contains("buy") || s.contains("kauf") -> tr("Swipe right for the Extras shop, or tap 🛍 for skins and accessories.")
            s.contains("game") || s.contains("play") || s.contains("spiel") -> tr("Try Goose Obby, Goose Hunt or Goose Shove. They are 3D!")
            s.contains("music") || s.contains("song") || s.contains("musik") -> tr("Tap 🎵 at the top left for the music player.")
            else -> tr("I only know simple things without a key. Tap 🔑 above to add an API key (Claude, ChatGPT, Gemini or another), then I can really talk!")
        }
    }
}
