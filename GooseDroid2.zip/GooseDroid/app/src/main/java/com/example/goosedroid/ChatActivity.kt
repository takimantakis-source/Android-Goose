package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Swipe left on the main menu to chat with the goose. */
class ChatActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var swipe: android.view.GestureDetector

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        swipe = makeSwipe(this, null) { finish() }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = tr("💬 Goose Chat"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Button(this).apply { text = "🔑"; setOnClickListener { keyDialog() } })
        head.addView(Button(this).apply { text = "🗑"; setOnClickListener { Chat.history.clear(); seed() } })
        root.addView(head)

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(box) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = tr("Type a message..."); maxLines = 4 }
        sendBtn = Button(this).apply { text = tr("Send"); setOnClickListener { send() } }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(sendBtn)
        root.addView(row)
        setContentView(root)
        seed()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun seed() {
        box.removeAllViews()
        if (Chat.history.isEmpty()) Chat.history.add("assistant" to tr("Honk! I'm your goose. Ask me anything!"))
        for ((role, text) in Chat.history) addBubble(text, role == "user")
        scrollDown()
    }

    private fun addBubble(text: String, mine: Boolean): TextView {
        val dark = ThemeMode.dark(this)
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (mine) Color.WHITE else if (dark) Color.WHITE else Color.BLACK)
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            maxWidth = (resources.displayMetrics.widthPixels * 0.8f).toInt()
            background = GradientDrawable().apply {
                cornerRadius = dp(18f).toFloat()
                setColor(if (mine) Color.rgb(33, 150, 243) else if (dark) Color.rgb(60, 63, 70) else Color.rgb(235, 235, 235))
            }
        }
        box.addView(tv, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (mine) Gravity.END else Gravity.START
            topMargin = dp(8f)
        })
        return tv
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        addBubble(t, true)
        Chat.history.add("user" to t)
        if (!Chat.hasKey(this)) {
            val r = Chat.offline(t)
            Chat.history.add("assistant" to r)
            addBubble(r, false)
            scrollDown()
            return
        }
        val typing = addBubble(tr("Thinking..."), false)
        sendBtn.isEnabled = false
        scrollDown()
        Chat.ask(this) { reply, err ->
            sendBtn.isEnabled = true
            if (reply != null) {
                typing.text = reply
                Chat.history.add("assistant" to reply)
            } else {
                typing.text = "⚠ " + (err ?: "")
                if (Chat.history.isNotEmpty() && Chat.history.last().first == "user") Chat.history.removeAt(Chat.history.size - 1)
            }
            scrollDown()
        }
    }

    private fun keyDialog() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(8f), dp(20f), 0)
        }
        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Chat.PROVIDERS.map { Chat.providerName(it) })
        spin.setSelection(Chat.PROVIDERS.indexOf(Chat.provider(this)).coerceAtLeast(0))
        val keyEt = EditText(this).apply {
            hint = "API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Chat.key(this@ChatActivity))
        }
        val modelEt = EditText(this).apply { hint = tr("Model"); setText(Chat.model(this@ChatActivity)) }
        val urlEt = EditText(this).apply {
            hint = tr("URL (OpenAI-compatible)")
            setText(Chat.url(this@ChatActivity))
        }
        fun sync(userChange: Boolean) {
            val p = Chat.PROVIDERS[spin.selectedItemPosition]
            urlEt.visibility = if (p == "custom") View.VISIBLE else View.GONE
            if (userChange) modelEt.setText(Chat.defaultModel(p))
        }
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { sync(!first); first = false }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(spin)
        col.addView(keyEt)
        col.addView(modelEt)
        col.addView(urlEt)
        sync(false)
        AlertDialog.Builder(this)
            .setTitle(tr("Chat key (AI provider)"))
            .setMessage(tr("Choose a provider and paste your API key. It is saved only on this phone and sent only to that provider. Using it can cost money. Without a key I only know a few simple things."))
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton(tr("Save")) { _, _ ->
                Chat.save(
                    this, Chat.PROVIDERS[spin.selectedItemPosition],
                    keyEt.text.toString(), modelEt.text.toString(), urlEt.text.toString()
                )
                Toast.makeText(this, "✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }
}
