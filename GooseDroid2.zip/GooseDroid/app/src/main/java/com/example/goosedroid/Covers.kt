package com.example.goosedroid

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import java.util.concurrent.Executors

/** Small cover thumbnails for the song list: loaded in the background and cached. */
object Covers {
    private val cache = LruCache<Long, Bitmap>(160)
    private val missing = HashSet<Long>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    private fun id(t: Player.Track) = ContentUris.parseId(t.uri)
    fun cached(t: Player.Track): Bitmap? = cache.get(id(t))
    fun isMissing(t: Player.Track): Boolean = synchronized(missing) { missing.contains(id(t)) }

    fun load(ctx: Context, t: Player.Track, cb: (Bitmap?) -> Unit) {
        val key = id(t)
        val hit = cache.get(key)
        if (hit != null) { cb(hit); return }
        val app = ctx.applicationContext
        pool.execute {
            val b = read(app, t, 160)
            if (b != null) cache.put(key, b) else synchronized(missing) { missing.add(key) }
            main.post { cb(b) }
        }
    }

    private fun read(app: Context, t: Player.Track, px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try { return app.contentResolver.loadThumbnail(t.uri, Size(px, px), null) } catch (_: Exception) {}
        }
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(app, t.uri)
            val b = r.embeddedPicture ?: return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            val o2 = BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / px) }
            return BitmapFactory.decodeByteArray(b, 0, b.size, o2)
        } catch (_: Exception) {
            return null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }
}
