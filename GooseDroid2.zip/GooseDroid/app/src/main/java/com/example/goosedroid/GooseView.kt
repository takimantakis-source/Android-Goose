package com.example.goosedroid

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Draws the goose with plain Canvas shapes, wearing whatever skin/accessories are equipped. */
class GooseView(context: Context, scale: Float = 1f) : View(context) {
    var facingLeft = false
    var walking = false
    var phase = 0f
    var bubble: String? = null
    var previewItem: Store.Item? = null // shop preview: wear this item instead of the equipped one in its slot

    // fixed outfit (used for the geese in the 3D hunt): ignores what the player has equipped
    var fixedLook = false
    var lookSkin = "skin_classic"
    var lookHat = ""
    var lookFace = ""
    var lookNeck = ""
    var lookBack = ""
    var lookFeet = ""

    private val d = resources.displayMetrics.density
    val sizeW = (110 * d * scale).toInt()
    val sizeH = (130 * d * scale).toInt() // extra 20dp on top for the speech bubble / tall hats

    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun stroke(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val white = fill(Color.WHITE)
    private val orange = fill(Color.rgb(255, 140, 0))
    private val black = fill(Color.BLACK)
    private val outline = stroke(Color.rgb(80, 80, 80), 1.3f)
    private val neckOutline = stroke(Color.rgb(80, 80, 80), 11f)
    private val neckWhite = stroke(Color.WHITE, 8.6f)
    private val legs = stroke(Color.rgb(255, 140, 0), 2.6f)
    private val acc = fill(Color.BLACK)
    private val accLine = stroke(Color.BLACK, 1.5f)
    private val bubbleFill = fill(Color.WHITE)
    private val bubbleLine = stroke(Color.DKGRAY, 2f * d)
    private val bubbleText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; textSize = 13 * d; typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    private val red = Color.rgb(229, 57, 53)
    private val gold = Color.rgb(255, 193, 7)

    init { Cosmetics.refresh(context) }

    private fun poly(c: Canvas, color: Int, vararg pts: Float) {
        val p = Path()
        p.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) { p.lineTo(pts[i], pts[i + 1]); i += 2 }
        p.close()
        acc.color = color
        c.drawPath(p, acc); c.drawPath(p, outline)
    }

    private fun oval(c: Canvas, color: Int, l: Float, t: Float, r: Float, b: Float) {
        acc.color = color
        val rc = RectF(l, t, r, b)
        c.drawOval(rc, acc); c.drawOval(rc, outline)
    }

    private fun box(c: Canvas, color: Int, l: Float, t: Float, r: Float, b: Float) {
        acc.color = color
        val rc = RectF(l, t, r, b)
        c.drawRect(rc, acc); c.drawRect(rc, outline)
    }

    private fun line(c: Canvas, color: Int, w: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
        accLine.color = color; accLine.strokeWidth = w
        c.drawLine(x1, y1, x2, y2, accLine)
    }

    // ---------- accessories ----------

    private fun backBehind(c: Canvas, id: String) {
        when (id) {
            "back_cape" -> poly(c, Color.rgb(198, 40, 40), 62f, 58f, 36f, 52f, 8f, 68f, 12f, 86f, 34f, 80f)
            "back_wings" -> {
                poly(c, Color.WHITE, 46f, 62f, 24f, 22f, 38f, 20f, 54f, 56f)
                poly(c, Color.rgb(235, 245, 255), 36f, 64f, 8f, 38f, 20f, 36f, 44f, 60f)
            }
        }
    }

    private fun backFront(c: Canvas, id: String) {
        when (id) {
            "back_backpack" -> {
                box(c, Color.rgb(141, 110, 99), 22f, 58f, 40f, 78f)
                box(c, Color.rgb(109, 76, 65), 22f, 58f, 40f, 66f)
                line(c, Color.rgb(78, 52, 46), 2f, 40f, 62f, 52f, 74f)
            }
            "back_jet" -> {
                box(c, Color.rgb(176, 190, 197), 21f, 56f, 30f, 78f)
                box(c, Color.rgb(176, 190, 197), 32f, 56f, 41f, 78f)
                poly(c, Color.rgb(255, 152, 0), 21f, 78f, 30f, 78f, 25.5f, 93f)
                poly(c, Color.rgb(255, 152, 0), 32f, 78f, 41f, 78f, 36.5f, 93f)
            }
        }
    }

    private fun feetDraw(c: Canvas, id: String, fx: Float) {
        when (id) {
            "feet_sneakers" -> {
                oval(c, red, fx - 7f, 88.5f, fx + 9f, 96f)
                line(c, Color.WHITE, 1.4f, fx - 6f, 94.5f, fx + 8f, 94.5f)
            }
            "feet_flippers" -> oval(c, Color.rgb(0, 200, 120), fx - 4f, 90f, fx + 17f, 96.5f)
            "feet_skates" -> {
                box(c, Color.WHITE, fx - 5f, 84f, fx + 6f, 91f)
                oval(c, Color.rgb(60, 60, 60), fx - 6f, 91f, fx - 2f, 96f)
                oval(c, Color.rgb(60, 60, 60), fx + 3f, 91f, fx + 7f, 96f)
            }
        }
    }

    private fun neckDraw(c: Canvas, id: String) {
        when (id) {
            "neck_bowtie" -> {
                poly(c, red, 67f, 50f, 58f, 45f, 58f, 55f)
                poly(c, red, 67f, 50f, 76f, 45f, 76f, 55f)
                oval(c, Color.rgb(150, 20, 20), 65f, 48f, 69f, 52f)
            }
            "neck_scarf" -> {
                line(c, red, 5f, 60f, 55f, 71f, 52f)
                line(c, red, 4f, 62f, 56f, 60f, 68f)
            }
            "neck_medal" -> {
                line(c, Color.rgb(30, 100, 200), 1.6f, 65f, 48f, 65f, 54f)
                oval(c, gold, 61.5f, 53f, 68.5f, 60f)
            }
            "neck_tie" -> poly(c, Color.rgb(25, 118, 210), 64f, 52f, 69f, 52f, 68f, 56f, 70f, 66f, 66f, 70f, 62f, 66f, 64f, 56f)
            "neck_pearls" -> {
                val xs = floatArrayOf(60f, 62.5f, 66f, 69.5f, 71.5f)
                val ys = floatArrayOf(56f, 58.5f, 59f, 57.5f, 55f)
                for (i in xs.indices) oval(c, Color.rgb(250, 245, 240), xs[i] - 1.8f, ys[i] - 1.8f, xs[i] + 1.8f, ys[i] + 1.8f)
            }
            "neck_bell" -> {
                line(c, red, 3f, 60f, 55f, 71f, 52f)
                oval(c, gold, 63f, 54f, 68.5f, 60f)
                acc.color = Color.BLACK
                c.drawCircle(65.7f, 58f, 0.9f, acc)
            }
            "neck_lei" -> {
                val xs = floatArrayOf(59.5f, 62f, 65.5f, 69f, 71.5f)
                val ys = floatArrayOf(56f, 58.5f, 59.5f, 58f, 55f)
                val cs = intArrayOf(Color.rgb(244, 143, 177), Color.rgb(255, 183, 77), Color.rgb(255, 241, 118), Color.rgb(244, 143, 177), Color.rgb(255, 183, 77))
                for (i in xs.indices) oval(c, cs[i], xs[i] - 2.4f, ys[i] - 2.4f, xs[i] + 2.4f, ys[i] + 2.4f)
            }
        }
    }

    private fun faceDraw(c: Canvas, id: String) {
        when (id) {
            "face_shades" -> {
                box(c, Color.BLACK, 72f, 24f, 84f, 30.5f)
                line(c, Color.BLACK, 1.6f, 72f, 26f, 65f, 27f)
            }
            "face_monocle" -> {
                accLine.color = gold; accLine.strokeWidth = 1.3f
                c.drawCircle(77.5f, 27f, 4.6f, accLine)
                line(c, gold, 0.8f, 77.5f, 31.6f, 75f, 44f)
            }
            "face_stache" -> line(c, Color.rgb(93, 64, 55), 3.2f, 80f, 38.5f, 91f, 35.5f)
            "face_heart" -> {
                poly(c, red, 77.5f, 32f, 72f, 26f, 74f, 23f, 77.5f, 25f, 81f, 23f, 83f, 26f)
                line(c, Color.BLACK, 1.2f, 72f, 26f, 65f, 27f)
            }
            "face_eyepatch" -> {
                oval(c, Color.BLACK, 73.5f, 23f, 82f, 31f)
                line(c, Color.BLACK, 1f, 66f, 22f, 84f, 25f)
            }
            "face_3d" -> {
                box(c, red, 72f, 24f, 78f, 31f)
                box(c, Color.rgb(0, 188, 212), 78f, 24f, 84f, 31f)
                line(c, Color.BLACK, 1.2f, 72f, 26f, 65f, 27f)
            }
            "face_blush" -> {
                acc.color = Color.argb(170, 255, 105, 135)
                c.drawOval(RectF(69.5f, 31f, 76f, 35.5f), acc)
            }
        }
    }

    private fun hatDraw(c: Canvas, id: String) {
        when (id) {
            "hat_halo" -> {
                accLine.color = gold; accLine.strokeWidth = 2.2f
                c.drawOval(RectF(65f, 9f, 83f, 15f), accLine)
            }
            "hat_party" -> {
                poly(c, Color.rgb(233, 30, 99), 67f, 22f, 81f, 22f, 74f, 1f)
                oval(c, Color.rgb(255, 235, 59), 71.5f, -1.5f, 76.5f, 3.5f)
            }
            "hat_cowboy" -> {
                val brown = Color.rgb(141, 110, 99)
                oval(c, brown, 58f, 17f, 90f, 25f)
                poly(c, brown, 67f, 19f, 69f, 8f, 79f, 8f, 81f, 19f)
            }
            "hat_top" -> {
                box(c, Color.rgb(33, 33, 33), 66f, 3f, 82f, 21f)
                box(c, Color.rgb(33, 33, 33), 61f, 19f, 87f, 24f)
                box(c, red, 66f, 15f, 82f, 18f)
            }
            "hat_crown" -> poly(c, gold, 66f, 22f, 66f, 9f, 70f, 15f, 74f, 6f, 78f, 15f, 82f, 9f, 82f, 22f)
            "hat_santa" -> {
                poly(c, red, 65f, 23f, 83f, 23f, 88f, 9f, 76f, 5f)
                box(c, Color.WHITE, 64f, 20f, 84f, 25f)
                oval(c, Color.WHITE, 85f, 5f, 91f, 11f)
            }
            "hat_bunny" -> {
                oval(c, Color.WHITE, 66f, -8f, 73f, 22f)
                oval(c, Color.WHITE, 74f, -8f, 81f, 22f)
                oval(c, Color.rgb(248, 187, 208), 68f, -2f, 71f, 17f)
                oval(c, Color.rgb(248, 187, 208), 76f, -2f, 79f, 17f)
            }
            "hat_flowers" -> {
                val cs = intArrayOf(Color.rgb(244, 143, 177), Color.rgb(255, 241, 118), Color.WHITE, Color.rgb(244, 143, 177), Color.rgb(255, 241, 118))
                var x = 66f
                for (k in cs.indices) { oval(c, cs[k], x - 2.6f, 19f, x + 2.6f, 25f); x += 4f }
            }
            "hat_chef" -> {
                oval(c, Color.WHITE, 64f, 6f, 76f, 17f)
                oval(c, Color.WHITE, 72f, 4f, 84f, 16f)
                oval(c, Color.WHITE, 68f, 0f, 80f, 12f)
                box(c, Color.WHITE, 66f, 12f, 82f, 23f)
            }
            "hat_pirate" -> {
                poly(c, Color.rgb(33, 33, 33), 60f, 23f, 74f, 8f, 88f, 23f, 82f, 25f, 66f, 25f)
                oval(c, Color.WHITE, 72f, 14f, 76f, 18f)
            }
            "hat_prop" -> {
                oval(c, Color.rgb(33, 150, 243), 65f, 16f, 83f, 28f)
                line(c, Color.DKGRAY, 1.4f, 74f, 17f, 74f, 10f)
                line(c, red, 2.4f, 64f, 9f, 84f, 11f)
            }
            "hat_wizard" -> {
                oval(c, Color.rgb(74, 20, 140), 61f, 20f, 87f, 26f)
                poly(c, Color.rgb(106, 27, 154), 66f, 23f, 82f, 23f, 78f, -4f)
                poly(c, Color.rgb(255, 235, 59), 74.5f, 8f, 76f, 11f, 74.5f, 14f, 73f, 11f)
            }
            "hat_viking" -> {
                poly(c, Color.rgb(245, 230, 200), 65f, 21f, 57f, 9f, 62f, 11f, 68f, 19f)
                poly(c, Color.rgb(245, 230, 200), 83f, 21f, 91f, 9f, 86f, 11f, 80f, 19f)
                oval(c, Color.rgb(158, 158, 158), 64f, 15f, 84f, 29f)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        var bodyC = Cosmetics.body
        var beakC = Cosmetics.beak
        var hatId = Cosmetics.hat
        var faceId = Cosmetics.face
        var neckId = Cosmetics.neck
        var backId = Cosmetics.back
        var feetId = Cosmetics.feet
        if (fixedLook) {
            val sk = Store.byId(lookSkin)
            bodyC = sk?.c1 ?: Color.WHITE
            beakC = sk?.c2 ?: Color.rgb(255, 140, 0)
            hatId = lookHat; faceId = lookFace; neckId = lookNeck; backId = lookBack; feetId = lookFeet
        }
        previewItem?.let {
            when (it.slot) {
                "skin" -> { bodyC = it.c1; beakC = it.c2 }
                "hat" -> hatId = it.id
                "face" -> faceId = it.id
                "neck" -> neckId = it.id
                "back" -> backId = it.id
                "feet" -> feetId = it.id
            }
        }
        white.color = bodyC
        neckWhite.color = bodyC
        orange.color = beakC
        legs.color = beakC

        bubble?.let {
            val r = RectF(width * 0.12f, 1 * d, width * 0.88f, 20 * d)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleFill)
            c.drawRoundRect(r, 8 * d, 8 * d, bubbleLine)
            c.drawText(it, r.centerX(), r.centerY() + 5 * d, bubbleText)
        }

        c.save()
        c.translate(0f, (height - width).toFloat())
        val s = width / 100f
        c.scale(s, s)
        if (facingLeft) c.scale(-1f, 1f, 50f, 50f)
        if (walking) c.translate(0f, -abs(sin(phase)) * 2f)

        // legs + feet (+ shoes)
        val step = if (walking) sin(phase) * 5f else 0f
        for (fx in floatArrayOf(42f + step, 54f - step)) {
            c.drawLine(fx, 80f, fx, 91f, legs)
            c.drawOval(RectF(fx - 6f, 89f, fx + 6f, 95f), orange)
            feetDraw(c, feetId, fx)
        }
        // things worn behind the body
        backBehind(c, backId)
        // tail
        val tail = Path().apply { moveTo(24f, 66f); lineTo(6f, 56f); lineTo(26f, 78f); close() }
        c.drawPath(tail, white); c.drawPath(tail, outline)
        // body + wing
        val body = RectF(20f, 56f, 72f, 88f)
        c.drawOval(body, white); c.drawOval(body, outline)
        c.drawArc(RectF(30f, 62f, 62f, 82f), 10f, 150f, false, outline)
        backFront(c, backId)
        // neck
        c.drawLine(62f, 64f, 72f, 36f, neckOutline)
        c.drawLine(62f, 64f, 72f, 36f, neckWhite)
        neckDraw(c, neckId)

        // head, beak, eye
        c.drawCircle(74f, 30f, 9f, white); c.drawCircle(74f, 30f, 9f, outline)
        val beak = Path().apply { moveTo(81f, 27f); lineTo(96f, 32f); lineTo(81f, 37f); close() }
        c.drawPath(beak, orange); c.drawPath(beak, outline)
        c.drawCircle(77f, 27f, 2f, black)

        faceDraw(c, faceId)
        hatDraw(c, hatId)
        c.restore()
    }
}
