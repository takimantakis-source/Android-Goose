package com.example.goosedroid

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import java.util.Locale

fun tr(s: String): String = Lang.tr(s)
fun trf(s: String, vararg args: Any): String = Lang.format(s, *args)

/**
 * UI language. The app's texts are English; German is built in (German.kt).
 * Every other language is translated on the phone by Google's ML Kit (one download per language,
 * then it works offline) and the result is saved.
 */
object Lang {
    private var app: Context? = null
    var code = "en"
        private set
    private var map: Map<String, String> = emptyMap()

    val languages: List<String> by lazy { (listOf("en", "de") + TranslateLanguage.getAllLanguages()).distinct() }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val saved = Store.prefs(ctx).getString("lang", null)
        code = saved ?: if (Locale.getDefault().language == "de") "de" else "en"
        map = load(code)
    }

    private fun load(c: String): Map<String, String> = when (c) {
        "en" -> emptyMap()
        "de" -> German.MAP
        else -> cached(c)
    }

    private fun cached(c: String): Map<String, String> {
        val a = app ?: return emptyMap()
        val out = HashMap<String, String>()
        try {
            val j = JSONObject(Store.prefs(a).getString("tr_$c", "{}") ?: "{}")
            for (k in j.keys()) out[k] = j.getString(k)
        } catch (_: Exception) {}
        return out
    }

    fun has(c: String): Boolean {
        val a = app ?: return c == "en"
        return c == "en" || c == "de" ||
            (Store.prefs(a).contains("tr_$c") && Store.prefs(a).getInt("trn_$c", -1) == StringKeys.ALL.size)
    }

    fun set(c: String) {
        val a = app ?: return
        Store.prefs(a).edit().putString("lang", c).apply()
        code = c
        map = load(c)
    }

    fun tr(s: String): String = map[s] ?: s

    fun format(s: String, vararg args: Any): String =
        try { String.format(tr(s), *args) } catch (_: Exception) { String.format(s, *args) }

    fun nativeName(c: String): String {
        val l = Locale.forLanguageTag(c)
        return l.getDisplayLanguage(l).replaceFirstChar { it.uppercase() }
    }

    fun englishName(c: String): String = Locale.forLanguageTag(c).getDisplayLanguage(Locale.ENGLISH)

    /** Downloads the language model, translates every text in StringKeys.ALL and saves the result. */
    fun download(c: String, progress: (Int, Int) -> Unit, done: (Boolean) -> Unit) {
        val a = app
        if (a == null) { done(false); return }
        try {
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(c)
                    .build()
            )
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnFailureListener { translator.close(); done(false) }
                .addOnSuccessListener {
                    val keys = StringKeys.ALL
                    val out = JSONObject()
                    fun next(i: Int) {
                        if (i >= keys.size) {
                            Store.prefs(a).edit().putString("tr_$c", out.toString()).putInt("trn_$c", keys.size).apply()
                            translator.close()
                            done(true)
                            return
                        }
                        progress(i, keys.size)
                        translateString(translator, keys[i]) { res ->
                            if (res != null) out.put(keys[i], res)
                            next(i + 1)
                        }
                    }
                    next(0)
                }
        } catch (e: Throwable) {
            done(false)
        }
    }

    /** Keeps %d / %s placeholders safe by swapping them for tokens, and checks they survive. */
    private fun translateString(t: Translator, s: String, cb: (String?) -> Unit) {
        val specs = Regex("%[sd]").findAll(s).map { it.value }.toList()
        var work = s
        specs.forEachIndexed { i, sp -> work = work.replaceFirst(sp, "QX${i}Z") }
        val lines = work.split("\n")
        val out = ArrayList<String>()
        fun step(i: Int) {
            if (i >= lines.size) {
                var r = out.joinToString("\n")
                for (k in specs.indices) {
                    if (!r.contains("QX${k}Z")) { cb(null); return }
                    r = r.replace("QX${k}Z", "%${k + 1}\$s")
                }
                cb(r)
                return
            }
            val line = lines[i]
            if (line.isBlank()) { out.add(line); step(i + 1); return }
            t.translate(line)
                .addOnSuccessListener { out.add(it); step(i + 1) }
                .addOnFailureListener { cb(null) }
        }
        step(0)
    }
}
