package com.example.goosedroid

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.widget.FrameLayout
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val games = listOf(
        Triple("catch", "🪿 Catch the Goose", "Tap the goose. It gets faster!"),
        Triple("bread", "🍞 Bread Catch", "Drag the goose to catch bread. Dodge rocks."),
        Triple("simon", "🎵 Honk Memory", "Repeat the goose's honk pattern."),
        Triple("flappy", "🌾 Flappy Goose", "Tap to flap through the reeds."),
        Triple("whack", "🦊 Whack-a-Goose", "Tap geese as they pop up. Not foxes!"),
        Triple("hunt", "🔎 Goose Hunt", "3D tag: chase the geese, then run! You pick the round length."),
        Triple("obby", "🏃 Goose Obby", "3D parkour: jump, climb, shoot and beat bosses!"),
        Triple("shove", "🏢 Goose Shove", "3D: shove geese off a skyscraper. Fall and you must climb back!")
    )
    private val gameButtons = ArrayList<Button>()
    private lateinit var shopButton: Button
    private var shownLang = ""
    private var rootFrame: FrameLayout? = null
    private var tutorial: Tutorial? = null
    private val swipe: GestureDetector by lazy {
        makeSwipe(
            this,
            { if (tutorial == null) startActivity(Intent(this, ChatActivity::class.java)) },
            { if (tutorial == null) startActivity(Intent(this, Shop2Activity::class.java)) }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        shownLang = Lang.code
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad / 2)
        }
        fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("🎵") { startActivity(Intent(this, MusicActivity::class.java)) }.apply { textSize = 22f })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(button("❓") { showTutorial() }.apply { textSize = 22f })
        top.addView(button("⚙") { startActivity(Intent(this, SettingsActivity::class.java)) }.apply { textSize = 22f })
        top.addView(button(if (ThemeMode.dark(this)) "☀️" else "🌙") {
            ThemeMode.toggle(this)
            recreate()
        }.apply { textSize = 22f })
        root.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        root.addView(label("🪿 GooseDroid", 30f))
        root.addView(label(tr("◀ Swipe left: chat 💬     Swipe right: 🧰 extras ▶"), 12f))
        root.addView(label(tr("Lets a goose waddle over your screen.\nTap it to honk. Drag it to pick it up."), 14f))
        root.addView(button(tr("Release the goose")) { start() })
        root.addView(button(tr("Shoo goose away")) { stopService(Intent(this, GooseService::class.java)) })

        shopButton = button("") { startActivity(Intent(this, ShopActivity::class.java)) }
        root.addView(shopButton)

        root.addView(label(tr("Minigames"), 22f))
        for ((key, title, _) in games) {
            val b = button("") {
                AlertDialog.Builder(this)
                    .setTitle(tr(title))
                    .setItems(arrayOf(tr("Play solo"), tr("Play online (player or bot)"))) { _, which ->
                        val maps: List<String>? = when (key) {
                            "hunt" -> HuntMaps.ALL.map { tr(it.name) }
                            "shove" -> TowerMaps.ALL.map { tr(it.name) }
                            else -> null
                        }
                        if (maps != null) {
                            AlertDialog.Builder(this)
                                .setTitle(tr("Choose a map"))
                                .setItems(maps.toTypedArray()) { _, m -> pickLength(key, which == 1, m) }
                                .show()
                        } else launchGame(key, which == 1, 0)
                    }.show()
            }
            gameButtons.add(b)
            root.addView(b)
        }
        root.addView(label(
            tr("Online matches use the public ntfy.sh relay. Your goose nickname and scores are visible to the other player. If nobody is found within ~9 seconds you play a bot (marked 🤖)."),
            12f
        ))

        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { isFillViewport = true; addView(root) })
        setContentView(frame)
        rootFrame = frame
        if (!Store.prefs(this).getBoolean("tutorial_done", false)) frame.post { showTutorial() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun showTutorial() {
        val f = rootFrame ?: return
        if (tutorial != null) return
        val tu = Tutorial(this) {
            tutorial?.let { f.removeView(it) }
            tutorial = null
            Store.prefs(this).edit().putBoolean("tutorial_done", true).apply()
        }
        tutorial = tu
        f.addView(tu, FrameLayout.LayoutParams(-1, -1))
    }

    override fun onResume() {
        super.onResume()
        if (shownLang != Lang.code) { recreate(); return } // language was changed in settings
        Cosmetics.refresh(this)
        val prefs = Store.prefs(this)
        shopButton.text = trf("🛍 Shop   (🪙 %d)", Store.coins(this))
        games.forEachIndexed { i, (key, title, hint) ->
            gameButtons[i].text = tr(title) + "\n" + tr(hint) + "\n" + trf("Best: %d", prefs.getInt(key, 0))
        }
    }

    private fun launchGame(key: String, online: Boolean, map: Int, minutes: Int = 10) {
        startActivity(
            Intent(this, GameActivity::class.java)
                .putExtra("game", key).putExtra("online", online).putExtra("map", map)
                .putExtra("minutes", minutes)
        )
    }

    /** Goose Hunt / Goose Shove: you choose how long a round lasts. Online rounds have a fixed length so both players get the same. */
    private fun pickLength(key: String, online: Boolean, map: Int) {
        if (online) { launchGame(key, true, map, if (key == "shove") 3 else 5); return }
        val mins = if (key == "shove") intArrayOf(1, 2, 3, 5, 10) else intArrayOf(2, 3, 5, 10, 15, 20, 30)
        AlertDialog.Builder(this)
            .setTitle(tr("Choose round length"))
            .setItems(mins.map { trf("%d min", it) }.toTypedArray()) { _, i -> launchGame(key, false, map, mins[i]) }
            .show()
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, tr("Allow \"Display over other apps\", then come back"), Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, GooseService::class.java))
    }
}
