package com.example.goosedroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri

/** Look of the music player: accent color, "liquid glass" panels and background. */
object MusicDesign {
    val ACCENTS = listOf(
        Triple("blue", "Blue", Color.rgb(33, 150, 243)),
        Triple("green", "Green", Color.rgb(67, 160, 71)),
        Triple("red", "Red", Color.rgb(229, 57, 53)),
        Triple("yellow", "Yellow", Color.rgb(251, 192, 45)),
        Triple("purple", "Purple", Color.rgb(142, 36, 170))
    )
    val BACKGROUNDS = listOf(
        "default" to "Design color",
        "sunset" to "Sunset",
        "ocean" to "Ocean",
        "aurora" to "Aurora",
        "night" to "Night",
        "custom" to "My picture"
    )

    fun accentKey(ctx: Context): String = Store.prefs(ctx).getString("m_accent", "blue") ?: "blue"
    fun accent(ctx: Context): Int = (ACCENTS.firstOrNull { it.first == accentKey(ctx) } ?: ACCENTS[0]).third
    fun glass(ctx: Context): Boolean = Store.prefs(ctx).getBoolean("m_glass", false)
    fun bgKey(ctx: Context): String = Store.prefs(ctx).getString("m_bg", "default") ?: "default"
    fun bgUri(ctx: Context): Uri? = Store.prefs(ctx).getString("m_bg_uri", null)?.let { Uri.parse(it) }

    fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    fun onAccent(a: Int): Int {
        val lum = (0.299 * Color.red(a) + 0.587 * Color.green(a) + 0.114 * Color.blue(a)) / 255
        return if (lum > 0.6) Color.BLACK else Color.WHITE
    }

    fun textColor(ctx: Context): Int =
        if (ThemeMode.dark(ctx) || bgKey(ctx) != "default") Color.WHITE else Color.rgb(25, 25, 25)

    fun scrim(ctx: Context): Int = when (bgKey(ctx)) {
        "default" -> Color.TRANSPARENT
        "custom" -> Color.argb(110, 0, 0, 0)
        else -> Color.argb(45, 0, 0, 0)
    }

    /** Panel behind lists and cards: frosted "liquid glass" or a plain card. */
    fun panel(ctx: Context, radiusDp: Float): Drawable {
        val d = ctx.resources.displayMetrics.density
        val r = radiusDp * d
        val dark = ThemeMode.dark(ctx)
        val base = GradientDrawable().apply { cornerRadius = r }
        if (glass(ctx)) {
            base.setColor(Color.argb(if (dark) 60 else 95, 255, 255, 255))
            base.setStroke(maxOf(1, (1.5f * d).toInt()), Color.argb(150, 255, 255, 255))
            val sheen = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.argb(110, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(45, 255, 255, 255))
            ).apply { cornerRadius = r }
            return LayerDrawable(arrayOf(base, sheen))
        }
        val a = accent(ctx)
        base.setColor(if (dark) Color.argb(235, 34, 38, 48) else Color.argb(235, 255, 255, 255))
        base.setStroke(maxOf(1, d.toInt()), Color.argb(120, Color.red(a), Color.green(a), Color.blue(a)))
        return base
    }

    fun button(ctx: Context): Drawable {
        val d = ctx.resources.displayMetrics.density
        val a = accent(ctx)
        val base = GradientDrawable().apply { cornerRadius = 14 * d }
        if (!glass(ctx)) { base.setColor(a); return base }
        base.setColor(Color.argb(170, Color.red(a), Color.green(a), Color.blue(a)))
        base.setStroke(maxOf(1, (1.5f * d).toInt()), Color.argb(170, 255, 255, 255))
        val sheen = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(120, 255, 255, 255), Color.argb(0, 255, 255, 255))
        ).apply { cornerRadius = 14 * d }
        return LayerDrawable(arrayOf(base, sheen))
    }

    /** The background picture: your own image, or a generated soft gradient with colored blobs. */
    fun background(ctx: Context, w: Int, h: Int): Bitmap {
        val key = bgKey(ctx)
        if (key == "custom") {
            val c = custom(ctx, w, h)
            if (c != null) return if (glass(ctx)) blur(c, 8) else c
        }
        return generated(ctx, if (key == "custom") "default" else key, maxOf(2, w / 2), maxOf(2, h / 2))
    }

    private fun custom(ctx: Context, w: Int, h: Int): Bitmap? {
        val uri = bgUri(ctx) ?: return null
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            val o2 = BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(o.outWidth / w, o.outHeight / h)) }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (_: Exception) {
            null
        }
    }

    /** Cheap blur: shrink then stretch back up. */
    private fun blur(src: Bitmap, factor: Int): Bitmap {
        val small = Bitmap.createScaledBitmap(src, maxOf(1, src.width / factor), maxOf(1, src.height / factor), true)
        return Bitmap.createScaledBitmap(small, src.width, src.height, true)
    }

    private fun generated(ctx: Context, key: String, w: Int, h: Int): Bitmap {
        val a = accent(ctx)
        val dark = ThemeMode.dark(ctx)
        val (c1, c2, blobs) = when (key) {
            "sunset" -> Triple(
                Color.rgb(255, 94, 98), Color.rgb(110, 40, 140),
                intArrayOf(Color.rgb(255, 195, 113), Color.rgb(255, 106, 136), Color.rgb(142, 45, 226))
            )
            "ocean" -> Triple(
                Color.rgb(33, 147, 176), Color.rgb(20, 60, 110),
                intArrayOf(Color.rgb(109, 213, 237), Color.rgb(0, 201, 255), Color.rgb(80, 120, 255))
            )
            "aurora" -> Triple(
                Color.rgb(15, 32, 39), Color.rgb(29, 151, 108),
                intArrayOf(Color.rgb(147, 249, 185), Color.rgb(142, 45, 226), Color.rgb(74, 0, 224))
            )
            "night" -> Triple(
                Color.rgb(15, 12, 41), Color.rgb(48, 43, 99),
                intArrayOf(Color.rgb(91, 134, 229), Color.rgb(142, 84, 233), Color.rgb(36, 36, 62))
            )
            else -> Triple(
                mix(a, if (dark) Color.BLACK else Color.WHITE, if (dark) 0.65f else 0.75f),
                mix(a, if (dark) Color.BLACK else Color.WHITE, if (dark) 0.25f else 0.35f),
                intArrayOf(a, mix(a, Color.WHITE, 0.4f), mix(a, Color.rgb(255, 0, 200), 0.35f))
            )
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w * 0.3f, h.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val spots = arrayOf(0.15f to 0.12f, 0.9f to 0.3f, 0.25f to 0.7f, 0.85f to 0.92f)
        val big = maxOf(w, h) * 0.6f
        spots.forEachIndexed { i, (fx, fy) ->
            val col = blobs[i % blobs.size]
            p.shader = RadialGradient(
                w * fx, h * fy, big,
                Color.argb(170, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(w * fx, h * fy, big, p)
        }
        return bmp
    }
}
