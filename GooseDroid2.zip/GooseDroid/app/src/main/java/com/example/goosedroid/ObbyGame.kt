package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan
import kotlin.random.Random

/**
 * Game 7: Goose Obby. An endless 3D parkour course (drawn with a small 3D engine on the canvas).
 * Jump gaps, climb walls, dodge hazards, grab coins and guns, fight foxes and bosses, and use the
 * HONK BLAST: a shockwave that stuns enemies and wipes enemy shots.
 */
class ObbyGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "obby", versus, onExit) {

    companion object {
        const val GRAV = 28f
        const val JUMP_V = 10.5f
        const val HALF = 0.35f
        const val PH = 0.9f
        const val STEP = 0.35f
        const val CLIMB_MAX = 2.4f
        const val FOG = 85f
        const val NEAR = 0.3f
        const val HALF_PATH = 3.6f
        const val PITCH = 0.30f
        const val COIN = 0
        const val HEART = 1
        const val GUN_BLASTER = 2
        const val GUN_SHOTGUN = 3
        const val GUN_ROCKET = 4
        val PALETTE = intArrayOf(
            Color.rgb(104, 200, 90), Color.rgb(100, 181, 246), Color.rgb(255, 183, 77),
            Color.rgb(240, 98, 146), Color.rgb(77, 208, 225), Color.rgb(186, 104, 200)
        )
        val SKY_TOP = intArrayOf(Color.rgb(90, 170, 235), Color.rgb(120, 70, 150), Color.rgb(8, 14, 45))
        val SKY_HOR = intArrayOf(Color.rgb(200, 235, 255), Color.rgb(255, 160, 110), Color.rgb(50, 70, 130))
    }

    override val coinRate = 0.2f
    override val versusLimitMs = 120_000L
    override fun currentScore() = score

    // ---------- world objects ----------
    // kind: 0 solid, 1 hazard (hurts), 2 moving platform, 3 gate (cannot be climbed)
    private class Block(
        var x0: Float, var x1: Float, val y0: Float, val y1: Float,
        val z0: Float, val z1: Float, val color: Int, val kind: Int
    ) {
        var base = 0f
        var amp = 0f
        var speed = 0f
        var phase = 0f
        var dx = 0f
    }

    private class Pick(val kind: Int, val x: Float, val y: Float, val z: Float) { var taken = false }

    private class Enemy(var x: Float, val y: Float, var z: Float, val boss: Boolean, var hp: Int, val segZ0: Float) {
        val maxHp = hp
        var stun = 0f
        var cool = 1.5f
        var hit = 0f
        var dead = false
    }

    private class Npc(val x: Float, val y: Float, val z: Float, val line: Int) { var used = false }

    // kind: 0 bullet, 1 pellet, 2 rocket, 3 enemy shot
    private class Proj(
        var x: Float, var y: Float, var z: Float,
        val vx: Float, val vy: Float, val vz: Float, val dmg: Int, val friendly: Boolean, val kind: Int
    ) { var life = 2f }

    private class DI(val z: Float, val type: Int, val ref: Any?)

    private val blocks = ArrayList<Block>()
    private val picks = ArrayList<Pick>()
    private val enemies = ArrayList<Enemy>()
    private val npcs = ArrayList<Npc>()
    private val projs = ArrayList<Proj>()
    private val safe = ArrayList<Float>()
    private val items = ArrayList<DI>()

    // ---------- player state ----------
    private var px = 0f
    private var py = 0f
    private var pz = 0f
    private var vy = 0f
    private var onGround = true
    private var coyote = 0f
    private var jumpBuf = 0f
    private var standing: Block? = null
    private var climbing = false
    private var climbTarget = 0f
    private var hp = 5
    private var invuln = 0f
    private var coins = 0
    private var kills = 0
    private var bosses = 0
    private var score = 0
    private var weapon = 0
    private var ammo = 0
    private var fireCd = 0f
    private var honkCd = 0f
    private var shockT = 0f
    private var t = 0f
    private var phase = 0f

    private var genZ = 0f
    private var segCount = 0
    private var hardRun = 0
    private var nextBossZ = 0f
    private var bossIndex = 0
    private var boss: Enemy? = null
    private var gate: Block? = null
    private var fighting = false
    private var arenaZ0 = 0f

    private var camX = 0f
    private var camY = 0f
    private var camZ = 0f
    private var camBase = 0f
    private var lastAt = 0L
    private var flash = ""
    private var flashUntil = 0L
    private var ready = false

    private var steer = 0f
    private var steerPid = -1
    private var firePid = -1
    private var steerOx = 0f

    // ---------- drawing tools ----------
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(70, 0, 0, 0); strokeWidth = 1.5f
    }
    private val skyP = Paint()
    private val voidP = Paint()
    private val uiP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val leftP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()
    private val rect = RectF()
    private val pr = FloatArray(8)
    private val pu = FloatArray(8)
    private val pd = FloatArray(8)
    private val qr = FloatArray(16)
    private val qu = FloatArray(16)
    private val qd = FloatArray(16)
    private val cosP = cos(PITCH)
    private val sinP = sin(PITCH)
    private var focal = 1f
    private var cx0 = 0f
    private var cy0 = 0f
    private var fogC = Color.WHITE

    // goose body parts: dx, y0, dz, hw, h, hd, color (0 body, 1 beak, 2 wing) - far to near when facing +z
    private val gp = arrayOf(
        floatArrayOf(0f, 1.12f, 0.62f, 0.08f, 0.10f, 0.16f, 1f),
        floatArrayOf(0f, 1.05f, 0.30f, 0.17f, 0.30f, 0.17f, 0f),
        floatArrayOf(0f, 0.70f, 0.20f, 0.10f, 0.40f, 0.10f, 0f),
        floatArrayOf(0f, 0.30f, 0f, 0.30f, 0.45f, 0.42f, 0f),
        floatArrayOf(-0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0f, 0.45f, -0.50f, 0.10f, 0.18f, 0.12f, 0f)
    )

    init {
        hud.setTextColor(Color.WHITE)
        hud.setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    // =====================================================================
    // setup
    // =====================================================================

    override fun reset() {
        blocks.clear(); picks.clear(); enemies.clear(); npcs.clear(); projs.clear(); safe.clear()
        px = 0f; py = 0f; pz = 0f; vy = 0f
        onGround = true; standing = null; climbing = false
        hp = 5; invuln = 0f; coins = 0; kills = 0; bosses = 0; score = 0
        weapon = 0; ammo = 0; fireCd = 0f; honkCd = 0f; shockT = 0f
        t = 0f; phase = 0f; steer = 0f; jumpBuf = 0f; coyote = 0f
        steerPid = -1; firePid = -1
        bossIndex = 0; boss = null; gate = null; fighting = false
        nextBossZ = 330f; hardRun = 0; segCount = 0

        plat(-14f, 34f)
        safe.add(10f)
        picks.add(Pick(GUN_BLASTER, 0f, 0.5f, 18f))
        coinLine(0f, 0.7f, 6f, 14f, 5)
        genZ = 34f

        camX = 0f; camBase = 0f; camY = 2.8f; camZ = -6f
        lastAt = SystemClock.uptimeMillis()
        flash = ""; flashUntil = 0L
        focal = width * 0.9f
        cx0 = width / 2f
        cy0 = height * 0.46f
        ensureAhead()
        ready = true
    }

    private fun plat(
        z0: Float, z1: Float, x0: Float = -HALF_PATH, x1: Float = HALF_PATH,
        color: Int = PALETTE[segCount % PALETTE.size]
    ) {
        blocks.add(Block(x0, x1, -1.2f, 0f, z0, z1, color, 0))
    }

    private fun coinLine(x: Float, y: Float, z0: Float, z1: Float, n: Int) {
        for (i in 0 until n) picks.add(Pick(COIN, x, y, z0 + (z1 - z0) * i / max(1, n - 1)))
    }

    private fun coinArc(x: Float, z0: Float, z1: Float, n: Int, peak: Float) {
        for (i in 0 until n) {
            val f = i / max(1f, n - 1f)
            picks.add(Pick(COIN, x, 0.7f + peak * 4f * f * (1f - f), z0 + (z1 - z0) * f))
        }
    }

    private fun lvl() = min(1f, genZ / 1500f)

    // =====================================================================
    // endless course generator
    // =====================================================================

    private fun ensureAhead() {
        while (genZ < pz + 95f) genSegment()
    }

    private fun genSegment() {
        val z0 = genZ
        segCount++
        val len: Float
        if (z0 >= nextBossZ && boss == null) {
            nextBossZ += 520f
            len = genBoss(z0)
        } else if (hardRun >= 2) {
            hardRun = 0
            len = genFlat(z0)
        } else {
            hardRun++
            val choice = if (z0 < 120f) Random.nextInt(3) else Random.nextInt(7)
            len = when (choice) {
                0 -> genGaps(z0)
                1 -> genHurdles(z0)
                2 -> genWalls(z0)
                3 -> genStairs(z0)
                4 -> genBeam(z0)
                5 -> genMoving(z0)
                else -> genSweepers(z0)
            }
        }
        genZ += len
    }

    private fun genFlat(z0: Float): Float {
        val len = 12f
        plat(z0, z0 + len)
        safe.add(z0 + len / 2f)
        coinLine(Random.nextFloat() * 3f - 1.5f, 0.7f, z0 + 2f, z0 + len - 2f, 6)
        val r = Random.nextInt(10)
        if (r < 4) {
            enemies.add(Enemy(Random.nextFloat() * 4f - 2f, 0f, z0 + len - 2f, false, 2, z0))
            if (lvl() > 0.4f && Random.nextBoolean()) {
                enemies.add(Enemy(Random.nextFloat() * 4f - 2f, 0f, z0 + len - 4f, false, 2, z0))
            }
        } else if (r < 6) {
            npcs.add(Npc(if (Random.nextBoolean()) -2.8f else 2.8f, 0f, z0 + len / 2f, Random.nextInt(3)))
        }
        if (Random.nextInt(4) == 0) {
            picks.add(Pick(GUN_BLASTER + Random.nextInt(3), Random.nextFloat() * 4f - 2f, 0.5f, z0 + 3f))
        }
        if (Random.nextInt(7) == 0) picks.add(Pick(HEART, Random.nextFloat() * 4f - 2f, 0.6f, z0 + 6f))
        return len
    }

    private fun genGaps(z0: Float): Float {
        var z = z0
        plat(z, z + 6f); z += 6f
        for (i in 0 until 2 + Random.nextInt(2)) {
            val g = 3.0f + 1.5f * lvl() + Random.nextFloat() * 0.4f
            coinArc(0f, z, z + g, 5, 1.2f)
            z += g
            val l = 4f + Random.nextFloat() * 2f
            plat(z, z + l); z += l
        }
        return z - z0
    }

    private fun genHurdles(z0: Float): Float {
        plat(z0, z0 + 24f)
        for (k in 0 until 3) {
            val zf = z0 + 6f + k * 6f
            val side = Random.nextInt(3)
            val xa = if (side == 2) -1.0f else -HALF_PATH
            val xb = if (side == 1) 1.0f else HALF_PATH
            blocks.add(Block(xa, xb, 0f, 0.8f, zf, zf + 0.4f, Color.rgb(229, 57, 53), 1))
            coinLine(0f, 1.6f, zf - 0.6f, zf + 1.0f, 3)
        }
        return 24f
    }

    private fun genWalls(z0: Float): Float {
        plat(z0, z0 + 26f)
        for (k in 0 until (if (lvl() > 0.5f) 3 else 2)) {
            val zf = z0 + 6f + k * 8f
            val h = 1.5f + Random.nextFloat() * 0.8f
            blocks.add(Block(-HALF_PATH, HALF_PATH, 0f, h, zf, zf + 1.6f, Color.rgb(255, 152, 0), 0))
            coinLine(0f, h + 0.7f, zf, zf + 1.6f, 3)
        }
        return 26f
    }

    private fun genStairs(z0: Float): Float {
        val col = PALETTE[segCount % PALETTE.size]
        plat(z0, z0 + 5f)
        var z = z0 + 5f
        for (i in 1..3) { blocks.add(Block(-1.8f, 1.8f, -1.2f, 0.8f * i, z, z + 2.6f, col, 0)); z += 2.6f }
        blocks.add(Block(-1.8f, 1.8f, -1.2f, 2.4f, z, z + 4f, col, 0))
        coinLine(0f, 3.1f, z, z + 4f, 4)
        z += 4f
        for (i in 2 downTo 1) { blocks.add(Block(-1.8f, 1.8f, -1.2f, 0.8f * i, z, z + 2.6f, col, 0)); z += 2.6f }
        plat(z, z + 5f); z += 5f
        return z - z0
    }

    private fun genBeam(z0: Float): Float {
        plat(z0, z0 + 4f)
        blocks.add(Block(-0.6f, 0.6f, -0.4f, 0f, z0 + 4f, z0 + 18f, Color.rgb(161, 136, 127), 0))
        coinLine(0f, 0.7f, z0 + 5f, z0 + 17f, 7)
        plat(z0 + 18f, z0 + 22f)
        return 22f
    }

    private fun genMoving(z0: Float): Float {
        plat(z0, z0 + 5f)
        for ((i, zs) in floatArrayOf(8f, 14f).withIndex()) {
            val m = Block(-1.6f, 1.6f, -0.4f, 0f, z0 + zs, z0 + zs + 3f, Color.rgb(0, 188, 212), 2)
            m.base = 0f; m.amp = 2.0f; m.speed = 1.4f + i * 0.5f; m.phase = Random.nextFloat() * 6f
            blocks.add(m)
        }
        plat(z0 + 20f, z0 + 25f)
        return 25f
    }

    private fun genSweepers(z0: Float): Float {
        plat(z0, z0 + 22f)
        for (zs in floatArrayOf(7f, 14f)) {
            val s = Block(-1.6f, 1.6f, 0f, 0.9f, z0 + zs, z0 + zs + 0.5f, Color.rgb(244, 67, 54), 1)
            s.base = 0f; s.amp = 2.0f; s.speed = 2.0f + lvl(); s.phase = Random.nextFloat() * 6f
            blocks.add(s)
        }
        return 22f
    }

    private fun genBoss(z0: Float): Float {
        plat(z0, z0 + 8f)
        arenaZ0 = z0 + 8f
        plat(arenaZ0, arenaZ0 + 26f, -6f, 6f, Color.rgb(90, 70, 110))
        val g = Block(-6f, 6f, 0f, 6f, arenaZ0 + 26f, arenaZ0 + 27.5f, Color.rgb(120, 60, 160), 3)
        blocks.add(g)
        gate = g
        val e = Enemy(0f, 0f, arenaZ0 + 18f, true, 30 + 20 * bossIndex, arenaZ0)
        enemies.add(e)
        boss = e
        bossIndex++
        picks.add(Pick(GUN_BLASTER, -2.5f, 0.5f, z0 + 3f))
        picks.add(Pick(GUN_SHOTGUN, 2.5f, 0.5f, z0 + 3f))
        picks.add(Pick(GUN_ROCKET, 0f, 0.5f, arenaZ0 + 2f))
        picks.add(Pick(HEART, 0f, 0.6f, arenaZ0 + 3.5f))
        safe.add(z0 + 4f)
        return 35.5f
    }

    // =====================================================================
    // touch controls
    // =====================================================================

    private fun btnX(i: Int) = if (i == 1) width - 186 * d else width - 84 * d
    private fun btnY(i: Int) = when (i) { 0 -> height - 130 * d; 1 -> height - 84 * d; else -> height - 250 * d }
    private fun btnR(i: Int) = when (i) { 0 -> 50 * d; 1 -> 38 * d; else -> 34 * d }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val id = e.getPointerId(idx)
                val x = e.getX(idx)
                val y = e.getY(idx)
                var btn = -1
                for (i in 0 until 3) if (hypot(x - btnX(i), y - btnY(i)) <= btnR(i) + 10 * d) btn = i
                when {
                    btn == 0 -> jumpBuf = 0.15f
                    btn == 1 -> firePid = id
                    btn == 2 -> honk()
                    steerPid == -1 -> { steerPid = id; steerOx = x; steer = 0f }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    if (e.getPointerId(i) == steerPid) {
                        val x = e.getX(i)
                        val range = 45 * d
                        if (x - steerOx > range) steerOx = x - range
                        if (x - steerOx < -range) steerOx = x + range
                        steer = ((x - steerOx) / range).coerceIn(-1f, 1f)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == firePid) firePid = -1
                if (id == steerPid) { steerPid = -1; steer = 0f }
                if (a != MotionEvent.ACTION_POINTER_UP) { firePid = -1; steerPid = -1; steer = 0f }
            }
        }
        return true
    }

    // =====================================================================
    // game loop
    // =====================================================================

    override fun tick() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastAt) / 1000f).coerceIn(0.001f, 0.05f)
        lastAt = now
        t += dt
        invuln = max(0f, invuln - dt)
        fireCd = max(0f, fireCd - dt)
        honkCd = max(0f, honkCd - dt)
        shockT = max(0f, shockT - dt)
        jumpBuf = max(0f, jumpBuf - dt)
        coyote = max(0f, coyote - dt)

        updateBlocks()
        movePlayer(dt)
        if (!isRunning()) return
        if (firePid != -1) fire()

        val b = boss
        if (b != null && !fighting && pz > arenaZ0 + 3f) {
            fighting = true
            flashMsg(tr("⚠ BOSS FIGHT!"))
        }
        updateEnemies(dt)
        updateProjs(dt)
        updatePicks()
        updateNpcs()
        if (!isRunning()) return

        if (py < -9f) fell()
        if (!isRunning()) return

        ensureAhead()
        if (segCount % 4 == 0) blocks.removeAll { it.z1 < pz - 70f }
        safe.removeAll { it < pz - 90f }

        // camera follows the goose, a little smoothed
        camBase += (py - camBase) * min(1f, 4f * dt)
        camX += (px * 0.6f - camX) * min(1f, 8f * dt)
        camY = camBase + 2.8f
        camZ = pz - 6f

        score = calcScore()
        hud.text = trf("Score: %d   🪙 %d   %d m", score, coins, max(0f, pz).toInt())
        invalidate()
    }

    private fun calcScore() = (max(0f, pz) / 5f).toInt() + coins * 3 + kills * 10 + bosses * 100

    private fun flashMsg(s: String) {
        flash = s
        flashUntil = SystemClock.uptimeMillis() + 1600L
    }

    private fun updateBlocks() {
        for (b in blocks) {
            if (b.amp != 0f) {
                val c = b.base + sin(t * b.speed + b.phase) * b.amp
                b.dx = c - (b.x0 + b.x1) / 2f
                b.x0 += b.dx
                b.x1 += b.dx
            } else {
                b.dx = 0f
            }
        }
    }

    private fun overlap(b: Block, x: Float, y: Float, z: Float) =
        x + HALF > b.x0 && x - HALF < b.x1 && y + PH > b.y0 && y < b.y1 && z + HALF > b.z0 && z - HALF < b.z1

    private fun hitBlock(x: Float, y: Float, z: Float): Block? {
        for (b in blocks) {
            if (b.kind == 1 || b.z1 < z - 1f || b.z0 > z + 1f) continue
            if (overlap(b, x, y + STEP, z)) return b
        }
        return null
    }

    private fun movePlayer(dt: Float) {
        standing?.let { px += it.dx } // ride moving platforms

        val dxm = steer * 6.5f * dt
        if (dxm != 0f && hitBlock(px + dxm, py, pz) == null) px += dxm

        val speed = if (fighting) 0f else min(14f, 8f + max(0f, pz) / 250f)
        phase += dt * (6f + speed)

        if (climbing) {
            py += 8f * dt
            vy = 0f
            standing = null
            if (py >= climbTarget) { py = climbTarget; climbing = false; pz += 0.7f }
        } else {
            val nz = pz + speed * dt
            val hit = hitBlock(px, py, nz)
            if (hit == null) pz = nz
            else if (hit.kind != 3 && hit.y1 - py <= CLIMB_MAX) { climbing = true; climbTarget = hit.y1 }
            if (fighting && pz > arenaZ0 + 4f) pz = arenaZ0 + 4f

            if (jumpBuf > 0f && (onGround || coyote > 0f)) {
                vy = JUMP_V; onGround = false; coyote = 0f; jumpBuf = 0f
                Sound.play(400.0, 700.0, 70)
            }
            vy -= GRAV * dt
            val ny = py + vy * dt
            var ground = -1000f
            var gb: Block? = null
            for (b in blocks) {
                if (b.kind == 1 || b.z1 < pz - 1f || b.z0 > pz + 1f) continue
                if (px + HALF > b.x0 && px - HALF < b.x1 && pz + HALF > b.z0 && pz - HALF < b.z1 &&
                    b.y1 <= py + STEP + 0.001f && b.y1 > ground
                ) { ground = b.y1; gb = b }
            }
            if (vy <= 0f && ny <= ground) {
                py = ground; vy = 0f; onGround = true; standing = gb; coyote = 0.1f
            } else {
                py = ny; onGround = false; standing = null
            }
        }

        if (invuln <= 0f) { // hazards: spike fences and sweepers
            for (b in blocks) {
                if (b.kind != 1 || b.z1 < pz - 1f || b.z0 > pz + 1f) continue
                if (overlap(b, px, py, pz)) {
                    hurt(1)
                    pz -= 1.2f; vy = 7f; onGround = false; climbing = false
                    break
                }
            }
        }
    }

    private fun hurt(n: Int) {
        if (invuln > 0f) return
        hp -= n
        invuln = 1.5f
        Sound.play(200.0, 80.0, 180)
        if (hp <= 0) over()
    }

    private fun over() {
        gameOver(trf("You ran %d m and beat %d bosses!", max(0f, pz).toInt(), bosses), calcScore())
    }

    /** Fell into the void: lose a heart and come back on the last safe platform. */
    private fun fell() {
        hp -= 1
        Sound.play(300.0, 60.0, 300)
        if (hp <= 0) { over(); return }
        val s = safe.lastOrNull { it <= pz } ?: 10f
        px = 0f; pz = s; py = 0.5f; vy = 0f
        climbing = false; onGround = false; standing = null
        invuln = 2f
        camBase = py
    }

    // =====================================================================
    // weapons, enemies, bosses, pickups
    // =====================================================================

    private fun weaponName(w: Int) = when (w) { 1 -> tr("Blaster"); 2 -> tr("Shotgun"); else -> tr("Rocket launcher") }

    private fun giveGun(w: Int, a: Int) {
        if (weapon == w) ammo += a else { weapon = w; ammo = a }
        flashMsg(trf("Got %s!", weaponName(w)))
        Sound.play(600.0, 1000.0, 100)
    }

    private fun nearestTarget(): Enemy? {
        var best: Enemy? = null
        for (e in enemies) {
            if (e.dead || e.z < pz || e.z > pz + 45f) continue
            val cur = best
            if (cur == null || e.z < cur.z) best = e
        }
        return best
    }

    private fun fire() {
        if (weapon == 0 || ammo <= 0 || fireCd > 0f) return
        val ox = px
        val oy = py + 0.7f
        val oz = pz + 0.6f
        val tgt = nearestTarget()
        val aim = if (tgt != null) ((tgt.x - px) / max(0.5f, (tgt.z - pz) / 40f)).coerceIn(-9f, 9f) else 0f
        when (weapon) {
            1 -> { projs.add(Proj(ox, oy, oz, aim, 0f, 40f, 1, true, 0)); fireCd = 0.16f; Sound.play(900.0, 500.0, 50) }
            2 -> {
                for (k in -2..2) projs.add(Proj(ox, oy, oz, aim * 0.5f + k * 2.2f, 0f, 36f, 1, true, 1).also { it.life = 0.5f })
                fireCd = 0.8f; Sound.play(300.0, 120.0, 120)
            }
            else -> { projs.add(Proj(ox, oy, oz, aim, 0f, 26f, 6, true, 2)); fireCd = 1.0f; Sound.play(200.0, 90.0, 200) }
        }
        ammo--
        if (ammo <= 0) weapon = 0
    }

    /** HONK BLAST: stuns everything in front of you, hurts bosses and wipes enemy shots. */
    private fun honk() {
        if (honkCd > 0f) return
        honkCd = 8f
        shockT = 0.6f
        Sound.honk()
        flashMsg(tr("📢 HONK BLAST!"))
        for (e in enemies) {
            if (e.dead) continue
            val dz = e.z - pz
            if (dz > -2f && dz < 20f && abs(e.x - px) < 9f) {
                e.stun = 2.5f
                if (e.boss) damageEnemy(e, 3) else e.z += 2f
            }
        }
        projs.removeAll { !it.friendly && it.z - pz < 16f }
    }

    private fun damageEnemy(e: Enemy, dmg: Int) {
        e.hp -= dmg
        e.hit = 0.15f
        if (e.hp <= 0 && !e.dead && !e.boss) {
            e.dead = true
            kills++
            picks.add(Pick(COIN, e.x, e.y + 0.8f, e.z))
            picks.add(Pick(COIN, e.x + 0.5f, e.y + 0.8f, e.z))
            if (Random.nextInt(8) == 0) picks.add(Pick(HEART, e.x, e.y + 0.6f, e.z))
            Sound.play(500.0, 200.0, 90)
        }
    }

    private fun explode(p: Proj) {
        for (e in enemies) {
            if (!e.dead && hypot(e.x - p.x, e.z - p.z) < 3.2f) damageEnemy(e, 3)
        }
        Sound.play(150.0, 60.0, 220)
    }

    private fun updateEnemies(dt: Float) {
        for (e in enemies) {
            if (e.dead) continue
            e.hit = max(0f, e.hit - dt)
            e.stun = max(0f, e.stun - dt)
            if (e.boss) { bossAI(e, dt); continue }
            val dz = e.z - pz
            if (e.stun <= 0f && dz < 22f && dz > -3f) {
                e.z = max(e.segZ0 + 1f, e.z - 4.2f * dt)
                e.x = (e.x + (px - e.x).coerceIn(-2.6f * dt, 2.6f * dt)).coerceIn(-3.4f, 3.4f)
            }
            if (abs(e.x - px) < 0.8f && abs(e.z - pz) < 0.8f && abs(e.y - py) < 1.0f) hurt(1)
        }
        enemies.removeAll { it.dead || (!it.boss && it.z < pz - 40f) }
    }

    private fun bossAI(e: Enemy, dt: Float) {
        if (e.stun <= 0f) e.x = sin(t * 0.9f) * 4.2f
        e.cool -= dt
        if (fighting && e.stun <= 0f && e.cool <= 0f) {
            e.cool = max(0.9f, 2.0f - 0.2f * bossIndex)
            val n = if (e.hp < e.maxHp / 2) 3 else 1
            val tt = max(0.3f, (e.z - pz) / 14f)
            for (k in 0 until n) {
                val tx = px + (k - (n - 1) / 2f) * 2.2f
                projs.add(Proj(e.x, e.y + 0.7f, e.z - 2f, (tx - e.x) / tt, 0f, -14f, 1, false, 3).also { it.life = tt + 0.6f })
            }
            Sound.play(220.0, 120.0, 150)
        }
        if (e.hp <= 0) bossDefeated(e)
    }

    private fun bossDefeated(e: Enemy) {
        e.dead = true
        boss = null
        fighting = false
        gate?.let { blocks.remove(it) }
        gate = null
        bosses++
        for (k in 0 until 15) picks.add(Pick(COIN, e.x + (k % 5 - 2) * 0.8f, 0.9f + (k / 5) * 0.4f, e.z - 2f - k * 0.5f))
        picks.add(Pick(HEART, 0f, 0.6f, e.z - 1f))
        flashMsg(tr("Boss defeated! +100"))
        Sound.play(400.0, 900.0, 300)
        projs.removeAll { !it.friendly }
    }

    private fun updateProjs(dt: Float) {
        val iter = projs.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt
            p.life -= dt
            var remove = p.life <= 0f
            if (!remove && p.friendly) {
                for (e in enemies) {
                    if (e.dead) continue
                    val rx = if (e.boss) 1.3f else 0.8f
                    val rz = if (e.boss) 1.8f else 0.9f
                    val top = e.y + (if (e.boss) 3.0f else 1.4f)
                    if (abs(p.x - e.x) < rx && abs(p.z - e.z) < rz && p.y > e.y - 0.2f && p.y < top) {
                        damageEnemy(e, p.dmg)
                        if (p.kind == 2) explode(p)
                        remove = true
                        break
                    }
                }
                if (!remove && p.kind == 2 && p.life < 0.05f) explode(p)
            } else if (!remove && !p.friendly) {
                if (abs(p.x - px) < HALF + 0.4f && abs(p.z - pz) < HALF + 0.5f &&
                    p.y > py - 0.3f && p.y < py + PH + 0.3f
                ) { hurt(1); remove = true }
            }
            if (remove) iter.remove()
        }
    }

    private fun updatePicks() {
        for (p in picks) {
            if (p.taken) continue
            if (abs(p.x - px) < 0.9f && abs(p.z - pz) < 0.9f && p.y > py - 0.6f && p.y < py + PH + 0.8f) {
                p.taken = true
                when (p.kind) {
                    COIN -> { coins++; Sound.play(900.0, 1300.0, 45) }
                    HEART -> { hp = min(5, hp + 1); flashMsg("+1 ❤"); Sound.play(600.0, 900.0, 90) }
                    GUN_BLASTER -> giveGun(1, 60)
                    GUN_SHOTGUN -> giveGun(2, 14)
                    else -> giveGun(3, 6)
                }
            }
        }
        picks.removeAll { it.taken || it.z < pz - 40f }
    }

    private fun npcLine(i: Int) = when (i) {
        0 -> tr("Nice run, goose!")
        1 -> tr("Watch the gaps!")
        else -> tr("Foxes ahead! Grab a gun!")
    }

    private fun updateNpcs() {
        for (n in npcs) {
            if (n.used) continue
            if (abs(n.x - px) < 2.6f && abs(n.z - pz) < 2.6f) {
                n.used = true
                when (Random.nextInt(3)) {
                    0 -> { hp = min(5, hp + 1); flashMsg(tr("Take a heart! ❤")) }
                    1 -> {
                        if (weapon == 0) { weapon = 1; ammo = 40 } else ammo += 20
                        flashMsg(tr("Take some ammo!"))
                    }
                    else -> { coins += 8; flashMsg(tr("Take some coins!")) }
                }
                Sound.play(600.0, 1000.0, 120)
            }
        }
        npcs.removeAll { it.z < pz - 40f }
    }

    // =====================================================================
    // 3D drawing
    // =====================================================================

    private fun mixC(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
    )

    private fun tone(color: Int, k: Float, fog: Float): Int =
        mixC(Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt()), fogC, fog)

    /** World point -> camera space slot i (right, up, depth). */
    private fun put(i: Int, x: Float, y: Float, z: Float) {
        val rx = x - camX
        val ry = y - camY
        val rz = z - camZ
        pr[i] = rx
        pu[i] = ry * cosP + rz * sinP
        pd[i] = -ry * sinP + rz * cosP
    }

    /** Fills the polygon in slots 0 until n, clipped against the near plane. */
    private fun poly(c: Canvas, color: Int, n: Int) {
        var m = 0
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            val di = pd[i] - NEAR
            val dj = pd[j] - NEAR
            if (di >= 0f) { qr[m] = pr[i]; qu[m] = pu[i]; qd[m] = pd[i]; m++ }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                qr[m] = pr[i] + (pr[j] - pr[i]) * f
                qu[m] = pu[i] + (pu[j] - pu[i]) * f
                qd[m] = NEAR
                m++
            }
        }
        if (m < 3) return
        path.reset()
        for (k in 0 until m) {
            val sx = cx0 + focal * qr[k] / qd[k]
            val sy = cy0 - focal * qu[k] / qd[k]
            if (k == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        path.close()
        fillP.color = color
        c.drawPath(path, fillP)
        c.drawPath(path, lineP)
    }

    private fun box(c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, z0: Float, z1: Float, color: Int) {
        if (z1 < camZ + NEAR) return
        val zn = max(z0, camZ)
        val fog = ((zn + min(z1 - zn, 12f) / 2f - camZ) / FOG).coerceIn(0f, 0.9f)
        if (camZ < z0) {
            put(0, x0, y0, z0); put(1, x1, y0, z0); put(2, x1, y1, z0); put(3, x0, y1, z0)
            poly(c, tone(color, 0.78f, fog), 4)
        }
        if (camX < x0) {
            put(0, x0, y0, z0); put(1, x0, y0, z1); put(2, x0, y1, z1); put(3, x0, y1, z0)
            poly(c, tone(color, 0.62f, fog), 4)
        } else if (camX > x1) {
            put(0, x1, y0, z0); put(1, x1, y0, z1); put(2, x1, y1, z1); put(3, x1, y1, z0)
            poly(c, tone(color, 0.62f, fog), 4)
        }
        if (camY > y1) {
            put(0, x0, y1, z0); put(1, x1, y1, z0); put(2, x1, y1, z1); put(3, x0, y1, z1)
            poly(c, tone(color, 1f, fog), 4)
        }
    }

    private fun vb(c: Canvas, cx: Float, y0: Float, cz: Float, hw: Float, h: Float, hd: Float, color: Int) =
        box(c, cx - hw, cx + hw, y0, y0 + h, cz - hd, cz + hd, color)

    /** A flat glowing disc that always faces the camera (coins, bullets). */
    private fun disc(c: Canvas, x: Float, y: Float, z: Float, r: Float, color: Int, squash: Float) {
        put(0, x, y, z)
        if (pd[0] < NEAR) return
        val sx = cx0 + focal * pr[0] / pd[0]
        val sy = cy0 - focal * pu[0] / pd[0]
        val rad = focal * r / pd[0]
        val fog = (pd[0] / FOG).coerceIn(0f, 0.9f)
        rect.set(sx - rad * squash, sy - rad, sx + rad * squash, sy + rad)
        fillP.color = mixC(color, fogC, fog)
        c.drawOval(rect, fillP)
        c.drawOval(rect, lineP)
    }

    private fun emoji(c: Canvas, x: Float, y: Float, z: Float, s: String, size: Float) {
        put(0, x, y, z)
        if (pd[0] < NEAR) return
        textP.textSize = focal * size / pd[0]
        c.drawText(s, cx0 + focal * pr[0] / pd[0], cy0 - focal * pu[0] / pd[0], textP)
    }

    private fun bubble(c: Canvas, x: Float, y: Float, z: Float, s: String) {
        put(0, x, y, z)
        if (pd[0] < NEAR) return
        val sx = cx0 + focal * pr[0] / pd[0]
        val sy = cy0 - focal * pu[0] / pd[0]
        leftP.textSize = 13 * d
        val tw = leftP.measureText(s)
        rect.set(sx - tw / 2f - 8 * d, sy - 22 * d, sx + tw / 2f + 8 * d, sy + 6 * d)
        fillP.color = Color.WHITE
        c.drawRoundRect(rect, 10 * d, 10 * d, fillP)
        leftP.setShadowLayer(0f, 0f, 0f, Color.BLACK)
        leftP.color = Color.BLACK
        c.drawText(s, sx - tw / 2f, sy - 2 * d, leftP)
        leftP.color = Color.WHITE
        leftP.setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }

    private fun hatDraw(c: Canvas, x: Float, y: Float, z: Float, id: String) {
        if (id.isEmpty()) return
        val col = when (id) {
            "hat_top", "hat_pirate" -> Color.rgb(33, 33, 33)
            "hat_crown" -> Color.rgb(255, 193, 7)
            "hat_party" -> Color.rgb(233, 30, 99)
            "hat_santa" -> Color.rgb(229, 57, 53)
            "hat_cowboy" -> Color.rgb(141, 110, 99)
            "hat_wizard" -> Color.rgb(106, 27, 154)
            "hat_chef" -> Color.WHITE
            "hat_halo" -> Color.rgb(255, 235, 59)
            "hat_viking" -> Color.rgb(158, 158, 158)
            else -> Color.rgb(33, 150, 243)
        }
        val h = if (id == "hat_top" || id == "hat_wizard" || id == "hat_chef") 0.38f else 0.2f
        vb(c, x, y + 1.33f, z, 0.21f, h, 0.21f, col)
    }

    /** A boxy ("obby style") goose. f = +1 faces away from the camera, -1 faces the camera. */
    private fun drawGoose(c: Canvas, x: Float, y: Float, z: Float, f: Float, body: Int, beak: Int, hat: String, swing: Float) {
        val wing = tone(body, 0.88f, 0f)
        vb(c, x - 0.14f, y, z + swing * f, 0.06f, 0.32f, 0.07f, beak)
        vb(c, x + 0.14f, y, z - swing * f, 0.06f, 0.32f, 0.07f, beak)
        val n = gp.size
        for (k in 0 until n) {
            val p = gp[if (f > 0f) k else n - 1 - k]
            val col = when (p[6].toInt()) { 0 -> body; 1 -> beak; else -> wing }
            vb(c, x + p[0], y + p[1], z + p[2] * f, p[3], p[4], p[5], col)
            if (p[1] == 1.05f) hatDraw(c, x, y, z + p[2] * f, hat) // the hat goes on right after the head
        }
    }

    private fun drawFox(c: Canvas, x: Float, y: Float, z: Float, s: Float, body: Int, eye: Int, flashing: Boolean, crown: Boolean) {
        val bc = if (flashing) Color.WHITE else body
        val white = Color.rgb(250, 250, 250)
        val dark = Color.rgb(60, 40, 30)
        vb(c, x, y + 0.45f * s, z + 0.9f * s, 0.10f * s, 0.12f * s, 0.10f * s, white)
        vb(c, x, y + 0.45f * s, z + 0.65f * s, 0.10f * s, 0.12f * s, 0.15f * s, bc)
        vb(c, x, y + 0.25f * s, z, 0.30f * s, 0.45f * s, 0.50f * s, bc)
        for (sx in floatArrayOf(-0.2f, 0.2f)) for (sz in floatArrayOf(-0.35f, 0.35f)) {
            vb(c, x + sx * s, y, z + sz * s, 0.07f * s, 0.25f * s, 0.07f * s, dark)
        }
        vb(c, x, y + 0.5f * s, z - 0.55f * s, 0.22f * s, 0.30f * s, 0.22f * s, bc)
        vb(c, x, y + 0.5f * s, z - 0.80f * s, 0.10f * s, 0.12f * s, 0.10f * s, white)
        vb(c, x - 0.14f * s, y + 0.80f * s, z - 0.5f * s, 0.06f * s, 0.16f * s, 0.05f * s, bc)
        vb(c, x + 0.14f * s, y + 0.80f * s, z - 0.5f * s, 0.06f * s, 0.16f * s, 0.05f * s, bc)
        vb(c, x - 0.10f * s, y + 0.62f * s, z - 0.78f * s, 0.04f * s, 0.05f * s, 0.02f * s, eye)
        vb(c, x + 0.10f * s, y + 0.62f * s, z - 0.78f * s, 0.04f * s, 0.05f * s, 0.02f * s, eye)
        if (crown) vb(c, x, y + 0.82f * s, z - 0.55f * s, 0.20f * s, 0.14f * s, 0.20f * s, Color.rgb(255, 193, 7))
    }

    private fun drawSky(c: Canvas, w: Float, h: Float, horizonY: Float) {
        val ph = max(0f, pz) / 400f
        val i0 = floor(ph).toInt() % 3
        val i1 = (i0 + 1) % 3
        val f = ph - floor(ph)
        val top = mixC(SKY_TOP[i0], SKY_TOP[i1], f)
        val hor = mixC(SKY_HOR[i0], SKY_HOR[i1], f)
        fogC = hor
        skyP.shader = LinearGradient(0f, 0f, 0f, horizonY, top, hor, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, horizonY, skyP)
        voidP.shader = LinearGradient(0f, horizonY, 0f, h, hor, mixC(hor, Color.BLACK, 0.6f), Shader.TileMode.CLAMP)
        c.drawRect(0f, horizonY, w, h, voidP)
        // sun / moon
        uiP.style = Paint.Style.FILL
        uiP.color = if (i0 == 2 || (i0 == 1 && f > 0.6f)) Color.argb(230, 240, 240, 255) else Color.argb(230, 255, 236, 150)
        c.drawCircle(w * 0.75f, horizonY - 70 * d, 34 * d, uiP)
    }

    override fun onDraw(c: Canvas) {
        if (!ready) return
        val w = width.toFloat()
        val h = height.toFloat()
        val horizonY = cy0 - focal * tan(PITCH)
        drawSky(c, w, h, horizonY)

        items.clear()
        for (b in blocks) if (b.z1 > camZ + NEAR && b.z0 < camZ + FOG) items.add(DI(b.z1, 0, b))
        for (p in picks) if (!p.taken && p.z > camZ + 0.5f && p.z < camZ + FOG) items.add(DI(p.z, 1, p))
        for (e in enemies) if (!e.dead && e.z > camZ + 0.5f && e.z < camZ + FOG) items.add(DI(e.z + 0.4f, 2, e))
        for (n in npcs) if (n.z > camZ + 0.5f && n.z < camZ + FOG) items.add(DI(n.z, 3, n))
        for (p in projs) if (p.z > camZ + 0.5f) items.add(DI(p.z, 4, p))
        items.add(DI(pz, 5, null))
        items.sortByDescending { it.z }

        for (di in items) {
            when (di.type) {
                0 -> { val b = di.ref as Block; box(c, b.x0, b.x1, b.y0, b.y1, b.z0, b.z1, b.color) }
                1 -> drawPick(c, di.ref as Pick)
                2 -> {
                    val e = di.ref as Enemy
                    if (e.boss) drawFox(c, e.x, e.y, e.z, 2.8f, Color.rgb(183, 28, 28), Color.rgb(255, 235, 59), e.hit > 0f, true)
                    else drawFox(c, e.x, e.y, e.z, 1f, Color.rgb(239, 108, 0), Color.BLACK, e.hit > 0f, false)
                }
                3 -> {
                    val n = di.ref as Npc
                    drawGoose(c, n.x, n.y, n.z, -1f, Color.rgb(255, 235, 130), Color.rgb(255, 140, 0), "hat_cowboy", 0f)
                    if (!n.used && abs(n.z - pz) < 14f) bubble(c, n.x, n.y + 2.1f, n.z, npcLine(n.line))
                }
                4 -> {
                    val p = di.ref as Proj
                    when (p.kind) {
                        0 -> disc(c, p.x, p.y, p.z, 0.13f, Color.rgb(255, 235, 59), 1f)
                        1 -> disc(c, p.x, p.y, p.z, 0.09f, Color.rgb(255, 183, 77), 1f)
                        2 -> disc(c, p.x, p.y, p.z, 0.25f, Color.rgb(120, 120, 120), 1f)
                        else -> disc(c, p.x, p.y, p.z, 0.32f, Color.rgb(255, 82, 82), 1f)
                    }
                }
                else -> {
                    if (!(invuln > 0f && (t * 12f).toInt() % 2 == 0)) {
                        val sw = if (onGround) sin(phase) * 0.15f else 0.12f
                        drawGoose(c, px, py, pz, 1f, Cosmetics.body, Cosmetics.beak, Cosmetics.hat, sw)
                    }
                }
            }
        }

        if (shockT > 0f) { // the honk shockwave ring
            val f = 1f - shockT / 0.6f
            put(0, px, py, pz)
            if (pd[0] > NEAR) {
                val sx = cx0 + focal * pr[0] / pd[0]
                val sy = cy0 - focal * pu[0] / pd[0]
                val rad = focal * (f * 14f) / pd[0]
                uiP.style = Paint.Style.STROKE
                uiP.strokeWidth = 6 * d
                uiP.color = Color.argb((200 * (1f - f)).toInt().coerceIn(0, 255), 255, 255, 255)
                rect.set(sx - rad, sy - rad * 0.35f, sx + rad, sy + rad * 0.35f)
                c.drawOval(rect, uiP)
            }
        }
        drawHud(c, w, h)
    }

    private fun drawPick(c: Canvas, p: Pick) {
        when (p.kind) {
            COIN -> disc(c, p.x, p.y, p.z, 0.32f, Color.rgb(255, 214, 0), max(0.25f, abs(cos(t * 4f + p.z))))
            HEART -> emoji(c, p.x, p.y - 0.2f, p.z, "❤", 0.9f)
            else -> {
                val col = when (p.kind) {
                    GUN_BLASTER -> Color.rgb(66, 165, 245)
                    GUN_SHOTGUN -> Color.rgb(255, 167, 38)
                    else -> Color.rgb(239, 83, 80)
                }
                vb(c, p.x, p.y - 0.4f, p.z, 0.35f, 0.7f, 0.35f, col)
                emoji(c, p.x, p.y + 0.5f, p.z, "🔫", 0.8f)
            }
        }
    }

    // =====================================================================
    // HUD and buttons
    // =====================================================================

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        val top = (if (versus != null) 104 else 80) * d
        leftP.textSize = 22 * d
        for (i in 0 until 5) {
            leftP.color = if (i < hp) Color.rgb(255, 82, 82) else Color.argb(120, 255, 255, 255)
            c.drawText("♥", 16 * d + i * 26 * d, top, leftP)
        }
        leftP.color = Color.WHITE
        leftP.textSize = 16 * d
        if (weapon != 0) c.drawText("🔫 ${weaponName(weapon)}  $ammo", 16 * d, top + 26 * d, leftP)

        val bs = boss
        if (bs != null && fighting) { // boss health bar
            val bw = w * 0.6f
            val bl = (w - bw) / 2f
            val by0 = h * 0.15f
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(160, 0, 0, 0)
            c.drawRect(bl - 4 * d, by0 - 4 * d, bl + bw + 4 * d, by0 + 14 * d, uiP)
            uiP.color = Color.rgb(229, 57, 53)
            c.drawRect(bl, by0, bl + bw * (max(0, bs.hp).toFloat() / bs.maxHp), by0 + 10 * d, uiP)
        }

        if (now < flashUntil) {
            textP.textSize = 24 * d
            c.drawText(flash, w / 2f, h * 0.24f, textP)
        }
        if (t < 6f) {
            textP.textSize = 13 * d
            c.drawText(tr("Left thumb: steer   Buttons: jump, shoot, honk"), w / 2f, h * 0.32f, textP)
        }

        for (i in 0 until 3) {
            val dim = (i == 1 && weapon == 0) || (i == 2 && honkCd > 0f)
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(if (dim) 45 else if (i == 1 && firePid != -1) 150 else 95, 255, 255, 255)
            c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 3 * d
            uiP.color = Color.argb(160, 255, 255, 255)
            c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
            textP.textSize = btnR(i) * 0.9f
            c.drawText(if (i == 0) "⬆" else if (i == 1) "🔫" else "📢", btnX(i), btnY(i) + btnR(i) * 0.3f, textP)
        }
        if (honkCd > 0f) {
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(120, 0, 0, 0)
            rect.set(btnX(2) - btnR(2), btnY(2) - btnR(2), btnX(2) + btnR(2), btnY(2) + btnR(2))
            c.drawArc(rect, -90f, 360f * honkCd / 8f, true, uiP)
        }
    }
}
