package com.example.goosedroid

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Playlists = name -> list of MediaStore song ids, stored as JSON in SharedPreferences. */
object Playlists {
    fun get(ctx: Context): LinkedHashMap<String, MutableList<Long>> {
        val out = LinkedHashMap<String, MutableList<Long>>()
        try {
            val j = JSONObject(Store.prefs(ctx).getString("playlists", "{}") ?: "{}")
            for (k in j.keys()) {
                val a = j.getJSONArray(k)
                val l = ArrayList<Long>()
                for (i in 0 until a.length()) l.add(a.getLong(i))
                out[k] = l
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(ctx: Context, m: Map<String, List<Long>>) {
        val j = JSONObject()
        for ((k, v) in m) j.put(k, JSONArray(v))
        Store.prefs(ctx).edit().putString("playlists", j.toString()).apply()
    }

    fun create(ctx: Context, name: String) {
        val m = get(ctx)
        if (!m.containsKey(name)) { m[name] = ArrayList(); save(ctx, m) }
    }

    fun delete(ctx: Context, name: String) {
        val m = get(ctx)
        m.remove(name)
        save(ctx, m)
    }

    fun add(ctx: Context, name: String, id: Long) {
        val m = get(ctx)
        val l = m.getOrPut(name) { ArrayList() }
        if (!l.contains(id)) l.add(id)
        save(ctx, m)
    }

    fun remove(ctx: Context, name: String, id: Long) {
        val m = get(ctx)
        m[name]?.remove(id)
        save(ctx, m)
    }
}
