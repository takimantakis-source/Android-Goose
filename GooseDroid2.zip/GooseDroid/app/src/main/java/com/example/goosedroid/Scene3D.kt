package com.example.goosedroid

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

/** A small software 3D engine: boxes and billboards, drawn back to front with perspective and fog. */
class Scene3D {
    var camX = 0f
    var camY = 0f
    var camZ = 0f
    var pitch = 0.5f
    var focal = 1f
    var cx0 = 0f
    var cy0 = 0f
    var fogC = Color.WHITE
    var fogDist = 90f

    private val near = 0.3f
    private var cosP = 1f
    private var sinP = 0f
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(70, 0, 0, 0); strokeWidth = 1.5f
    }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val rect = RectF()
    private val pr = FloatArray(8)
    private val pu = FloatArray(8)
    private val pd = FloatArray(8)
    private val qr = FloatArray(16)
    private val qu = FloatArray(16)
    private val qd = FloatArray(16)

    // goose parts: dx, y0, dz, hw, h, hd, color (0 body, 1 beak, 2 wing); the last two are the legs
    private val parts = arrayOf(
        floatArrayOf(0f, 1.12f, 0.62f, 0.08f, 0.10f, 0.16f, 1f),
        floatArrayOf(0f, 1.05f, 0.30f, 0.17f, 0.30f, 0.17f, 0f),
        floatArrayOf(0f, 0.70f, 0.20f, 0.10f, 0.40f, 0.10f, 0f),
        floatArrayOf(0f, 0.30f, 0f, 0.30f, 0.45f, 0.42f, 0f),
        floatArrayOf(-0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0f, 0.45f, -0.50f, 0.10f, 0.18f, 0.12f, 0f),
        floatArrayOf(-0.14f, 0f, 0f, 0.06f, 0.32f, 0.07f, 1f),
        floatArrayOf(0.14f, 0f, 0f, 0.06f, 0.32f, 0.07f, 1f)
    )
    private val gx = FloatArray(9)
    private val gz = FloatArray(9)
    private val ghx = FloatArray(9)
    private val ghz = FloatArray(9)
    private val order = IntArray(9)

    fun begin(w: Int, h: Int) {
        focal = w * 0.9f
        cx0 = w / 2f
        cy0 = h * 0.5f
        cosP = cos(pitch)
        sinP = sin(pitch)
    }

    fun horizonY() = cy0 - focal * tan(pitch)

    fun mix(a: Int, b: Int, f: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
    )

    private fun tone(color: Int, k: Float, fog: Float): Int =
        mix(Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt()), fogC, fog)

    private fun put(i: Int, x: Float, y: Float, z: Float) {
        val rx = x - camX
        val ry = y - camY
        val rz = z - camZ
        pr[i] = rx
        pu[i] = ry * cosP + rz * sinP
        pd[i] = -ry * sinP + rz * cosP
    }

    private fun poly(c: Canvas, color: Int, n: Int) {
        var m = 0
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            val di = pd[i] - near
            val dj = pd[j] - near
            if (di >= 0f) { qr[m] = pr[i]; qu[m] = pu[i]; qd[m] = pd[i]; m++ }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                qr[m] = pr[i] + (pr[j] - pr[i]) * f
                qu[m] = pu[i] + (pu[j] - pu[i]) * f
                qd[m] = near
                m++
            }
        }
        if (m < 3) return
        path.reset()
        for (k in 0 until m) {
            val sx = cx0 + focal * qr[k] / qd[k]
            val sy = cy0 - focal * qu[k] / qd[k]
            if (k == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        path.close()
        fillP.color = color
        c.drawPath(path, fillP)
        c.drawPath(path, lineP)
    }

    fun box(
        c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, z0: Float, z1: Float, color: Int,
        front: Boolean = true, left: Boolean = true, right: Boolean = true, top: Boolean = true
    ) {
        if (z1 < camZ + near) return
        val zn = max(z0, camZ)
        val fog = ((zn + min(z1 - zn, 12f) / 2f - camZ) / fogDist).coerceIn(0f, 0.9f)
        if (front && camZ < z0) {
            put(0, x0, y0, z0); put(1, x1, y0, z0); put(2, x1, y1, z0); put(3, x0, y1, z0)
            poly(c, tone(color, 0.78f, fog), 4)
        }
        if (left && camX < x0) {
            put(0, x0, y0, z0); put(1, x0, y0, z1); put(2, x0, y1, z1); put(3, x0, y1, z0)
            poly(c, tone(color, 0.62f, fog), 4)
        } else if (right && camX > x1) {
            put(0, x1, y0, z0); put(1, x1, y0, z1); put(2, x1, y1, z1); put(3, x1, y1, z0)
            poly(c, tone(color, 0.62f, fog), 4)
        }
        if (top && camY > y1) {
            put(0, x0, y1, z0); put(1, x1, y1, z0); put(2, x1, y1, z1); put(3, x0, y1, z1)
            poly(c, tone(color, 1f, fog), 4)
        }
    }

    fun vb(c: Canvas, cx: Float, y0: Float, cz: Float, hw: Float, h: Float, hd: Float, color: Int) =
        box(c, cx - hw, cx + hw, y0, y0 + h, cz - hd, cz + hd, color)

    /** A flat rectangle on the plane z (windows on a wall). */
    fun quadFront(c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, z: Float, color: Int) {
        if (z < camZ + near) return
        val fog = ((z - camZ) / fogDist).coerceIn(0f, 0.9f)
        put(0, x0, y0, z); put(1, x1, y0, z); put(2, x1, y1, z); put(3, x0, y1, z)
        poly(c, tone(color, 1f, fog), 4)
    }

    fun emoji(c: Canvas, x: Float, y: Float, z: Float, s: String, size: Float) {
        put(0, x, y, z)
        if (pd[0] < near) return
        textP.textSize = focal * size / pd[0]
        c.drawText(s, cx0 + focal * pr[0] / pd[0], cy0 - focal * pu[0] / pd[0], textP)
    }

    private fun hatColor(id: String): Int = when (id) {
        "hat_top", "hat_pirate" -> Color.rgb(33, 33, 33)
        "hat_crown" -> Color.rgb(255, 193, 7)
        "hat_party" -> Color.rgb(233, 30, 99)
        "hat_santa" -> Color.rgb(229, 57, 53)
        "hat_cowboy" -> Color.rgb(141, 110, 99)
        "hat_wizard" -> Color.rgb(106, 27, 154)
        "hat_chef" -> Color.WHITE
        "hat_halo" -> Color.rgb(255, 235, 59)
        "hat_viking" -> Color.rgb(158, 158, 158)
        else -> Color.rgb(33, 150, 243)
    }

    /** A boxy goose. dir: 0 faces +z (away from the camera), 1 faces +x, 2 faces -z, 3 faces -x. */
    fun goose(c: Canvas, x: Float, y: Float, z: Float, dir: Int, body: Int, beak: Int, hat: String, swing: Float) {
        val wing = tone(body, 0.88f, 0f)
        parts[7][2] = swing
        parts[8][2] = -swing
        for (k in 0 until 9) {
            val p = parts[k]
            val dx = p[0]
            val dz = p[2]
            when (dir) {
                0 -> { gx[k] = x + dx; gz[k] = z + dz; ghx[k] = p[3]; ghz[k] = p[5] }
                1 -> { gx[k] = x + dz; gz[k] = z + dx; ghx[k] = p[5]; ghz[k] = p[3] }
                2 -> { gx[k] = x + dx; gz[k] = z - dz; ghx[k] = p[3]; ghz[k] = p[5] }
                else -> { gx[k] = x - dz; gz[k] = z + dx; ghx[k] = p[5]; ghz[k] = p[3] }
            }
            order[k] = k
        }
        // far parts first (larger z), simple insertion sort
        for (i in 1 until 9) {
            val v = order[i]
            var j = i - 1
            while (j >= 0 && gz[order[j]] < gz[v]) { order[j + 1] = order[j]; j-- }
            order[j + 1] = v
        }
        for (idx in 0 until 9) {
            val k = order[idx]
            val p = parts[k]
            val col = when (p[6].toInt()) { 0 -> body; 1 -> beak; else -> wing }
            vb(c, gx[k], y + p[1], gz[k], ghx[k], p[4], ghz[k], col)
            if (k == 1 && hat.isNotEmpty()) {
                val h = if (hat == "hat_top" || hat == "hat_wizard" || hat == "hat_chef") 0.38f else 0.2f
                vb(c, gx[k], y + 1.33f, gz[k], 0.21f, h, 0.21f, hatColor(hat))
            }
        }
    }
}
