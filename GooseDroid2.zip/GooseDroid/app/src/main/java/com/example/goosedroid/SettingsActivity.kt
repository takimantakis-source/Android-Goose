package com.example.goosedroid

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.graphics.Typeface
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** App settings: choose the language. */
class SettingsActivity : Activity() {
    private lateinit var listView: ListView
    private lateinit var search: EditText
    private var shown: List<String> = emptyList()

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
        }
        root.addView(TextView(this).apply { text = tr("⚙ Settings"); textSize = 24f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = tr("Language"); textSize = 18f; setPadding(0, dp(10f), 0, dp(4f)) })
        root.addView(TextView(this).apply {
            text = tr("English and German work offline. Other languages are downloaded once (about 30 MB each) and then work offline.")
            textSize = 13f
        })
        search = EditText(this).apply {
            hint = tr("Search language...")
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { fill() }
            })
        }
        root.addView(search)
        listView = ListView(this)
        root.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        listView.setOnItemClickListener { _, _, pos, _ -> if (pos < shown.size) choose(shown[pos]) }
        fill()
    }

    private fun fill() {
        val q = search.text.toString().trim().lowercase()
        val sorted = Lang.languages.sortedWith(compareBy({ it != "en" && it != "de" }, { Lang.englishName(it) }))
        shown = sorted.filter {
            q.isEmpty() || Lang.nativeName(it).lowercase().contains(q) || Lang.englishName(it).lowercase().contains(q)
        }
        val labels = shown.map {
            val mark = when {
                it == Lang.code -> "  ✓"
                !Lang.has(it) -> "  ⬇"
                else -> ""
            }
            "${Lang.nativeName(it)}  -  ${Lang.englishName(it)}$mark"
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun choose(c: String) {
        if (Lang.has(c)) { Lang.set(c); finish(); return }
        AlertDialog.Builder(this)
            .setTitle(trf("Download %s?", Lang.englishName(c)))
            .setMessage(tr("Needs internet once, about 30 MB. After that it works offline."))
            .setPositiveButton(tr("Download")) { _, _ -> startDownload(c) }
            .setNegativeButton(tr("Cancel"), null)
            .show()
    }

    private fun startDownload(c: String) {
        val tv = TextView(this).apply { text = tr("Downloading..."); setPadding(dp(24f), dp(16f), dp(24f), dp(16f)) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(trf("Translating to %s", Lang.englishName(c)))
            .setView(tv)
            .setCancelable(false)
            .show()
        Lang.download(c, { i, n -> tv.text = trf("Translating... %d/%d", i, n) }) { ok ->
            try { dlg.dismiss() } catch (_: Exception) {}
            if (ok) { Lang.set(c); finish() }
            else Toast.makeText(this, tr("Download failed. Check your internet connection."), Toast.LENGTH_LONG).show()
        }
    }
}
