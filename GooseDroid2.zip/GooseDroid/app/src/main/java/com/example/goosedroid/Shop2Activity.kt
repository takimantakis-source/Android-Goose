package com.example.goosedroid

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Swipe right on the main menu to get here. Pets and honk sounds. */
class Shop2Activity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var swipe: android.view.GestureDetector
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeMode.apply(this)
        super.onCreate(savedInstanceState)
        swipe = makeSwipe(this, { finish() }, null)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun tv(t: String, size: Float) = TextView(this).apply {
        text = t; textSize = size
        setPadding(0, pad / 2, 0, pad / 2)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun render() {
        root.removeAllViews()
        root.addView(tv(tr("🧰 Goose Extras"), 26f))
        root.addView(tv(trf("🪙 %d coins  -  earn more in the minigames!", Store.coins(this)), 16f))

        root.addView(tv(tr("Pets"), 20f))
        root.addView(tv(tr("Pets follow your goose over the screen (up to 3)."), 13f))
        for (p in Extras.pets) root.addView(petRow(p))

        root.addView(tv(tr("Honk sounds"), 20f))
        for (s in Extras.sounds) root.addView(soundRow(s))
    }

    private fun petRow(p: Extras.Pet): LinearLayout {
        val owned = Extras.owned(this, p.id)
        val eq = Extras.equippedPets(this).contains(p.id)
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val g = GooseView(this, 0.5f).apply { fixedLook = true; lookSkin = p.skin; lookHat = p.hat }
        r.addView(g, LinearLayout.LayoutParams(g.sizeW, g.sizeH))
        r.addView(TextView(this).apply {
            text = tr(p.name) + if (!owned) "\n🪙${p.price}" else "\n" + tr("✓ Owned")
            textSize = 16f
            setPadding(pad / 2, 0, pad / 2, 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Button(this).apply {
            text = when {
                !owned -> tr("Buy")
                eq -> tr("Unequip")
                else -> tr("Equip")
            }
            setOnClickListener {
                val list = Extras.equippedPets(this@Shop2Activity).toMutableList()
                if (!owned) {
                    if (!Extras.buy(this@Shop2Activity, p.id, p.price)) { toast(tr("Not enough coins")); return@setOnClickListener }
                    if (list.size < 3) list.add(p.id)
                } else if (eq) {
                    list.remove(p.id)
                } else {
                    if (list.size >= 3) { toast(tr("You can have up to 3 pets.")); return@setOnClickListener }
                    list.add(p.id)
                }
                Extras.setPets(this@Shop2Activity, list)
                GooseService.instance?.refreshPets()
                render()
            }
        })
        return r
    }

    private fun soundRow(s: Extras.Snd): LinearLayout {
        val owned = Extras.owned(this, s.id)
        val use = Extras.honkPack(this) == s.id
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        r.addView(TextView(this).apply {
            text = tr(s.name) + if (!owned) "\n🪙${s.price}" else "\n" + tr("✓ Owned")
            textSize = 16f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Button(this).apply { text = "▶"; setOnClickListener { Sound.honkPack(s.id) } })
        r.addView(Button(this).apply {
            text = when {
                !owned -> tr("Buy")
                use -> tr("In use")
                else -> tr("Use")
            }
            isEnabled = !use
            setOnClickListener {
                if (!owned && !Extras.buy(this@Shop2Activity, s.id, s.price)) {
                    toast(tr("Not enough coins")); return@setOnClickListener
                }
                Extras.setHonk(this@Shop2Activity, s.id)
                render()
            }
        })
        return r
    }
}
