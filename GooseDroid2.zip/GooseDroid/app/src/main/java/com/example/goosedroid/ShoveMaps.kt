package com.example.goosedroid

import android.graphics.Color

/**
 * One tower. hx/hz = half size of the roof, height = how far you fall (and have to climb),
 * friction = how quickly geese stop (low = ice), wind = sideways push, shrink = roof gets smaller.
 */
class ShoveMap(
    val name: String,
    val hx: Float, val hz: Float, val height: Float,
    val bots: Int, val friction: Float, val wind: Float, val shrink: Boolean,
    val roof: Int, val wall: Int, val skyTop: Int, val skyHor: Int,
    val obstacles: List<FloatArray>, // x0, z0, x1, z1, height
    val bumpers: List<FloatArray>,   // x, z, radius
    val voids: List<FloatArray>      // x0, z0, x1, z1 (holes in the roof)
)

object ShoveMaps {
    private fun c(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)
    private fun box(x0: Float, z0: Float, x1: Float, z1: Float, h: Float) = floatArrayOf(x0, z0, x1, z1, h)

    val ALL = listOf(
        ShoveMap(
            "Office Roof", 7f, 7f, 30f, 4, 6f, 0f, false,
            c(120, 125, 135), c(96, 125, 139), c(110, 180, 240), c(210, 235, 255),
            listOf(box(-4f, -3f, -2.5f, -1.5f, 1f), box(2.5f, 2f, 4f, 3.5f, 1f)), emptyList(), emptyList()
        ),
        ShoveMap(
            "Skyscraper", 5.5f, 5.5f, 55f, 4, 6f, 0f, false,
            c(70, 80, 100), c(38, 50, 70), c(30, 60, 120), c(150, 190, 240),
            listOf(box(-1f, -1f, 1f, 1f, 0.8f)), emptyList(), emptyList()
        ),
        ShoveMap(
            "Helipad", 8f, 8f, 34f, 5, 5.5f, 0f, false,
            c(90, 90, 95), c(110, 110, 120), c(100, 170, 235), c(220, 240, 255),
            listOf(
                box(-7f, -7f, -6f, -6f, 1f), box(6f, -7f, 7f, -6f, 1f),
                box(-7f, 6f, -6f, 7f, 1f), box(6f, 6f, 7f, 7f, 1f)
            ), emptyList(), emptyList()
        ),
        ShoveMap(
            "Water Tower", 7f, 7f, 36f, 5, 6f, 0f, false,
            c(140, 110, 90), c(120, 90, 70), c(255, 190, 130), c(255, 230, 190),
            listOf(box(-1.3f, -1.3f, 1.3f, 1.3f, 3.5f), box(-6f, 2f, -3f, 2.8f, 0.7f), box(3f, -3f, 6f, -2.2f, 0.7f)),
            emptyList(), emptyList()
        ),
        ShoveMap(
            "Icy Penthouse", 7f, 7f, 40f, 5, 1.3f, 0f, false,
            c(175, 225, 245), c(120, 160, 190), c(150, 200, 240), c(235, 248, 255),
            listOf(box(-3f, -4f, -1.8f, -2.8f, 0.9f), box(2f, 3f, 3.4f, 4.4f, 0.9f)), emptyList(), emptyList()
        ),
        ShoveMap(
            "Construction Site", 8f, 8f, 48f, 5, 5f, 0f, false,
            c(160, 140, 110), c(130, 115, 95), c(240, 170, 100), c(255, 225, 170),
            listOf(box(-1f, -0.5f, 1f, 0.5f, 1f)), emptyList(),
            listOf(
                floatArrayOf(-8f, -8f, -4.5f, -4.5f), floatArrayOf(4.5f, -8f, 8f, -4.5f),
                floatArrayOf(-8f, 4.5f, -4.5f, 8f), floatArrayOf(4.5f, 4.5f, 8f, 8f)
            )
        ),
        ShoveMap(
            "Solar Farm", 8f, 8f, 32f, 5, 6f, 0f, false,
            c(70, 90, 70), c(90, 105, 90), c(120, 190, 250), c(220, 245, 255),
            listOf(
                box(-6f, -4.3f, -1.5f, -3.7f, 0.6f), box(1.5f, -4.3f, 6f, -3.7f, 0.6f),
                box(-3.5f, -0.3f, 3.5f, 0.3f, 0.6f),
                box(-6f, 3.7f, -1.5f, 4.3f, 0.6f), box(1.5f, 3.7f, 6f, 4.3f, 0.6f)
            ), emptyList(), emptyList()
        ),
        ShoveMap(
            "Party Roof", 7.5f, 7.5f, 38f, 5, 6f, 0f, false,
            c(156, 39, 176), c(106, 27, 154), c(60, 20, 100), c(240, 120, 200),
            emptyList(),
            listOf(
                floatArrayOf(3.5f, 3.5f, 0.9f), floatArrayOf(-3.5f, 3.5f, 0.9f),
                floatArrayOf(3.5f, -3.5f, 0.9f), floatArrayOf(-3.5f, -3.5f, 0.9f), floatArrayOf(0f, 0f, 1f)
            ), emptyList()
        ),
        ShoveMap(
            "Windy Tower", 7f, 7f, 50f, 5, 5f, 6f, false,
            c(170, 175, 185), c(90, 100, 120), c(80, 90, 110), c(180, 190, 205),
            listOf(box(-5f, -5f, -4f, -4f, 1.2f), box(4f, 4f, 5f, 5f, 1.2f)), emptyList(), emptyList()
        ),
        ShoveMap(
            "Mega Tower", 9f, 9f, 60f, 7, 4.5f, 0f, true,
            c(60, 60, 70), c(30, 30, 40), c(15, 20, 50), c(120, 100, 170),
            listOf(
                box(-3f, -3f, -2f, -2f, 1f), box(2f, 2f, 3f, 3f, 1f),
                box(-3f, 2f, -2f, 3f, 1f), box(2f, -3f, 3f, -2f, 1f)
            ), emptyList(), emptyList()
        )
    )
}
