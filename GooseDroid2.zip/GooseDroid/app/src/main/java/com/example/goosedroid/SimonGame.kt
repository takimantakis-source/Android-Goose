package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.widget.FrameLayout
import kotlin.random.Random

/** Game 3: the goose honks a pattern, you repeat it. One more honk every round. */
class SimonGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "simon", versus, onExit) {
    override val coinRate = 3f
    override fun currentScore() = (seq.size - 1).coerceAtLeast(0)
    private val goose = GooseView(ctx)
    private val colors = intArrayOf(
        Color.rgb(229, 57, 53), Color.rgb(67, 160, 71),
        Color.rgb(30, 136, 229), Color.rgb(253, 216, 53)
    )
    private val freqs = doubleArrayOf(262.0, 330.0, 392.0, 523.0)
    private val rects = Array(4) { RectF() }
    private val pad = Paint(Paint.ANTI_ALIAS_FLAG)

    private val seq = ArrayList<Int>()
    private var input = 0
    private var lit = -1
    private var accepting = false

    init {
        addView(goose, FrameLayout.LayoutParams(goose.sizeW, goose.sizeH))
    }

    override fun reset() {
        seq.clear()
        lit = -1
        goose.x = (width - goose.sizeW) / 2f
        goose.y = 50 * d
        goose.invalidate()

        val top = 190 * d
        val gap = 12 * d
        val pw = (width - 3 * gap) / 2f
        val ph = (height - top - 16 * d - gap) / 2f
        for (i in 0 until 4) {
            val l = gap + (i % 2) * (pw + gap)
            val t = top + (i / 2) * (ph + gap)
            rects[i].set(l, t, l + pw, t + ph)
        }
        nextRound()
    }

    private fun nextRound() {
        seq.add(Random.nextInt(4))
        input = 0
        accepting = false
        hud.text = trf("Round %d - watch the goose", seq.size)
        val step = (700 - seq.size * 20L).coerceAtLeast(400L)
        seq.forEachIndexed { i, p ->
            uiHandler.postDelayed({ flash(p, step - 150) }, 900L + i * step)
        }
        uiHandler.postDelayed({
            accepting = true
            hud.text = trf("Round %d - your turn!", seq.size)
        }, 900L + seq.size * step)
    }

    private fun flash(p: Int, ms: Long) {
        lit = p
        invalidate()
        Sound.play(freqs[p], freqs[p] * 0.85, 350)
        goose.bubble = "HONK!"
        goose.invalidate()
        uiHandler.postDelayed({
            lit = -1
            goose.bubble = null
            invalidate()
            goose.invalidate()
        }, ms)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked != MotionEvent.ACTION_DOWN || !accepting) return true
        val p = rects.indexOfFirst { it.contains(e.x, e.y) }
        if (p < 0) return true
        flash(p, 300)
        if (p == seq[input]) {
            input++
            if (input == seq.size) {
                accepting = false
                hud.text = tr("Nice! Get ready...")
                uiHandler.postDelayed({ nextRound() }, 1000)
            }
        } else {
            accepting = false
            hud.text = tr("Wrong pad!")
            val score = seq.size - 1
            uiHandler.postDelayed({ gameOver(trf("You reached round %d", seq.size), score) }, 600)
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        for (i in 0 until 4) {
            val col = colors[i]
            pad.color = if (i == lit) col
            else Color.argb(110, Color.red(col), Color.green(col), Color.blue(col))
            c.drawRoundRect(rects[i], 24 * d, 24 * d, pad)
        }
    }
}
