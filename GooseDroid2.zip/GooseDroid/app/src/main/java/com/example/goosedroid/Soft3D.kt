package com.example.goosedroid

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** A tiny software 3D engine for the canvas: boxes with perspective, a free orbit camera, fog, near-plane clipping. */
class Soft3D {
    var camX = 0f
    var camY = 0f
    var camZ = 0f
    var yaw = 0f
    var pitch = 0.5f
    var fogC = Color.WHITE
    var fogDist = 120f
    var focal = 1f
    var cx0 = 0f
    var cy0 = 0f

    private var sinY = 0f
    private var cosY = 1f
    private var sinP = 0f
    private var cosP = 1f

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(70, 0, 0, 0); strokeWidth = 1.5f
    }
    val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()
    private val rect = RectF()
    private val pr = FloatArray(8)
    private val pu = FloatArray(8)
    private val pd = FloatArray(8)
    private val qr = FloatArray(16)
    private val qu = FloatArray(16)
    private val qd = FloatArray(16)
    private val near = 0.3f

    /** Call once per frame after setting camX/Y/Z, yaw and pitch. */
    fun begin(w: Int, h: Int) {
        focal = w * 0.9f
        cx0 = w / 2f
        cy0 = h * 0.5f
        sinY = sin(yaw); cosY = cos(yaw); sinP = sin(pitch); cosP = cos(pitch)
    }

    fun horizonY() = cy0 - focal * tan(pitch)

    fun mixC(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
    )

    fun tone(color: Int, k: Float, fog: Float): Int = mixC(
        Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt()),
        fogC, fog
    )

    /** World point -> camera space slot i (right, up, depth). */
    private fun put(i: Int, x: Float, y: Float, z: Float) {
        val rx = x - camX
        val ry = y - camY
        val rz = z - camZ
        pr[i] = rx * cosY - rz * sinY
        pu[i] = rx * sinY * sinP + ry * cosP + rz * cosY * sinP
        pd[i] = rx * sinY * cosP - ry * sinP + rz * cosY * cosP
    }

    private fun poly(c: Canvas, color: Int, n: Int) {
        var m = 0
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            val di = pd[i] - near
            val dj = pd[j] - near
            if (di >= 0f) { qr[m] = pr[i]; qu[m] = pu[i]; qd[m] = pd[i]; m++ }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                qr[m] = pr[i] + (pr[j] - pr[i]) * f
                qu[m] = pu[i] + (pu[j] - pu[i]) * f
                qd[m] = near
                m++
            }
        }
        if (m < 3) return
        path.reset()
        for (k in 0 until m) {
            val sx = cx0 + focal * qr[k] / qd[k]
            val sy = cy0 - focal * qu[k] / qd[k]
            if (k == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        path.close()
        fillP.color = color
        c.drawPath(path, fillP)
        c.drawPath(path, lineP)
    }

    /** An axis-aligned box. Only the faces that face the camera are drawn. */
    fun box(c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, z0: Float, z1: Float, color: Int) {
        val nx = camX.coerceIn(x0, x1) - camX
        val ny = camY.coerceIn(y0, y1) - camY
        val nz = camZ.coerceIn(z0, z1) - camZ
        val fog = (sqrt(nx * nx + ny * ny + nz * nz) / fogDist).coerceIn(0f, 0.92f)
        if (camZ < z0) {
            put(0, x0, y0, z0); put(1, x1, y0, z0); put(2, x1, y1, z0); put(3, x0, y1, z0)
            poly(c, tone(color, 0.78f, fog), 4)
        }
        if (camZ > z1) {
            put(0, x0, y0, z1); put(1, x1, y0, z1); put(2, x1, y1, z1); put(3, x0, y1, z1)
            poly(c, tone(color, 0.70f, fog), 4)
        }
        if (camX < x0) {
            put(0, x0, y0, z0); put(1, x0, y0, z1); put(2, x0, y1, z1); put(3, x0, y1, z0)
            poly(c, tone(color, 0.62f, fog), 4)
        }
        if (camX > x1) {
            put(0, x1, y0, z0); put(1, x1, y0, z1); put(2, x1, y1, z1); put(3, x1, y1, z0)
            poly(c, tone(color, 0.66f, fog), 4)
        }
        if (camY > y1) {
            put(0, x0, y1, z0); put(1, x1, y1, z0); put(2, x1, y1, z1); put(3, x0, y1, z1)
            poly(c, tone(color, 1f, fog), 4)
        }
        if (camY < y0) {
            put(0, x0, y0, z0); put(1, x1, y0, z0); put(2, x1, y0, z1); put(3, x0, y0, z1)
            poly(c, tone(color, 0.5f, fog), 4)
        }
    }

    fun vb(c: Canvas, cx: Float, y0: Float, cz: Float, hw: Float, h: Float, hd: Float, color: Int) =
        box(c, cx - hw, cx + hw, y0, y0 + h, cz - hd, cz + hd, color)

    /** Where a world point lands on screen: out = (x, y, depth). False if it is behind the camera. */
    fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        put(0, x, y, z)
        if (pd[0] < near) return false
        out[0] = cx0 + focal * pr[0] / pd[0]
        out[1] = cy0 - focal * pu[0] / pd[0]
        out[2] = pd[0]
        return true
    }

    fun emoji(c: Canvas, x: Float, y: Float, z: Float, s: String, size: Float) {
        put(0, x, y, z)
        if (pd[0] < near) return
        textP.textSize = focal * size / pd[0]
        c.drawText(s, cx0 + focal * pr[0] / pd[0], cy0 - focal * pu[0] / pd[0], textP)
    }

    fun rectF(): RectF = rect
}
