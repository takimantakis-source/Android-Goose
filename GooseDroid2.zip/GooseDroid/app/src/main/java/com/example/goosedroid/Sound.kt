package com.example.goosedroid

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Tiny synth: a tone sweeping from startHz to endHz. wave: 0 saw, 1 square, 2 sine, 3 triangle. */
object Sound {
    fun play(startHz: Double, endHz: Double, ms: Int, wave: Int = 0, vib: Double = 0.0) {
        val sr = 22050
        val n = sr * ms / 1000
        val buf = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i / n.toDouble()
            val f = startHz + (endHz - startHz) * t + vib * sin(2 * PI * 6.0 * i / sr)
            ph += f / sr
            val x = ph % 1.0
            val s = when (wave) {
                1 -> if (x < 0.5) 0.6 else -0.6
                2 -> sin(2 * PI * x)
                3 -> 4 * abs(x - 0.5) - 1
                else -> 2 * x - 1
            }
            val env = if (t < 0.05) t / 0.05 else 1 - (t - 0.05) / 0.95
            buf[i] = (s * env * 0.5 * Short.MAX_VALUE).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(n * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(buf, 0, n)
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack) { t.release() }
            override fun onPeriodicNotification(t: AudioTrack) {}
        })
        track.notificationMarkerPosition = n
        track.play()
    }

    /** One of the honk sounds from the Extras shop. */
    fun honkPack(id: String) {
        when (id) {
            "honk_squeaky" -> play(900.0, 1500.0, 140, 1)
            "honk_trumpet" -> play(392.0, 392.0, 520, 1, 8.0)
            "honk_bass" -> play(110.0, 70.0, 480, 0)
            "honk_robot" -> play(240.0, 180.0, 300, 1, 40.0)
            "honk_alarm" -> play(700.0, 500.0, 400, 3, 60.0)
            else -> play(330.0, 210.0, 300)
        }
    }

    /** The honk you chose in the Extras shop. */
    fun honk() {
        val a = Store.app
        val id = if (a != null) Store.prefs(a).getString("honk_pack", "honk_classic") ?: "honk_classic" else "honk_classic"
        honkPack(id)
    }
}
