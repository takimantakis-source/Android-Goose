package com.example.goosedroid

import android.app.Activity
import android.view.GestureDetector
import android.view.MotionEvent
import kotlin.math.abs

/** Detects a quick horizontal swipe. Call detector.onTouchEvent(ev) from dispatchTouchEvent. */
fun makeSwipe(a: Activity, onLeft: (() -> Unit)?, onRight: (() -> Unit)?): GestureDetector {
    val d = a.resources.displayMetrics.density
    return GestureDetector(a, object : GestureDetector.SimpleOnGestureListener() {
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (e1 == null) return false
            val dx = e2.x - e1.x
            val dy = e2.y - e1.y
            if (abs(dx) > 120 * d && abs(dx) > abs(dy) * 1.6f && abs(velocityX) > 700f) {
                if (dx < 0) onLeft?.invoke() else onRight?.invoke()
                return true
            }
            return false
        }
    })
}
