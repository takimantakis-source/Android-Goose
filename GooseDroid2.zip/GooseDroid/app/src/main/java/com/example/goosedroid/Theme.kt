package com.example.goosedroid

import android.app.Activity
import android.content.Context
import android.graphics.Color

/** Light / dark mode, saved in SharedPreferences. Call apply() at the very start of onCreate. */
object ThemeMode {
    fun dark(ctx: Context) = Store.prefs(ctx).getBoolean("dark", false)

    fun toggle(ctx: Context) {
        Store.prefs(ctx).edit().putBoolean("dark", !dark(ctx)).apply()
    }

    fun apply(a: Activity, noActionBar: Boolean = false) {
        val dark = dark(a)
        a.setTheme(
            when {
                noActionBar && dark -> android.R.style.Theme_DeviceDefault_NoActionBar
                noActionBar -> android.R.style.Theme_DeviceDefault_Light_NoActionBar
                dark -> android.R.style.Theme_DeviceDefault
                else -> android.R.style.Theme_DeviceDefault_Light
            }
        )
    }

    fun bg(ctx: Context) = if (dark(ctx)) Color.rgb(18, 28, 46) else Color.rgb(190, 230, 255)
    fun text(ctx: Context) = if (dark(ctx)) Color.WHITE else Color.BLACK
    fun oppText(ctx: Context) = if (dark(ctx)) Color.rgb(255, 150, 150) else Color.rgb(140, 0, 0)
}
