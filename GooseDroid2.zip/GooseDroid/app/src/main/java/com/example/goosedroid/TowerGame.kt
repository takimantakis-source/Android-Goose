package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan
import kotlin.random.Random

/**
 * Game 8: Goose Shove. A 3D king-of-the-roof brawl on top of a skyscraper.
 * Shove the other geese off the edge. If you fall you land on the street and have to climb
 * back up an obstacle route on the side of the building (ladders, trampolines, elevators...).
 */
class TowerGame(ctx: Context, versus: Versus?, onExit: () -> Unit, mapIndex: Int, roundMin: Int) :
    BaseGame(ctx, "shove", versus, onExit) {

    companion object {
        const val GRAV = 28f
        const val JUMP_V = 10.5f
        const val HALF = 0.35f
        const val PH = 0.9f
        const val STEP = 0.35f
        const val CLIMB_MAX = 2.4f
        const val FOG = 170f
        const val NEAR = 0.3f
        const val PITCH = 0.32f
        // weights of the climbing sections: ledges, sliders, elevator, trampoline, ladder
        val ROUTE_W = arrayOf(
            intArrayOf(4, 1, 0, 1, 3), intArrayOf(3, 1, 1, 1, 3), intArrayOf(2, 1, 0, 5, 1),
            intArrayOf(2, 5, 0, 1, 1), intArrayOf(2, 1, 5, 1, 1), intArrayOf(2, 2, 2, 2, 2), intArrayOf(1, 1, 1, 1, 6)
        )
        val LOOKS = arrayOf(
            arrayOf("skin_pink", "hat_party"), arrayOf("skin_mint", ""), arrayOf("skin_gold", "hat_crown"),
            arrayOf("skin_gray", "hat_top"), arrayOf("skin_dark", "")
        )
        // corner indices of the 6 faces of a box: top, +x, -x, +z, -z, bottom
        val FACES = arrayOf(
            intArrayOf(4, 5, 7, 6), intArrayOf(1, 3, 7, 5), intArrayOf(0, 2, 6, 4),
            intArrayOf(2, 3, 7, 6), intArrayOf(0, 1, 5, 4), intArrayOf(0, 1, 3, 2)
        )
    }

    private val mapId = mapIndex.coerceIn(0, TowerMaps.ALL.size - 1)
    private val map = TowerMaps.ALL[mapId]
    private val H = map.height
    private val W = map.roofW
    private val D = map.roofD
    private val roundMs = roundMin.coerceIn(1, 60) * 60_000L

    override val coinRate = 0.4f
    override val versusLimitMs = roundMs + 30_000L
    override fun currentScore() = score

    // kind: 0 solid, 1 trampoline, 2 mover, 3 ladder (climbable, not solid)
    private class Blk(
        var x0: Float, var x1: Float, var y0: Float, var y1: Float,
        val z0: Float, val z1: Float, val color: Int, val kind: Int
    ) {
        var baseX = 0f
        var baseY = 0f
        var ampX = 0f
        var ampY = 0f
        var speed = 0f
        var ph = 0f
        var dx = 0f
        var dy = 0f
    }

    private class Gs(var x: Float, var y: Float, var z: Float, val look: Int) {
        var yaw = 0f
        var vy = 0f
        var cvx = 0f
        var cvz = 0f
        var kx = 0f
        var kz = 0f
        var state = 0 // bots: 0 on the roof, 1 falling, 2 climbing back up
        var stun = 0f
        var shoveCd = 1f
        var pusher = -1
        var credited = true
        var climbT = 0f
        var climbDur = 10f
        var climbX = 0f
        var thinkT = 0f
        var tx = 0f
        var tz = 0f
    }

    private class DI(val d2: Float, val type: Int, val ref: Any?)

    private val blocks = ArrayList<Blk>()
    private val obst = ArrayList<Blk>()
    private val decos = ArrayList<FloatArray>()
    private val geese = ArrayList<Gs>()
    private val items = ArrayList<DI>()
    private var groundBlk: Blk? = null
    private var bodyBlk: Blk? = null
    private var slabBlk: Blk? = null

    // player physics
    private var onGround = false
    private var coyote = 0f
    private var jumpBuf = 0f
    private var ladderCool = 0f
    private var standing: Blk? = null
    private var climbing = false
    private var climbTarget = 0f
    private var climbDx = 0f
    private var climbDz = 0f
    private var inputMag = 0f

    private var camYaw = 0f
    private var camX = 0f
    private var camY = 0f
    private var camZ = 0f
    private var camBase = 0f

    private var score = 0
    private var pushes = 0
    private var roofAcc = 0f
    private var t = 0f
    private var lastAt = 0L
    private var startAt = 0L
    private var flash = ""
    private var flashUntil = 0L
    private var ready = false

    // touch
    private var movePid = -1
    private var lookPid = -1
    private var moveOx = 0f
    private var moveOy = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var lastLookX = 0f

    // drawing
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(60, 0, 0, 0); strokeWidth = 1.2f
    }
    private val skyP = Paint()
    private val voidP = Paint()
    private val uiP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val leftP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val path = Path()
    private val rect = RectF()
    private val pr = FloatArray(8)
    private val pu = FloatArray(8)
    private val pd = FloatArray(8)
    private val qr = FloatArray(16)
    private val qu = FloatArray(16)
    private val qd = FloatArray(16)
    private val wx = FloatArray(8)
    private val wy = FloatArray(8)
    private val wz = FloatArray(8)
    private val cosP = cos(PITCH)
    private val sinP = sin(PITCH)
    private var focal = 1f
    private var cx0 = 0f
    private var cy0 = 0f
    private var fogC = Color.WHITE

    // goose parts: dx, y0, dz, hw, h, hd, color (0 body, 1 beak, 2 wing) - the goose faces +z
    private val gp = arrayOf(
        floatArrayOf(0f, 1.12f, 0.62f, 0.08f, 0.10f, 0.16f, 1f),
        floatArrayOf(0f, 1.05f, 0.30f, 0.17f, 0.30f, 0.17f, 0f),
        floatArrayOf(0f, 0.70f, 0.20f, 0.10f, 0.40f, 0.10f, 0f),
        floatArrayOf(0f, 0.30f, 0f, 0.30f, 0.45f, 0.42f, 0f),
        floatArrayOf(-0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0.34f, 0.42f, -0.02f, 0.05f, 0.25f, 0.28f, 2f),
        floatArrayOf(0f, 0.45f, -0.50f, 0.10f, 0.18f, 0.12f, 0f)
    )
    private val partDepth = FloatArray(12)
    private val partOrder = IntArray(12)

    init {
        hud.setTextColor(Color.WHITE)
        hud.setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    // =====================================================================
    // setup
    // =====================================================================

    override fun reset() {
        blocks.clear(); obst.clear(); decos.clear(); geese.clear()
        val ground = Blk(-600f, 600f, -5f, 0f, -600f, 600f, map.groundA, 0)
        blocks.add(ground); groundBlk = ground
        val body = Blk(-W / 2f, W / 2f, 0f, H - 0.3f, 0f, D, map.wallColor, 0)
        blocks.add(body); bodyBlk = body
        val slab = Blk(-W / 2f - 0.2f, W / 2f + 0.2f, H - 0.3f, H, -0.2f, D + 0.2f, map.roofColor, 0)
        blocks.add(slab); slabBlk = slab
        genObstacles()
        genRoute()
        val rnd = Random(mapId * 77 + 5)
        repeat(18) {
            val a = rnd.nextFloat() * 6.283f
            val rad = 55f + rnd.nextFloat() * 110f
            decos.add(
                floatArrayOf(
                    sin(a) * rad, D / 2f + cos(a) * rad,
                    4f + rnd.nextFloat() * 5f, 4f + rnd.nextFloat() * 5f, 8f + rnd.nextFloat() * H * 1.3f
                )
            )
        }

        geese.add(Gs(0f, H, D * 0.3f, 0))
        for (i in 0 until 5) {
            val a = i * 6.283f / 5f + 0.4f
            val g = Gs(sin(a) * W * 0.3f, H, D * 0.5f + cos(a) * D * 0.3f, i)
            g.yaw = a + 3.1416f
            g.shoveCd = 1.5f + Random.nextFloat()
            geese.add(g)
        }

        onGround = false; standing = null; climbing = false
        coyote = 0f; jumpBuf = 0f; ladderCool = 0f
        score = 0; pushes = 0; roofAcc = 0f; t = 0f
        camYaw = 0f; camBase = H
        movePid = -1; lookPid = -1
        val now = SystemClock.uptimeMillis()
        startAt = now; lastAt = now
        flash = ""; flashUntil = 0L
        focal = width * 0.9f
        cx0 = width / 2f
        cy0 = height * 0.46f
        ready = true
    }

    private fun crate(x: Float, z: Float, w: Float, d: Float, h: Float, color: Int) {
        if (abs(x) < 2.4f && abs(z - D * 0.3f) < 2.4f) return
        if (abs(x) + w / 2f > W / 2f - 0.8f || z - d / 2f < 0.8f || z + d / 2f > D - 0.8f) return
        val o = Blk(x - w / 2f, x + w / 2f, H, H + h, z - d / 2f, z + d / 2f, color, 0)
        blocks.add(o); obst.add(o)
    }

    private fun genObstacles() {
        val cz = D / 2f
        val crateC = Color.rgb(176, 124, 72)
        when (map.obstacles) {
            1 -> repeat(5) {
                crate((Random.nextFloat() - 0.5f) * (W - 4f), 2f + Random.nextFloat() * (D - 4f), 1.6f, 1.6f, 1.4f, crateC)
            }
            2 -> for (gx in -1..1) for (gz in -1..1) {
                crate(gx * W * 0.3f, cz + gz * D * 0.3f, 1.1f, 1.1f, 3.4f, Color.rgb(200, 200, 210))
            }
            3 -> repeat(13) {
                crate(
                    (Random.nextFloat() - 0.5f) * (W - 3f), 1.5f + Random.nextFloat() * (D - 3f),
                    1.2f + Random.nextFloat() * 1.2f, 1.2f + Random.nextFloat() * 1.2f, 1.1f + Random.nextFloat() * 0.9f, crateC
                )
            }
            4 -> {
                val hp = Blk(-3.5f, 3.5f, H, H + 0.8f, cz - 3.5f, cz + 3.5f, Color.rgb(90, 90, 95), 0)
                blocks.add(hp); obst.add(hp)
                crate(-6f, cz - 4f, 1.5f, 1.5f, 1.4f, crateC)
                crate(6f, cz + 4f, 1.5f, 1.5f, 1.4f, crateC)
            }
        }
    }

    /** The way back up: a chain of climbing sections on the front of the building. */
    private fun genRoute() {
        val xr = min(7f, W / 2f - 2f)
        val pal = PALETTE
        var y = 0f
        var x = 0f
        var n = 0
        fun ledge(lx: Float, ly: Float) {
            blocks.add(Blk(lx - 1.5f, lx + 1.5f, ly - 0.4f, ly, -3.2f, -0.2f, pal[n++ % pal.size], 0))
        }
        val w = ROUTE_W[min(map.route, ROUTE_W.size - 1)]
        while (y < H - 8f) {
            var r = Random.nextInt(w.sum())
            var kind = 0
            for (i in w.indices) { if (r < w[i]) { kind = i; break }; r -= w[i] }
            when (kind) {
                0 -> repeat(4) {
                    y += 1.7f
                    x = (x + (Random.nextFloat() - 0.5f) * 8f).coerceIn(-xr, xr)
                    ledge(x, y)
                }
                1 -> repeat(3) {
                    y += 1.7f
                    val m = Blk(x - 1.5f, x + 1.5f, y - 0.4f, y, -3.2f, -0.2f, Color.rgb(0, 188, 212), 2)
                    m.baseX = x; m.ampX = min(2.5f, xr - abs(x) + 2f); m.speed = 1.2f + Random.nextFloat() * 0.6f
                    m.ph = Random.nextFloat() * 6f
                    blocks.add(m)
                }
                2 -> {
                    val dir = if (x > 0f) -1f else 1f
                    val x2 = x + dir * 3.4f
                    val m = Blk(x2 - 1.5f, x2 + 1.5f, y - 0.4f, y, -3.2f, -0.2f, Color.rgb(255, 193, 7), 2)
                    m.baseY = y + 3.4f; m.ampY = 3.4f; m.speed = 0.8f; m.ph = -1.5708f
                    blocks.add(m)
                    y += 6.8f
                    x = x2 + dir * 3.4f
                    ledge(x, y)
                }
                3 -> {
                    blocks.add(Blk(x - 1.5f, x + 1.5f, y, y + 0.3f, -3.2f, -0.2f, Color.rgb(240, 98, 146), 1))
                    y += 4.6f
                    x = (x + (if (Random.nextBoolean()) 2.5f else -2.5f)).coerceIn(-xr, xr)
                    ledge(x, y)
                }
                else -> {
                    blocks.add(Blk(x - 0.6f, x + 0.6f, y, y + 6f, -1.1f, -0.1f, Color.rgb(121, 85, 72), 3))
                    y += 6f
                    ledge(x, y)
                }
            }
        }
        while (y < H - 2.0f) {
            y = min(y + 1.7f, H - 1.8f)
            ledge(x, y)
        }
    }

    private val PALETTE = intArrayOf(
        Color.rgb(104, 200, 90), Color.rgb(100, 181, 246), Color.rgb(255, 183, 77),
        Color.rgb(186, 104, 200), Color.rgb(77, 208, 225)
    )

    // =====================================================================
    // touch controls
    // =====================================================================

    private fun btnX(i: Int) = if (i == 0) width - 90 * d else width - 200 * d
    private fun btnY(i: Int) = if (i == 0) height - 120 * d else height - 70 * d
    private fun btnR(i: Int) = if (i == 0) 48 * d else 38 * d

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val id = e.getPointerId(idx)
                val x = e.getX(idx)
                val y = e.getY(idx)
                var btn = -1
                for (i in 0 until 2) if (hypot(x - btnX(i), y - btnY(i)) <= btnR(i) + 10 * d) btn = i
                when {
                    btn == 0 -> playerShove()
                    btn == 1 -> jumpBuf = 0.15f
                    x < width / 2f && movePid == -1 -> { movePid = id; moveOx = x; moveOy = y; moveX = x; moveY = y }
                    x >= width / 2f && lookPid == -1 -> { lookPid = id; lastLookX = x }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == movePid) {
                        moveX = e.getX(i); moveY = e.getY(i)
                    } else if (id == lookPid) {
                        val x = e.getX(i)
                        camYaw += (x - lastLookX) * 0.006f
                        lastLookX = x
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == movePid) movePid = -1
                if (id == lookPid) lookPid = -1
                if (a != MotionEvent.ACTION_POINTER_UP) { movePid = -1; lookPid = -1 }
            }
        }
        return true
    }

    // =====================================================================
    // game loop
    // =====================================================================

    override fun tick() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastAt) / 1000f).coerceIn(0.001f, 0.05f)
        lastAt = now
        t += dt
        val elapsed = now - startAt
        if (elapsed >= roundMs) { gameOver(trf("You shoved %d geese off the roof!", pushes), score); return }

        val p = geese[0]
        p.shoveCd = max(0f, p.shoveCd - dt)
        p.stun = max(0f, p.stun - dt)
        jumpBuf = max(0f, jumpBuf - dt)
        coyote = max(0f, coyote - dt)
        ladderCool = max(0f, ladderCool - dt)

        updateBlocks()
        movePlayer(dt)
        for (i in 1 until geese.size) updateBot(geese[i], i, dt)

        if (onRoof(p)) roofAcc += dt
        score = roofAcc.toInt() + pushes * 10

        camBase += (p.y - camBase) * min(1f, 5f * dt)
        camX = p.x - sin(camYaw) * 6.5f
        camZ = p.z - cos(camYaw) * 6.5f
        camY = camBase + 3.4f
        if (camY < H && camX > -W / 2f - 0.5f && camX < W / 2f + 0.5f && camZ > -0.5f && camZ < D + 0.5f) camZ = -0.6f

        val secs = ((roundMs - elapsed) / 1000).toInt().coerceIn(0, (roundMs / 1000).toInt()) + 1
        hud.text = trf("Score: %d     Time: %s", score, String.format("%d:%02d", secs / 60, secs % 60))
        invalidate()
    }

    private fun flashMsg(s: String) {
        flash = s
        flashUntil = SystemClock.uptimeMillis() + 1500L
    }

    private fun onRoof(p: Gs) =
        p.y >= H - 0.6f && p.x > -W / 2f - 0.2f && p.x < W / 2f + 0.2f && p.z > -0.2f && p.z < D + 0.2f

    private fun onRoofGoose(g: Gs, i: Int) = if (i == 0) onRoof(g) else g.state == 0

    private fun updateBlocks() {
        for (b in blocks) {
            var nx = (b.x0 + b.x1) / 2f
            var ny = b.y1
            if (b.ampX != 0f) nx = b.baseX + sin(t * b.speed + b.ph) * b.ampX
            if (b.ampY != 0f) ny = b.baseY + sin(t * b.speed + b.ph) * b.ampY
            b.dx = nx - (b.x0 + b.x1) / 2f
            b.dy = ny - b.y1
            b.x0 += b.dx; b.x1 += b.dx; b.y0 += b.dy; b.y1 += b.dy
        }
    }

    // ---------- player physics ----------

    private fun overlap(b: Blk, x: Float, y: Float, z: Float) =
        x + HALF > b.x0 && x - HALF < b.x1 && y + PH > b.y0 && y < b.y1 && z + HALF > b.z0 && z - HALF < b.z1

    private fun hitBlock(x: Float, y: Float, z: Float): Blk? {
        for (b in blocks) {
            if (b.kind == 3) continue
            if (overlap(b, x, y + STEP, z)) return b
        }
        return null
    }

    private fun ladderAt(p: Gs): Blk? {
        for (b in blocks) {
            if (b.kind != 3) continue
            if (p.x + HALF + 0.3f > b.x0 && p.x - HALF - 0.3f < b.x1 && p.z + HALF > b.z0 - 0.6f && p.z - HALF < b.z1 &&
                p.y < b.y1 && p.y + PH > b.y0 + 0.2f
            ) return b
        }
        return null
    }

    private fun stepMove(p: Gs, dx: Float, dz: Float) {
        val nx = p.x + dx
        val nz = p.z + dz
        val hit = hitBlock(nx, p.y, nz)
        if (hit == null) { p.x = nx; p.z = nz; return }
        if (inputMag > 0.3f && hit.y1 - p.y <= CLIMB_MAX && hit.y1 > p.y + STEP) {
            climbing = true
            climbTarget = hit.y1
            val m = max(0.01f, hypot(dx, dz))
            climbDx = dx / m
            climbDz = dz / m
        }
    }

    private fun movePlayer(dt: Float) {
        val p = geese[0]
        standing?.let { p.x += it.dx; p.y += it.dy } // ride elevators and sliders

        var fwd = 0f
        var str = 0f
        if (movePid != -1) {
            val r = 56f * d
            var jx = (moveX - moveOx) / r
            var jy = (moveY - moveOy) / r
            val len = hypot(jx, jy)
            if (len > 1f) { jx /= len; jy /= len }
            fwd = -jy
            str = jx
        }
        val sn = sin(camYaw)
        val cs = cos(camYaw)
        var wx = sn * fwd + cs * str
        var wz = cs * fwd - sn * str
        inputMag = hypot(wx, wz)
        if (p.stun > 0f) { wx *= 0.25f; wz *= 0.25f }
        if (inputMag > 0.1f) p.yaw = atan2(wx, wz)

        val slipK = 1f - 0.9f * map.slip
        val acc = min(1f, (if (onGround) 14f * slipK else 4f) * dt)
        p.cvx += (wx * 6.5f + map.wind - p.cvx) * acc
        p.cvz += (wz * 6.5f - p.cvz) * acc
        val kd = exp(-3f * slipK * dt)
        p.kx *= kd
        p.kz *= kd
        val mx = (p.cvx + p.kx) * dt
        val mz = (p.cvz + p.kz) * dt

        if (climbing) {
            p.y += 8f * dt
            p.vy = 0f
            standing = null
            if (p.y >= climbTarget) {
                p.y = climbTarget
                climbing = false
                p.x += climbDx * 0.7f
                p.z += climbDz * 0.7f
            }
            return
        }

        if (mx != 0f) stepMove(p, mx, 0f)
        if (mz != 0f && !climbing) stepMove(p, 0f, mz)
        if (climbing) return

        val lad = ladderAt(p)
        if (lad != null && ladderCool <= 0f) {
            p.vy = 4.5f
            onGround = false
            standing = null
            if (jumpBuf > 0f) { p.vy = 9f; ladderCool = 0.35f; jumpBuf = 0f }
            p.y += p.vy * dt
            return
        }

        if (jumpBuf > 0f && (onGround || coyote > 0f)) {
            p.vy = JUMP_V; onGround = false; coyote = 0f; jumpBuf = 0f
            Sound.play(400.0, 700.0, 70)
        }
        p.vy -= GRAV * dt
        val ny = p.y + p.vy * dt
        var ground = -1000f
        var gb: Blk? = null
        for (b in blocks) {
            if (b.kind == 3) continue
            if (p.x + HALF > b.x0 && p.x - HALF < b.x1 && p.z + HALF > b.z0 && p.z - HALF < b.z1 &&
                b.y1 <= p.y + STEP + 0.001f && b.y1 > ground
            ) { ground = b.y1; gb = b }
        }
        if (p.vy <= 0f && ny <= ground) {
            p.y = ground
            if (gb != null && gb.kind == 1) {
                p.vy = 17f; onGround = false; standing = null
                Sound.play(500.0, 900.0, 80)
            } else {
                p.vy = 0f; onGround = true; standing = gb; coyote = 0.1f
            }
        } else {
            p.y = ny; onGround = false; standing = null
        }
    }

    // ---------- shoving ----------

    private fun applyShove(att: Gs, attIdx: Int) {
        var best: Gs? = null
        var bi = -1
        var bd = 2.4f
        for ((i, o) in geese.withIndex()) {
            if (o === att || !onRoofGoose(o, i)) continue
            val dx = o.x - att.x
            val dz = o.z - att.z
            val dd = hypot(dx, dz)
            if (dd >= bd || abs(o.y - att.y) > 1.5f) continue
            var da = atan2(dx, dz) - att.yaw
            while (da > 3.1416f) da -= 6.2832f
            while (da < -3.1416f) da += 6.2832f
            if (abs(da) < 1.3f) { best = o; bi = i; bd = dd }
        }
        val o = best ?: return
        val dx = o.x - att.x
        val dz = o.z - att.z
        val len = max(0.1f, hypot(dx, dz))
        o.kx += dx / len * 14f
        o.kz += dz / len * 14f
        o.vy = 5f
        o.stun = 0.9f
        o.pusher = attIdx
        o.credited = false
        if (bi == 0) { onGround = false; standing = null; flashMsg(tr("You got shoved!")) }
        Sound.play(220.0, 90.0, 90)
    }

    private fun playerShove() {
        val p = geese[0]
        if (p.shoveCd > 0f) return
        p.shoveCd = 1.1f
        applyShove(p, 0)
        p.kx += sin(p.yaw) * 3f
        p.kz += cos(p.yaw) * 3f
    }

    // ---------- bots ----------

    private fun updateBot(b: Gs, idx: Int, dt: Float) {
        b.stun = max(0f, b.stun - dt)
        b.shoveCd = max(0f, b.shoveCd - dt)
        when (b.state) {
            0 -> botRoof(b, idx, dt)
            1 -> botFall(b, dt)
            else -> botClimb(b, dt)
        }
    }

    private fun pushOut(b: Gs) {
        for (o in obst) {
            if (b.y > o.y1 - 0.1f) continue
            val r = 0.4f
            if (b.x > o.x0 - r && b.x < o.x1 + r && b.z > o.z0 - r && b.z < o.z1 + r) {
                val l = b.x - (o.x0 - r)
                val rr = (o.x1 + r) - b.x
                val f = b.z - (o.z0 - r)
                val bk = (o.z1 + r) - b.z
                val m = min(min(l, rr), min(f, bk))
                if (m == l) b.x = o.x0 - r
                else if (m == rr) b.x = o.x1 + r
                else if (m == f) b.z = o.z0 - r
                else b.z = o.z1 + r
            }
        }
    }

    private fun botRoof(b: Gs, idx: Int, dt: Float) {
        val slipK = 1f - 0.9f * map.slip
        b.thinkT -= dt
        if (b.thinkT <= 0f) {
            b.thinkT = 0.5f + Random.nextFloat() * 0.6f
            var best = 1e9f
            var tx = b.x
            var tz = b.z
            for ((i, o) in geese.withIndex()) {
                if (o === b || !onRoofGoose(o, i)) continue
                val dd = hypot(o.x - b.x, o.z - b.z)
                if (dd < best) { best = dd; tx = o.x; tz = o.z }
            }
            b.tx = tx
            b.tz = tz
        }
        var mx = 0f
        var mz = 0f
        if (b.stun <= 0f) {
            val dx = b.tx - b.x
            val dz = b.tz - b.z
            val dist = hypot(dx, dz)
            if (dist > 1.4f) { mx = dx / dist * 4.2f; mz = dz / dist * 4.2f }
            if (dist > 0.05f) b.yaw = atan2(dx, dz)
            if (dist < 1.9f && b.shoveCd <= 0f) { applyShove(b, idx); b.shoveCd = 1.6f + Random.nextFloat() }
        }
        val kd = exp(-3f * slipK * dt)
        b.kx *= kd
        b.kz *= kd
        b.x += (mx + map.wind * 0.6f + b.kx) * dt
        b.z += (mz + b.kz) * dt
        pushOut(b)
        if (b.vy != 0f || b.y > H) {
            b.vy -= GRAV * dt
            b.y += b.vy * dt
            if (b.y <= H) { b.y = H; b.vy = 0f }
        }
        val out = b.x < -W / 2f - 0.2f || b.x > W / 2f + 0.2f || b.z < -0.2f || b.z > D + 0.2f
        if (out) {
            b.state = 1
            b.vy = max(0f, b.vy)
        } else if (b.stun <= 0f) {
            b.x = b.x.coerceIn(-W / 2f + 0.7f, W / 2f - 0.7f)
            b.z = b.z.coerceIn(0.7f, D - 0.7f)
        }
    }

    private fun botFall(b: Gs, dt: Float) {
        b.vy -= GRAV * dt
        b.y += b.vy * dt
        b.x += b.kx * dt
        b.z += b.kz * dt
        if (!b.credited && b.pusher == 0 && b.y < H - 2f) {
            b.credited = true
            pushes++
            flashMsg(tr("Shoved one off! +10"))
            Sound.play(700.0, 300.0, 200)
        }
        if (b.y <= 0f) {
            b.y = 0f
            b.state = 2
            b.climbT = 0f
            b.climbDur = H * 0.55f + Random.nextFloat() * 5f
            b.climbX = (Random.nextFloat() - 0.5f) * 8f
            b.kx = 0f
            b.kz = 0f
            b.yaw = 0f
        }
    }

    private fun botClimb(b: Gs, dt: Float) {
        b.climbT += dt
        val s = (b.climbT / b.climbDur).coerceIn(0f, 1f)
        b.y = s * (H - 0.4f)
        b.x = b.climbX + sin(b.climbT * 2.1f) * 1.4f
        b.z = -1.7f
        if (s >= 1f) {
            b.state = 0
            b.y = H
            b.x = b.x.coerceIn(-W / 2f + 1f, W / 2f - 1f)
            b.z = 1.0f
            b.stun = 0.5f
            b.pusher = -1
            b.vy = 0f
        }
    }

    // =====================================================================
    // 3D drawing
    // =====================================================================

    private fun mixC(a: Int, b: Int, f: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
    )

    private fun tone(color: Int, k: Float, fog: Float): Int = mixC(
        Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt()), fogC, fog
    )

    /** World point -> camera space slot i (right, up, depth). The camera turns with camYaw. */
    private fun put(i: Int, x: Float, y: Float, z: Float) {
        val rx = x - camX
        val ry = y - camY
        val rz = z - camZ
        val ax = rx * cos(camYaw) - rz * sin(camYaw)
        val az = rx * sin(camYaw) + rz * cos(camYaw)
        pr[i] = ax
        pu[i] = ry * cosP + az * sinP
        pd[i] = -ry * sinP + az * cosP
    }

    private fun poly(c: Canvas, color: Int, n: Int) {
        var m = 0
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            val di = pd[i] - NEAR
            val dj = pd[j] - NEAR
            if (di >= 0f) { qr[m] = pr[i]; qu[m] = pu[i]; qd[m] = pd[i]; m++ }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                qr[m] = pr[i] + (pr[j] - pr[i]) * f
                qu[m] = pu[i] + (pu[j] - pu[i]) * f
                qd[m] = NEAR
                m++
            }
        }
        if (m < 3) return
        path.reset()
        for (k in 0 until m) {
            val sx = cx0 + focal * qr[k] / qd[k]
            val sy = cy0 - focal * qu[k] / qd[k]
            if (k == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)
        }
        path.close()
        fillP.color = color
        c.drawPath(path, fillP)
        c.drawPath(path, lineP)
    }

    private fun quadTop(c: Canvas, x0: Float, x1: Float, z0: Float, z1: Float, y: Float, color: Int) {
        put(0, x0, y, z0); put(1, x1, y, z0); put(2, x1, y, z1); put(3, x0, y, z1)
        poly(c, color, 4)
    }

    /** A box that can be turned around the vertical axis. Only the faces looking at the camera are drawn. */
    private fun rbox(c: Canvas, cx: Float, y0: Float, cz: Float, hw: Float, h: Float, hd: Float, yaw: Float, color: Int) {
        val cs = cos(yaw)
        val sn = sin(yaw)
        for (i in 0 until 8) {
            val lx = if ((i and 1) == 0) -hw else hw
            val lz = if (((i shr 1) and 1) == 0) -hd else hd
            wx[i] = cx + lx * cs + lz * sn
            wz[i] = cz - lx * sn + lz * cs
            wy[i] = if (((i shr 2) and 1) == 0) y0 else y0 + h
        }
        val dist = hypot(hypot(cx - camX, cz - camZ), y0 + h / 2f - camY)
        val fog = (dist / FOG).coerceIn(0f, 0.9f)
        for (f in 0 until 6) {
            val nx: Float
            val ny: Float
            val nz: Float
            when (f) {
                0 -> { nx = 0f; ny = 1f; nz = 0f }
                1 -> { nx = cs; ny = 0f; nz = -sn }
                2 -> { nx = -cs; ny = 0f; nz = sn }
                3 -> { nx = sn; ny = 0f; nz = cs }
                4 -> { nx = -sn; ny = 0f; nz = -cs }
                else -> { nx = 0f; ny = -1f; nz = 0f }
            }
            val fc = FACES[f]
            val fcx = (wx[fc[0]] + wx[fc[1]] + wx[fc[2]] + wx[fc[3]]) / 4f
            val fcy = (wy[fc[0]] + wy[fc[1]] + wy[fc[2]] + wy[fc[3]]) / 4f
            val fcz = (wz[fc[0]] + wz[fc[1]] + wz[fc[2]] + wz[fc[3]]) / 4f
            if ((camX - fcx) * nx + (camY - fcy) * ny + (camZ - fcz) * nz <= 0f) continue
            val shade = min(1f, 0.55f + 0.45f * max(0f, nx * 0.4f + ny * 0.85f - nz * 0.35f))
            for (k in 0 until 4) put(k, wx[fc[k]], wy[fc[k]], wz[fc[k]])
            poly(c, tone(color, shade, fog), 4)
        }
    }

    private fun hatColor(id: String) = when (id) {
        "hat_top", "hat_pirate" -> Color.rgb(33, 33, 33)
        "hat_crown" -> Color.rgb(255, 193, 7)
        "hat_party" -> Color.rgb(233, 30, 99)
        "hat_santa" -> Color.rgb(229, 57, 53)
        "hat_cowboy" -> Color.rgb(141, 110, 99)
        "hat_wizard" -> Color.rgb(106, 27, 154)
        "hat_chef" -> Color.WHITE
        "hat_halo" -> Color.rgb(255, 235, 59)
        "hat_viking" -> Color.rgb(158, 158, 158)
        else -> Color.rgb(33, 150, 243)
    }

    /** A boxy goose turned towards yaw. */
    private fun drawGoose(c: Canvas, x: Float, y: Float, z: Float, yaw: Float, body: Int, beak: Int, hat: String, swing: Float) {
        val cs = cos(yaw)
        val sn = sin(yaw)
        val wing = tone(body, 0.88f, 0f)
        // collect parts: 2 legs + body parts + optional hat, drawn far to near
        val n = gp.size
        val total = 2 + n + (if (hat.isEmpty()) 0 else 1)
        val parts = Array(total) { FloatArray(8) }
        parts[0] = floatArrayOf(-0.14f, 0f, swing, 0.06f, 0.32f, 0.07f, 1f)
        parts[1] = floatArrayOf(0.14f, 0f, -swing, 0.06f, 0.32f, 0.07f, 1f)
        for (k in 0 until n) parts[2 + k] = gp[k]
        if (hat.isNotEmpty()) {
            val h = if (hat == "hat_top" || hat == "hat_wizard" || hat == "hat_chef") 0.38f else 0.2f
            parts[total - 1] = floatArrayOf(0f, 1.33f, 0.30f, 0.21f, h, 0.21f, 3f)
        }
        for (k in 0 until total) {
            val p = parts[k]
            val px = x + p[0] * cs + p[2] * sn
            val pz = z - p[0] * sn + p[2] * cs
            partDepth[k] = (px - camX) * sin(camYaw) + (pz - camZ) * cos(camYaw)
            partOrder[k] = k
        }
        for (i in 1 until total) { // tiny insertion sort, far first
            val v = partOrder[i]
            var j = i - 1
            while (j >= 0 && partDepth[partOrder[j]] < partDepth[v]) { partOrder[j + 1] = partOrder[j]; j-- }
            partOrder[j + 1] = v
        }
        for (k in 0 until total) {
            val p = parts[partOrder[k]]
            val col = when (p[6].toInt()) { 0 -> body; 1 -> beak; 2 -> wing; else -> hatColor(hat) }
            rbox(c, x + p[0] * cs + p[2] * sn, y + p[1], z - p[0] * sn + p[2] * cs, p[3], p[4], p[5], yaw, col)
        }
    }

    private fun label3d(c: Canvas, x: Float, y: Float, z: Float, s: String, size: Float) {
        put(0, x, y, z)
        if (pd[0] < NEAR) return
        textP.textSize = size
        c.drawText(s, cx0 + focal * pr[0] / pd[0], cy0 - focal * pu[0] / pd[0], textP)
    }

    override fun onDraw(c: Canvas) {
        if (!ready) return
        val w = width.toFloat()
        val h = height.toFloat()
        val horizonY = cy0 - focal * tan(PITCH)
        fogC = map.skyHor
        skyP.shader = LinearGradient(0f, 0f, 0f, horizonY, map.skyTop, map.skyHor, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, horizonY, skyP)
        voidP.shader = LinearGradient(0f, horizonY, 0f, h, map.skyHor, mixC(map.groundA, map.skyHor, 0.35f), Shader.TileMode.CLAMP)
        c.drawRect(0f, horizonY, w, h, voidP)

        // the street far below: a checkered floor
        val ts = 40f
        val bx = floor(camX / ts).toInt()
        val bz = floor(camZ / ts).toInt()
        for (iz in -5..5) for (ix in -5..5) {
            val gx = bx + ix
            val gz = bz + iz
            val x0 = gx * ts
            val z0 = gz * ts
            val col = if (((gx + gz) and 1) == 0) map.groundA else map.groundB
            val dist = hypot(hypot(x0 + ts / 2f - camX, z0 + ts / 2f - camZ), camY)
            quadTop(c, x0, x0 + ts, z0, z0 + ts, 0f, tone(col, 1f, (dist / (FOG * 1.3f)).coerceIn(0f, 0.95f)))
        }
        // distant city
        for (dc in decos.sortedByDescending { hypot(it[0] - camX, it[1] - camZ) }) {
            rbox(c, dc[0], 0f, dc[1], dc[2], dc[4], dc[3], 0f, map.decoColor)
        }
        // the skyscraper
        bodyBlk?.let { b -> rbox(c, 0f, 0f, D / 2f, W / 2f, b.y1, D / 2f, 0f, b.color) }
        slabBlk?.let { b -> rbox(c, 0f, b.y0, D / 2f, W / 2f + 0.2f, b.y1 - b.y0, D / 2f + 0.2f, 0f, b.color) }

        items.clear()
        for (b in blocks) {
            if (b === groundBlk || b === bodyBlk || b === slabBlk) continue
            val dx = (b.x0 + b.x1) / 2f - camX
            val dy = (b.y0 + b.y1) / 2f - camY
            val dz = (b.z0 + b.z1) / 2f - camZ
            items.add(DI(dx * dx + dy * dy + dz * dz, 0, b))
        }
        for (g in geese) {
            val dx = g.x - camX
            val dy = g.y + 0.6f - camY
            val dz = g.z - camZ
            items.add(DI(dx * dx + dy * dy + dz * dz - 1f, 1, g))
        }
        items.sortByDescending { it.d2 }
        for (di in items) {
            if (di.type == 0) {
                val b = di.ref as Blk
                rbox(c, (b.x0 + b.x1) / 2f, b.y0, (b.z0 + b.z1) / 2f, (b.x1 - b.x0) / 2f, b.y1 - b.y0, (b.z1 - b.z0) / 2f, 0f, b.color)
            } else {
                val g = di.ref as Gs
                val isPlayer = g === geese[0]
                val look = LOOKS[g.look % LOOKS.size]
                val sk = Store.byId(look[0])
                val body = if (isPlayer) Cosmetics.body else sk?.c1 ?: Color.WHITE
                val beak = if (isPlayer) Cosmetics.beak else sk?.c2 ?: Color.rgb(255, 140, 0)
                val hat = if (isPlayer) Cosmetics.hat else look[1]
                val moving = isPlayer && onGround || (!isPlayer && g.state != 1)
                val swing = if (moving) sin(t * 12f + g.look) * 0.15f else 0.1f
                drawGoose(c, g.x, g.y, g.z, g.yaw, body, beak, hat, swing)
                if (isPlayer) label3d(c, g.x, g.y + 2.1f, g.z, "▼", 22 * d)
            }
        }
        drawHud(c, w, h)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        val now = SystemClock.uptimeMillis()
        val p = geese[0]
        val top = (if (versus != null) 104 else 80) * d
        leftP.textSize = 15 * d
        val st = if (onRoof(p)) tr("🏢 Shove the others off the roof!") else tr("🧗 You fell! Climb back up!")
        c.drawText(st, 16 * d, top, leftP)
        if (!onRoof(p)) c.drawText(trf("⬆ %d / %d m", max(0f, p.y).toInt(), H.toInt()), 16 * d, top + 22 * d, leftP)

        if (now < flashUntil) {
            textP.textSize = 22 * d
            c.drawText(flash, w / 2f, h * 0.24f, textP)
        }
        if (t < 7f) {
            textP.textSize = 12 * d
            c.drawText(tr("Left thumb: move   Right: turn camera   Buttons: shove, jump"), w / 2f, h * 0.32f, textP)
        }
        if (movePid != -1) {
            val r = 56f * d
            var jx = moveX - moveOx
            var jy = moveY - moveOy
            val len = hypot(jx, jy)
            if (len > r) { jx = jx / len * r; jy = jy / len * r }
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 3 * d
            uiP.color = Color.argb(130, 255, 255, 255)
            c.drawCircle(moveOx, moveOy, r, uiP)
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(170, 255, 255, 255)
            c.drawCircle(moveOx + jx, moveOy + jy, 20f * d, uiP)
        }
        for (i in 0 until 2) {
            val dim = i == 0 && p.shoveCd > 0f
            uiP.style = Paint.Style.FILL
            uiP.color = Color.argb(if (dim) 45 else 95, 255, 255, 255)
            c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
            uiP.style = Paint.Style.STROKE
            uiP.strokeWidth = 3 * d
            uiP.color = Color.argb(160, 255, 255, 255)
            c.drawCircle(btnX(i), btnY(i), btnR(i), uiP)
            textP.textSize = btnR(i) * 0.9f
            c.drawText(if (i == 0) "👊" else "⬆", btnX(i), btnY(i) + btnR(i) * 0.3f, textP)
        }
    }
}
