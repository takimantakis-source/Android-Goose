package com.example.goosedroid

import android.graphics.Color

/**
 * A skyscraper roof for Goose Shove.
 * obstacles: 0 none, 1 a few crates, 2 pillars, 3 lots of crates, 4 helipad.
 * route (how you climb back up): 0 ledges+ladders, 1 windy mix, 2 trampolines, 3 sliding ledges, 4 elevators, 5 everything, 6 ladders.
 */
class TowerMap(
    val name: String, val height: Float, val roofW: Float, val roofD: Float,
    val skyTop: Int, val skyHor: Int, val roofColor: Int, val wallColor: Int,
    val groundA: Int, val groundB: Int, val decoColor: Int,
    val wind: Float, val slip: Float, val obstacles: Int, val route: Int
)

object TowerMaps {
    val ALL = listOf(
        TowerMap(
            "Downtown", 40f, 18f, 18f,
            Color.rgb(110, 180, 240), Color.rgb(210, 235, 255), Color.rgb(110, 110, 120), Color.rgb(160, 120, 110),
            Color.rgb(95, 100, 105), Color.rgb(85, 90, 95), Color.rgb(130, 145, 170), 0f, 0f, 1, 0
        ),
        TowerMap(
            "Skyscraper", 55f, 12f, 12f,
            Color.rgb(70, 130, 220), Color.rgb(190, 220, 250), Color.rgb(60, 70, 90), Color.rgb(80, 120, 160),
            Color.rgb(80, 85, 95), Color.rgb(70, 75, 85), Color.rgb(100, 130, 170), 0f, 0f, 0, 4
        ),
        TowerMap(
            "Windy Heights", 45f, 20f, 20f,
            Color.rgb(150, 190, 230), Color.rgb(235, 240, 245), Color.rgb(140, 140, 150), Color.rgb(170, 170, 180),
            Color.rgb(110, 120, 110), Color.rgb(100, 110, 100), Color.rgb(160, 170, 185), 2.0f, 0f, 1, 1
        ),
        TowerMap(
            "Ice Tower", 40f, 18f, 18f,
            Color.rgb(150, 210, 250), Color.rgb(235, 250, 255), Color.rgb(210, 240, 250), Color.rgb(160, 215, 240),
            Color.rgb(235, 245, 250), Color.rgb(215, 230, 240), Color.rgb(190, 225, 245), 0f, 0.9f, 2, 3
        ),
        TowerMap(
            "Crate Maze", 35f, 24f, 24f,
            Color.rgb(255, 205, 150), Color.rgb(255, 235, 200), Color.rgb(150, 110, 70), Color.rgb(190, 140, 90),
            Color.rgb(150, 125, 95), Color.rgb(140, 115, 85), Color.rgb(170, 140, 100), 0f, 0f, 3, 0
        ),
        TowerMap(
            "Pillar Plaza", 40f, 22f, 22f,
            Color.rgb(200, 170, 240), Color.rgb(240, 225, 255), Color.rgb(230, 225, 235), Color.rgb(200, 190, 210),
            Color.rgb(210, 205, 215), Color.rgb(195, 190, 200), Color.rgb(190, 180, 215), 0f, 0f, 2, 2
        ),
        TowerMap(
            "Neon Night", 50f, 16f, 16f,
            Color.rgb(8, 10, 40), Color.rgb(60, 30, 110), Color.rgb(30, 30, 60), Color.rgb(40, 40, 80),
            Color.rgb(20, 25, 50), Color.rgb(30, 35, 70), Color.rgb(110, 50, 190), 0f, 0f, 1, 5
        ),
        TowerMap(
            "Helipad", 45f, 20f, 14f,
            Color.rgb(100, 170, 230), Color.rgb(215, 235, 250), Color.rgb(150, 150, 155), Color.rgb(200, 200, 205),
            Color.rgb(105, 125, 105), Color.rgb(95, 115, 95), Color.rgb(160, 170, 185), 0f, 0f, 4, 4
        ),
        TowerMap(
            "Construction Site", 50f, 18f, 18f,
            Color.rgb(240, 190, 120), Color.rgb(255, 230, 180), Color.rgb(110, 100, 90), Color.rgb(200, 150, 60),
            Color.rgb(170, 150, 110), Color.rgb(155, 135, 95), Color.rgb(190, 160, 80), 0f, 0f, 3, 6
        ),
        TowerMap(
            "Candy Tower", 40f, 20f, 20f,
            Color.rgb(255, 170, 210), Color.rgb(255, 225, 240), Color.rgb(180, 230, 250), Color.rgb(250, 150, 190),
            Color.rgb(255, 220, 235), Color.rgb(250, 200, 225), Color.rgb(240, 170, 210), 1.2f, 0.6f, 2, 5
        )
    )
}
