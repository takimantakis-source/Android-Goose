package com.example.goosedroid

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.sin

/** A little goose that shows how everything works. Shown on the first start and with the ❓ button. */
class Tutorial(ctx: Context, private val onDone: () -> Unit) : FrameLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val steps = listOf(
        tr("Honk! I'm Gus, your goose guide. Let me show you around!"),
        tr("Tap “Release the goose” and I'll waddle over your other apps. Tap me to honk, drag me to move me!"),
        tr("Minigames earn you coins 🪙. Play solo, or online against players or bots."),
        tr("Spend your coins in the 🛍 Shop on skins and accessories. They show on your goose!"),
        tr("Tap 🎵 for the music player: covers, playlists, designs and more. Hold a song to add it to a playlist."),
        tr("Swipe left to chat with me! 💬"),
        tr("Swipe right for the Extras shop: pets and honk sounds! 🐥"),
        tr("Tap ⚙ for settings and languages, and 🌙 for dark mode. Tap ❓ to see this tour again."),
        tr("That's it! Have fun, and don't forget to honk! 🪿")
    )
    private var step = 0
    private val goose = GooseView(ctx, 1.2f)
    private val text = TextView(ctx)
    private val next = Button(ctx)
    private val skip = Button(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private var bob = 0f
    private val bobber = object : Runnable {
        override fun run() {
            bob += 0.25f
            goose.translationY = sin(bob) * 8 * d
            handler.postDelayed(this, 40)
        }
    }

    init {
        setBackgroundColor(Color.argb(170, 0, 0, 0))
        isClickable = true // swallow touches so the menu below stays still

        val p = (16 * d).toInt()
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(p, p, p, p)
        }
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, p / 2)
            background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(Color.WHITE) }
        }
        text.apply { textSize = 17f; setTextColor(Color.BLACK) }
        card.addView(text)
        skip.text = tr("Skip")
        skip.setOnClickListener { finish() }
        next.setOnClickListener { if (step >= steps.size - 1) finish() else { step++; show() } }
        val btns = LinearLayout(ctx).apply { gravity = Gravity.END }
        btns.addView(skip)
        btns.addView(next)
        card.addView(btns)
        col.addView(card, LinearLayout.LayoutParams(-1, -2))
        col.addView(goose, LinearLayout.LayoutParams(goose.sizeW, goose.sizeH))
        addView(col, LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (24 * d).toInt() })
        show()
    }

    private fun show() {
        text.text = steps[step]
        next.text = if (step >= steps.size - 1) tr("Let's go!") else tr("Next ▶")
        goose.bubble = if (step == 0) "HONK!" else null
        goose.invalidate()
    }

    private fun finish() {
        handler.removeCallbacks(bobber)
        onDone()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(bobber)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(bobber)
        super.onDetachedFromWindow()
    }
}
