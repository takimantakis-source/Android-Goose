package com.example.goosedroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import kotlin.random.Random

/** Game 5: geese pop out of holes, tap them. Tap a fox and you lose points. 30 seconds. */
class WhackGame(ctx: Context, versus: Versus?, onExit: () -> Unit) : BaseGame(ctx, "whack", versus, onExit) {
    override fun currentScore() = score

    private val state = IntArray(9) // 0 empty, 1 goose, 2 fox
    private val until = LongArray(9)
    private val cells = Array(9) { RectF() }
    private var score = 0
    private var endAt = 0L
    private var nextSpawn = 0L

    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private val holeP = fill(Color.rgb(93, 64, 55))
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(80, 80, 80); strokeWidth = 2 * d
    }
    private val body = fill(Color.WHITE)
    private val beakP = fill(Color.rgb(255, 140, 0))
    private val foxP = fill(Color.rgb(230, 74, 25))
    private val snoutP = fill(Color.WHITE)
    private val eyeP = fill(Color.BLACK)

    override fun reset() {
        score = 0
        state.fill(0)
        val now = SystemClock.uptimeMillis()
        endAt = now + 30_000
        nextSpawn = now + 500
        val top = 110 * d
        val area = height - top - 24 * d
        val cell = minOf(width / 3f, area / 3f)
        val left = (width - 3 * cell) / 2f
        for (i in 0 until 9) {
            val l = left + (i % 3) * cell
            val t = top + (i / 3) * cell
            cells[i].set(l + 8 * d, t + 8 * d, l + cell - 8 * d, t + cell - 8 * d)
        }
    }

    override fun tick() {
        val now = SystemClock.uptimeMillis()
        val left = endAt - now
        if (left <= 0) { gameOver(trf("You whacked %d!", score), score); return }
        hud.text = trf("Score: %d     Time: %d", score, left / 1000 + 1)

        for (i in 0 until 9) if (state[i] != 0 && now >= until[i]) state[i] = 0
        if (now >= nextSpawn) {
            val empty = (0 until 9).filter { state[it] == 0 }
            if (empty.isNotEmpty()) {
                val i = empty.random()
                state[i] = if (Random.nextInt(4) == 0) 2 else 1
                until[i] = now + (1100 - score * 15L).coerceAtLeast(550L)
            }
            nextSpawn = now + (650 - score * 8L).coerceAtLeast(300L)
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return true
        for (i in 0 until 9) {
            if (state[i] != 0 && cells[i].contains(e.x, e.y)) {
                if (state[i] == 1) { score++; Sound.play(450.0, 300.0, 120) }
                else { score = (score - 2).coerceAtLeast(0); Sound.play(150.0, 80.0, 220) }
                state[i] = 0
                invalidate()
                break
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        body.color = Cosmetics.body
        beakP.color = Cosmetics.beak
        for (i in 0 until 9) {
            val r = cells[i]
            c.drawOval(RectF(r.left, r.centerY(), r.right, r.bottom), holeP)
            val cx = r.centerX()
            val cy = r.centerY() - r.height() * 0.05f
            val rad = r.width() * 0.28f
            if (state[i] == 1) {
                c.drawCircle(cx, cy, rad, body); c.drawCircle(cx, cy, rad, outline)
                val beak = Path().apply {
                    moveTo(cx + rad * 0.8f, cy - rad * 0.2f)
                    lineTo(cx + rad * 1.7f, cy + rad * 0.1f)
                    lineTo(cx + rad * 0.8f, cy + rad * 0.4f)
                    close()
                }
                c.drawPath(beak, beakP)
                c.drawCircle(cx + rad * 0.35f, cy - rad * 0.3f, rad * 0.14f, eyeP)
            } else if (state[i] == 2) {
                for (s in floatArrayOf(-1f, 1f)) {
                    val ear = Path().apply {
                        moveTo(cx + s * rad * 1.0f, cy - rad * 0.4f)
                        lineTo(cx + s * rad * 0.8f, cy - rad * 1.5f)
                        lineTo(cx + s * rad * 0.1f, cy - rad * 0.9f)
                        close()
                    }
                    c.drawPath(ear, foxP)
                }
                c.drawCircle(cx, cy, rad, foxP); c.drawCircle(cx, cy, rad, outline)
                c.drawOval(RectF(cx - rad * 0.45f, cy + rad * 0.05f, cx + rad * 0.45f, cy + rad * 0.7f), snoutP)
                c.drawCircle(cx - rad * 0.4f, cy - rad * 0.25f, rad * 0.13f, eyeP)
                c.drawCircle(cx + rad * 0.4f, cy - rad * 0.25f, rad * 0.13f, eyeP)
            }
        }
    }
}
